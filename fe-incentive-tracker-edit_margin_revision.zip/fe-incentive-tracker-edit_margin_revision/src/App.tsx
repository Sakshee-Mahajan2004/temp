import React, { useState, useMemo, useEffect } from 'react';
import * as XLSX from 'xlsx';

// Error boundary component
class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error?: Error }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-red-600 mb-4">Something went wrong</h2>
            <p className="text-gray-600 mb-4">
              The application encountered an error. Please refresh the page to try again.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

import { Candidate, MonthlyHours, IncentiveCalculation, IncentiveCycle, RetroactiveIncentive, Coordinator, MarginRevision, IncentiveAdjustment, User, AuthState, ADMIN_PERMISSIONS } from './types';
import { CandidateForm } from './components/CandidateForm';
import { CandidateList } from './components/CandidateList';
import { IncentiveReports } from './components/IncentiveReports';
import IncentiveCycleManager from './components/IncentiveCycleManager';
import { CycleHoursForm } from './components/CycleHoursForm';
import { CustomReportModal } from './components/CustomReportModal';
import { CandidateImportModal } from './components/CandidateImportModal';
import { CoordinatorManager } from './components/CoordinatorManager';
import { MarginRevisionModal } from './components/MarginRevisionModal';
import { MarginRevisionsModal } from './components/MarginRevisionsModal';
import { EditMarginRevisionModal } from './components/EditMarginRevisionModal';
import { ApprovedCyclesManager } from './components/ApprovedCyclesManager';

import { LoginPage } from './components/LoginPage';
import { UserManagement } from './components/UserManagement';
import { useLocalStorage } from './hooks/useLocalStorage';
import { calculateIncentivesForCandidate, generateRetroactiveIncentives, generateIncentiveReport, getAllHoursForCandidate, generateCoordinatorReports, calculateIncentiveAdjustments, getNextSequentialMonth } from './utils/calculations';
import {
  Users,
  Plus,
  BarChart3,
  Target,
  Menu,
  X,
  Repeat,
  FileText,
  Upload,
  UserCheck,
  TrendingUp,
  CheckCircle,
  LogOut,
  Shield,
  Download
} from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { getCoordinators } from './network/coordinatorApi';
import { CandidatePayload, createCandidate, getCandidates, updateCandidate, UpdateCandidatePayload, createMarginRevision, updateMarginRevision, MarginRevisionPayload, deleteCandidate } from './network/candidateApi';
import { TotalIncentiveReportModal } from './components/TotalIncentiveReportModal';
import { getIncentiveCycles } from './network/incentiveCycleApi';

type ActiveTab = 'candidates' | 'reports' | 'cycles' | 'custom-reports' | 'coordinators' | 'approved-cycles' | 'users';

function App() {
  // Authentication state
  const [authState, setAuthState] = useLocalStorage<AuthState>('auth-state', {
    isAuthenticated: false,
    user: null
  });

  const [users, setUsers] = useLocalStorage<User[]>('incentive-users', []);

  // const [candidates, setCandidates] = useLocalStorage<Candidate[]>('incentive-candidates', []);
  const [monthlyHours, setMonthlyHours] = useLocalStorage<MonthlyHours[]>('monthly-hours', []);
  // const [incentiveCycles, setIncentiveCycles] = useLocalStorage<IncentiveCycle[]>('incentive-cycles', []);
  const [incentiveCycles, setIncentiveCycles] = useState<IncentiveCycle[]>([]);
  // const [coordinators, setCoordinators] = useLocalStorage<Coordinator[]>('coordinators', []);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [coordinators, setCoordinators] = useState<Coordinator[]>([]);
  const [retroactiveIncentives, setRetroactiveIncentives] = useLocalStorage<RetroactiveIncentive[]>('retroactive-incentives', []);
  const [activeTab, setActiveTab] = useState<ActiveTab>('cycles');
  const [showCandidateForm, setShowCandidateForm] = useState(false);
  const [showCycleHoursForm, setShowCycleHoursForm] = useState(false);
  const [showCustomReportModal, setShowCustomReportModal] = useState(false);
  const [showCandidateImportModal, setShowCandidateImportModal] = useState(false);
  const [showMarginRevisionModal, setShowMarginRevisionModal] = useState(false);
  const [showMarginRevisionsReport, setShowMarginRevisionsReport] = useState(false);
  const [showTotalIncentiveReport, setShowTotalIncentiveReport] = useState<IncentiveCycle | null>(null);
  const [editingCandidate, setEditingCandidate] = useState<Candidate | null>(null);
  const [revisionCandidate, setRevisionCandidate] = useState<Candidate | null>(null);
  const [showEditMarginRevisionModal, setShowEditMarginRevisionModal] = useState(false);
  const [editingRevision, setEditingRevision] = useState<{ candidate: Candidate; revision: MarginRevision } | null>(null);
  const [selectedCycle, setSelectedCycle] = useState<IncentiveCycle | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [sessionExpired, setSessionExpired] = useState(false);


  // get Initial co-ordinate and save it
  const { data: coordinatorsData, isLoading, error } = useQuery({
    queryKey: ['coordinators'],
    queryFn: getCoordinators,
    enabled: authState.isAuthenticated,
  });

  const { data: candidatesData, isLoading: isCandidatesLoading, error: candidatesError, refetch: reftechCandidate } = useQuery({
    queryKey: ['candidates'],
    queryFn: getCandidates,
    enabled: authState.isAuthenticated,
  });

  const { data: incentiveData, isLoading: isIncentiveCycleLoading, error: incentiveCycleErrorsError, refetch: reftechIncentiveCycle } = useQuery({
    queryKey: ['incentive-cycle'],
    queryFn: getIncentiveCycles,
    enabled: authState.isAuthenticated,
  });

  useEffect(() => {
    if (incentiveData) {
      setIncentiveCycles(incentiveData);
    }
  }, [incentiveData, setCandidates]);

  useEffect(() => {
    if (coordinatorsData) {
      setCoordinators(coordinatorsData);
    }
  }, [coordinatorsData, setCoordinators]);

  useEffect(() => {
    if (candidatesData) {
      setCandidates(candidatesData);
    }
  }, [candidatesData, setCandidates]);

  useEffect(() => {
    const handler = () => setSessionExpired(true);
    window.addEventListener('sessionExpired', handler);
    return () => window.removeEventListener('sessionExpired', handler);
  }, []);

  const handleSessionExpiredOk = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('auth-state');
    setAuthState({ isAuthenticated: false, user: null });
    setSessionExpired(false);
    window.location.reload(); // reloads to login
  };


  const createCandidateMutation = useMutation({
    mutationFn: (payload: CandidatePayload) => createCandidate(payload),
    onSuccess: (data) => {
      reftechCandidate();
      // Handle success, e.g., show a message or refetch candidate list

    },
    onError: (error) => {
      // Handle error
      alert('Failed to create candidate');
      console.error(error);
    }
  });

  const updateCandidateMutation = useMutation({
    mutationFn: (payload: UpdateCandidatePayload) => updateCandidate(payload),
    onSuccess: (updatedCandidate) => {
      setCandidates(prev =>
        prev.map(c =>
          (c.id && updatedCandidate.id && c.id === updatedCandidate.id) ||
          (c.candidateId && updatedCandidate.candidateId && c.candidateId === updatedCandidate.candidateId)
            ? updatedCandidate
            : c
        )
      );
      // reftechCandidate();
    },
    onError: (error) => {
      alert('Failed to update candidate');
      console.error(error);
    }
  });

  const deleteCandidateMutation = useMutation({
    mutationFn: (id: string) => deleteCandidate(id),
    onSuccess: () => {
      reftechCandidate();
    },
    onError: (error) => {
      alert('Failed to delete candidate');
      console.error(error);
    }
  });

  const createMarginRevisionMutation = useMutation({
    mutationFn: ({ candidateId, payload }: { candidateId: string; payload: MarginRevisionPayload }) =>
      createMarginRevision(candidateId, payload),
    onSuccess: () => {
      reftechCandidate();
    },
    onError: (error) => {
      alert('Failed to save margin revision');
      console.error(error);
    }
  });

  const updateMarginRevisionMutation = useMutation({
    mutationFn: ({ candidateId, revisionId, payload }: { candidateId: string; revisionId: string; payload: MarginRevisionPayload }) =>
      updateMarginRevision(candidateId, revisionId, payload),
    onSuccess: () => {
      reftechCandidate();
    },
    onError: (error) => {
      alert('Failed to update margin revision');
      console.error(error);
    }
  });



  // Initialize default admin user if no users exist
  React.useEffect(() => {
    if (users.length === 0) {
      const defaultAdmin: User = {
        id: 'admin-001',
        username: 'admin',
        email: 'admin@company.com',
        role: 'ADMIN',
        permissions: ADMIN_PERMISSIONS,
        createdAt: new Date().toISOString(),
        isActive: true
      };
      setUsers([defaultAdmin]);
    }
  }, [users, setUsers]);

  const handleLogin = (user: User) => {
    setAuthState({
      isAuthenticated: true,
      user
    });
  };

  const handleLogout = () => {
    setAuthState({
      isAuthenticated: false,
      user: null
    });
    setActiveTab('cycles');
  };

  const hasPermission = (permission: string): boolean => {
    if (!authState.user) return false;
    return authState.user.permissions.includes(permission as any);
  };

  console.log("Current user:", authState.user);
console.log("Current user permissions:", authState.user?.permissions);

  const incentiveCalculations = useMemo(() => {
    try {
      const calculations: IncentiveCalculation[] = [];

      candidates.forEach(candidate => {
        try {
          const approvedCycles = incentiveCycles.filter(c => c.status === 'approved' || c.status === 'APPROVED');
          incentiveCycles.forEach(cycle => {
            const cycleHours = (cycle.monthlyHours ?? []).find(h => h.candidateId === candidate.candidateId);
            if (cycleHours) {
              const candidateIncentives = calculateIncentivesForCandidate(candidate, cycleHours, approvedCycles);
              // If types match, just push:
              const mapped = candidateIncentives.map(inc => ({
                candidateId: inc.candidateId,
                candidateName: inc.candidateName,
                coordinatorName: inc.coordinatorName,
                coordinatorType: (inc as any).coordinatorType || '',
                month: (inc as any).month || cycle.month,
                hoursWorked: (inc as any).hoursWorked ?? cycleHours.hoursWorked ?? 0,
                margin: (inc as any).margin ?? candidate.margin ?? 0,
                incentiveAmount: inc.amount,
                isRecurring: (inc as any).isRecurring || false,
                isOneTime: (inc as any).isOneTime,
                notes: (inc as any).notes || (inc as any).reason || '',
              }));
              calculations.push(...mapped);
            }
          });
        } catch (error) {
          console.error('Error calculating incentives for candidate:', candidate.candidateId, error);
        }
      });

      return calculations;
    } catch (error) {
      console.error('Error in incentiveCalculations:', error);
      return [];
    }
  }, [candidates, monthlyHours, incentiveCycles]);


  // Show login page if not authenticated
  if (!authState.isAuthenticated) {
    return (
      <ErrorBoundary>
        <LoginPage onLogin={handleLogin} />
      </ErrorBoundary>
    );
  }

  const handleSaveCandidate = (candidate: Candidate) => {
    if (editingCandidate) {
      if (typeof candidate.id === 'string') {
        updateCandidateMutation.mutate({ ...candidate, id: candidate.id });
      } else if (typeof candidate.candidateId === 'string') {
        updateCandidateMutation.mutate({ ...candidate, id: candidate.candidateId });
      }
    } else {
      const { id, ...candidateWithoutId } = candidate;
      createCandidateMutation.mutate(candidateWithoutId);
    }
    setShowCandidateForm(false);
    setEditingCandidate(null);
  };

const handleImportCandidates = async (newCandidates: Candidate[]) => {
  try {
    // For each candidate, check if they exist and call update or create accordingly
    const results = await Promise.allSettled(
      newCandidates.map(async (candidate) => {
        // Try to find existing candidate by id or candidateId
        const existing = candidates.find(
          c => (c.id && candidate.id && c.id === candidate.id) ||
               (c.candidateId && candidate.candidateId && c.candidateId === candidate.candidateId)
        );
        if (existing) {
          // Update existing candidate
          const updatePayload = { ...candidate, id: existing.id || candidate.id || candidate.candidateId };
          return updateCandidateMutation.mutateAsync(updatePayload);
        } else {
          // Create new candidate (remove id if present)
          const { id, ...candidateWithoutId } = candidate;
          return createCandidateMutation.mutateAsync(candidateWithoutId);
        }
      })
    );

    // Check for any failures
    const failedImports = results.filter(result => result.status === 'rejected');
    if (failedImports.length > 0) {
      console.error('Some candidates failed to import:', failedImports);
      alert(`Successfully imported ${results.length - failedImports.length} candidates, but failed to import ${failedImports.length}.`);
    } else {
      alert(`Successfully imported/updated ${newCandidates.length} candidates!`);
    }

    // Refresh the candidate list
    reftechCandidate();
    setShowCandidateImportModal(false);
  } catch (error) {
    console.error('Error during import:', error);
    alert('An error occurred during import. Please check the console for details.');
  }
};

  const handleEditCandidate = (candidate: Candidate) => {
    setEditingCandidate(candidate);
    setShowCandidateForm(true);
  };

  const handleMarginRevision = (candidate: Candidate) => {
    setRevisionCandidate(candidate);
    setShowMarginRevisionModal(true);
  };

  const handleEditRevision = (candidate: Candidate, revision: MarginRevision) => {
    setEditingRevision({ candidate, revision });
    setShowEditMarginRevisionModal(true);
    setRevisionCandidate(null);
    setShowMarginRevisionModal(false);
    setShowMarginRevisionsReport(false);
  };

  const handleSaveMarginRevision = async (revision: MarginRevision) => {
    if (revisionCandidate && revisionCandidate.id) {
      // Use only the fields required by MarginRevisionPayload
      const {
        effectiveDate,
        contractType,
        payRate,
        w2PayrollAdminTaxesPercentage,
        w2C2COverheadCostPercentage,
        healthBenefits,
        billRate,
        mspFeesPercentage,
        finderFees,
        w2PayrollAdminTaxes,
        w2C2COverheadCost,
        netPurchase,
        mspFeesDollar,
        netBillRate,
        margin,
        reason,
        createdAt,
        createdBy,
      } = revision;

      const payload: MarginRevisionPayload = {
        effectiveDate,
        contractType,
        payRate,
        w2PayrollAdminTaxesPercentage,
        w2C2COverheadCostPercentage,
        healthBenefits,
        billRate,
        mspFeesPercentage,
        finderFees,
        w2PayrollAdminTaxes,
        w2C2COverheadCost,
        netPurchase,
        mspFeesDollar,
        netBillRate,
        margin,
        reason,
        createdAt,
        createdBy,
      };

      createMarginRevisionMutation.mutate(
        { candidateId: revisionCandidate.id, payload },
        {
          onSuccess: () => {
            setShowMarginRevisionModal(false);
            setRevisionCandidate(null);
            // Optionally refetch candidates here
          },
          onError: () => {
            setShowMarginRevisionModal(false);
            setRevisionCandidate(null);
          }
        }
      );
    }
    setCandidates(prev => prev.map(candidate => {
      if (candidate.candidateId === revision.candidateId) {
        const updatedCandidate = {
          ...candidate,
          marginRevisions: [...(candidate.marginRevisions || []), revision]
        };

        // Calculate adjustments for approved cycles
        // calculateIncentiveAdjustments expects (currentIncentives, previousIncentives)
        // You need to provide the correct arguments, for now pass empty arrays and do not add to incentiveAdjustments since types do not match
        // const adjustments = calculateIncentiveAdjustments([], []);
        const adjustments: IncentiveAdjustment[] = [];

        // Add adjustments to the current active cycle if it exists
        if (adjustments.length > 0) {
          
          const activeCycle = incentiveCycles.find(c => c.status === 'draft' || c.status === 'calculated');

          if (activeCycle) {
            setIncentiveCycles(prevCycles => prevCycles.map(cycle => {
              if (cycle.id === activeCycle.id) {
                return {
                  ...cycle,
                  incentiveAdjustments: [...(cycle.incentiveAdjustments || []), ...adjustments]
                };
              }
              return cycle;
            }));
          }
        }

        return updatedCandidate;
      }
      return candidate;
    }));
    setShowMarginRevisionModal(false);
    setRevisionCandidate(null);
  };

  const handleUpdateMarginRevision = async (revision: MarginRevision) => {
    if (editingRevision && editingRevision.candidate.id && revision.id) {
      // Use only the fields required by MarginRevisionPayload
      const {
        effectiveDate,
        contractType,
        payRate,
        w2PayrollAdminTaxesPercentage,
        w2C2COverheadCostPercentage,
        healthBenefits,
        billRate,
        mspFeesPercentage,
        finderFees,
        w2PayrollAdminTaxes,
        w2C2COverheadCost,
        netPurchase,
        mspFeesDollar,
        netBillRate,
        margin,
        reason,
        createdAt,
        createdBy,
      } = revision;

      const payload: MarginRevisionPayload = {
        effectiveDate,
        contractType,
        payRate,
        w2PayrollAdminTaxesPercentage,
        w2C2COverheadCostPercentage,
        healthBenefits,
        billRate,
        mspFeesPercentage,
        finderFees,
        w2PayrollAdminTaxes,
        w2C2COverheadCost,
        netPurchase,
        mspFeesDollar,
        netBillRate,
        margin,
        reason,
        createdAt,
        createdBy,
      };

      updateMarginRevisionMutation.mutate(
        { candidateId: editingRevision.candidate.id, revisionId: revision.id, payload },
        {
          onSuccess: () => {
            setShowEditMarginRevisionModal(false);
            setEditingRevision(null);
          },
          onError: () => {
            setShowEditMarginRevisionModal(false);
            setEditingRevision(null);
          }
        }
      );
    }
  };

  const handleDeleteCandidate = (candidateId: string) => {
    if (window.confirm('Are you sure you want to delete this candidate?')) {
      deleteCandidateMutation.mutate(candidateId);
      setCandidates(prev => prev.filter(c => c.id !== candidateId));
      // Also remove associated monthly hours
      setMonthlyHours(prev => prev.filter(h => {
        const candidate = candidates.find(c => c.id === candidateId);
        return candidate ? h.candidateId !== candidate.candidateId : true;
      }));
    }
  };
  

  // Incentive Cycle Management
  const handleStartCycle = (month: string) => {
    try {
      const newCycle: IncentiveCycle = {
        id: `cycle-${Date.now()}`,
        month,
        type: 'regular',
        status: 'draft',
        startedAt: new Date().toISOString(),
        monthlyHours: [],
        incentiveCalculations: [],
        incentiveAdjustments: []
      };

      setIncentiveCycles(prev => [...prev, newCycle]);
    } catch (error) {
      console.error('Error starting cycle:', error);
      alert('Error starting cycle. Please try again.');
    }
  };

  const handleStartAdditionalCycle = (month: string) => {
    const newCycle: IncentiveCycle = {
      id: `additional-cycle-${Date.now()}`,
      month,
      type: 'additional',
      status: 'draft',
      startedAt: new Date().toISOString(),
      monthlyHours: [],
      incentiveCalculations: [],
      incentiveAdjustments: []
    };

    setIncentiveCycles(prev => [...prev, newCycle]);
  };

  const handleCalculateIncentives = (cycleId: string) => {
    try {
      setIncentiveCycles(prev => prev.map(cycle => {
        if (cycle.id === cycleId) {
          try {
            // generateCoordinatorReports expects (incentives, candidates)
            const coordinatorReports: any = generateCoordinatorReports([], candidates);

            return {
              ...cycle,
              status: 'calculated' as const,
              calculatedAt: new Date().toISOString(),
              coordinatorReports
            };
          } catch (error) {
            console.error('Error calculating cycle:', error);
            return cycle;
          }
        }
        return cycle;
      }));
    } catch (error) {
      console.error('Error in handleCalculateIncentives:', error);
      alert('Error calculating incentives. Please try again.');
    }
  };

  const handleMakeChanges = (cycleId: string) => {
    setIncentiveCycles(prev => prev.map(cycle => {
      if (cycle.id === cycleId) {
        return {
          ...cycle,
          status: 'draft' as const
        };
      }
      return cycle;
    }));
  };

  const handleApproveCycle = (cycleId: string) => {
    if (window.confirm('Are you sure you want to approve this cycle? This will send coordinator reports via email.')) {
      setIncentiveCycles(prev => prev.map(cycle => {
        if (cycle.id === cycleId) {
          // Mark coordinator reports as sent
          const updatedReports = cycle.coordinatorReports?.map(report => ({
            ...report,
            sentAt: new Date().toISOString()
          }));

          return {
            ...cycle,
            status: 'approved' as const,
            approvedAt: new Date().toISOString(),
            coordinatorReports: updatedReports
          };
        }
        return cycle;
      }));

      // Here you would integrate with an email service to send the reports
      alert('Cycle approved! Coordinator reports have been generated and marked for sending.');
    }
  };

  const handleCancelCycle = (cycleId: string, reason: string) => {
    setIncentiveCycles(prev => prev.map(cycle => {
      if (cycle.id === cycleId) {
        return {
          ...cycle,
          status: 'cancelled' as const,
          cancelledAt: new Date().toISOString(),
          cancellationReason: reason
        };
      }
      return cycle;
    }));
  };

  const handleDeleteCycle = (cycleId: string) => {
    setIncentiveCycles(prev => prev.filter(cycle => cycle.id !== cycleId));
  };

  const handleDeleteApprovedCycle = (cycleId: string) => {
    if (hasPermission('DELETE_APPROVED_CYCLES')) {
      setIncentiveCycles(prev => prev.filter(cycle => cycle.id !== cycleId));
    } else {
      alert('You do not have permission to delete approved cycles.');
    }
  };

  const handleAddHours = (cycleId: string) => {
    const cycle = incentiveCycles.find(c => c.id === cycleId);
    if (cycle) {
      setSelectedCycle(cycle);
      setShowCycleHoursForm(true);
    }
  };

  const handleSaveCycleHours = (incentiveCycle: IncentiveCycle, monthlyHours: MonthlyHours[]) => {
    setIncentiveCycles(prev => prev.map(cycle => {
      if (cycle.id === incentiveCycle.id) {
      const obj = {
          ...incentiveCycle
        };
        return  obj;
      }
      return cycle;
    }));
    setShowCycleHoursForm(false);
    setSelectedCycle(null);
  };

  const handleDownloadReport = (cycleId: string) => {
    const cycle = incentiveCycles.find(c => c.id === cycleId);
    if (cycle) {
      // generateIncentiveReport expects (incentives, candidates, cycle)
      const csvContent = generateIncentiveReport([], candidates, cycle);
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `incentive-report-${cycle.month}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    }
  };

  const exportCandidatesToExcel = () => {
    const formatCurrency = (amount: number | undefined | null): string => {
      if (amount === undefined || amount === null || isNaN(amount)) return '$0.00';
      return `$${amount.toFixed(2)}`;
    };
    const formatDate = (date: string): string => new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    const formatPercentage = (value: number | undefined | null): string => {
      if (value === undefined || value === null || isNaN(value)) return '0%';
      return `${(value * 100).toFixed(2)}%`;
    };
    const getCoordinatorName = (coordinator: any): string => coordinator?.name || 'N/A';

    const candidateData = candidates.map((candidate): Record<string, string | number> => ({
      'Candidate ID': candidate.candidateId,
      'Candidate Name': candidate.candidateName,
      'Client Name': candidate.clientName,
      'Contract Type': candidate.contractType,
      'Start Date': formatDate(candidate.startDate),
      'End Date': candidate.endDate ? formatDate(candidate.endDate) : 'Active',
      'Status': candidate.endDate ? 'Inactive' : 'Active',
      'Pay Rate': formatCurrency(candidate.payRate),
      'W2 Payroll Admin Taxes %': formatPercentage(candidate.w2PayrollAdminTaxesPercentage),
      'W2 Payroll Admin Taxes $': formatCurrency(candidate.w2PayrollAdminTaxes),
      'W2/C2C Overhead Cost %': formatPercentage(candidate.w2C2COverheadCostPercentage),
      'W2/C2C Overhead Cost $': formatCurrency(candidate.w2C2COverheadCost),
      'Health Benefits': formatCurrency(candidate.healthBenefits),
      'Net Purchase': formatCurrency(candidate.netPurchase),
      'Bill Rate': formatCurrency(candidate.billRate),
      'MSP Fees %': formatPercentage(candidate.mspFeesPercentage),
      'MSP Fees $': formatCurrency(candidate.mspFeesDollar),
      'Net Bill Rate': formatCurrency(candidate.netBillRate),
      'Current Margin': formatCurrency(candidate.margin),
      'Finder Fees': candidate.finderFees ? formatCurrency(candidate.finderFees) : 'N/A',
      'Recruiter': getCoordinatorName(candidate.recruiter),
      'Team Lead': getCoordinatorName(candidate.lead),
      'Manager': getCoordinatorName(candidate.manager),
      'Senior Manager': getCoordinatorName(candidate.seniorManager),
      'Associate Director': getCoordinatorName(candidate.assoDirector),
      'Center Head': getCoordinatorName(candidate.centerHead),
      'CRM': getCoordinatorName(candidate.crm),
      'Candidate Source': candidate.candidateSource || 'N/A',
      'Other Name': candidate.otherName || 'N/A',
      'Margin Revisions Count': candidate.marginRevisions?.length || 0,
      'Last Updated': candidate.marginRevisions && candidate.marginRevisions.length > 0 
        ? formatDate(candidate.marginRevisions[candidate.marginRevisions.length - 1].effectiveDate)
        : formatDate(candidate.startDate)
    }));
    const marginRevisionsData: Record<string, string | number>[] = [];
    candidates.forEach((candidate) => {
      if (candidate.marginRevisions && candidate.marginRevisions.length > 0) {
        candidate.marginRevisions.forEach((revision) => {
          marginRevisionsData.push({
            'Candidate ID': candidate.candidateId,
            'Candidate Name': candidate.candidateName,
            'Client Name': candidate.clientName,
            'Revision Date': formatDate(revision.effectiveDate),
            'Contract Type': revision.contractType || candidate.contractType,
            'Pay Rate': formatCurrency(revision.payRate || candidate.payRate),
            'W2 Payroll Admin Taxes %': formatPercentage(revision.w2PayrollAdminTaxesPercentage),
            'W2/C2C Overhead Cost %': formatPercentage(revision.w2C2COverheadCostPercentage),
            'Health Benefits': formatCurrency(revision.healthBenefits),
            'Bill Rate': formatCurrency(revision.billRate || candidate.billRate),
            'MSP Fees %': formatPercentage(revision.mspFeesPercentage),
            'Finder Fees': revision.finderFees ? formatCurrency(revision.finderFees) : 'N/A',
            'W2 Payroll Admin Taxes $': formatCurrency(revision.w2PayrollAdminTaxes),
            'W2/C2C Overhead Cost $': formatCurrency(revision.w2C2COverheadCost),
            'Net Purchase': formatCurrency(revision.netPurchase),
            'MSP Fees $': formatCurrency(revision.mspFeesDollar),
            'Net Bill Rate': formatCurrency(revision.netBillRate),
            'Margin': formatCurrency(revision.margin),
            'Reason': revision.reason || 'N/A',
            'Created By': revision.createdBy || 'N/A',
            'Created At': formatDate(revision.createdAt)
          });
        });
      }
    });
    const workbook = XLSX.utils.book_new();
    const candidateWorksheet = XLSX.utils.json_to_sheet(candidateData);
    XLSX.utils.book_append_sheet(workbook, candidateWorksheet, 'Candidates');
    let revisionsWorksheet: XLSX.WorkSheet | undefined;
    if (marginRevisionsData.length > 0) {
      revisionsWorksheet = XLSX.utils.json_to_sheet(marginRevisionsData);
      XLSX.utils.book_append_sheet(workbook, revisionsWorksheet, 'Margin Revisions');
    }
    const candidateColWidths = Object.keys(candidateData[0] || {}).map(key => ({ wch: Math.min(Math.max(key.length + 2, 12), 30) }));
    candidateWorksheet['!cols'] = candidateColWidths;
    if (marginRevisionsData.length > 0 && revisionsWorksheet) {
      const revisionsColWidths = Object.keys(marginRevisionsData[0] || {}).map(key => ({ wch: Math.min(Math.max(key.length + 2, 12), 25) }));
      revisionsWorksheet['!cols'] = revisionsColWidths;
    }
    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `candidates_export_${timestamp}.xlsx`;
    XLSX.writeFile(workbook, filename);
  };

  // if (isLoading || isCandidatesLoading) return <div>Loading Data...</div>;
  // if (error || candidatesError) return <div>Error loading Data</div>;



  const tabs = [
    { id: 'cycles' as const, name: 'Incentive Cycles', icon: Repeat, count: incentiveCycles.length },
    { id: 'approved-cycles' as const, name: 'Approved Cycles', icon: CheckCircle, count: incentiveCycles.filter(c => c.status === 'APPROVED' || c.status === 'approved').length },
    { id: 'candidates' as const, name: 'Candidates', icon: Users, count: candidates.length, permission: 'ADD_CANDIDATES' },
    { id: 'coordinators' as const, name: 'Coordinators', icon: UserCheck, count: coordinators.length, permission: 'COORDINATORS' },
    { id: 'custom-reports' as const, name: 'Custom Reports', icon: FileText, count: 0, permission: 'CUSTOM_REPORTS' },
    { id: 'reports' as const, name: 'Legacy Reports', icon: BarChart3, count: incentiveCalculations.length, permission: 'LEGACY_REPORTS' },
    ...(hasPermission('USER_MANAGEMENT') ? [{ id: 'users' as const, name: 'User Management', icon: Shield, count: users.length, permission: 'USER_MANAGEMENT' }] : [])
  ].filter(tab => !tab.permission || hasPermission(tab.permission));
  console.log("authState.user?.role", authState.user?.role);

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <Target className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Incentive Tracker</h1>
                  <p className="text-sm text-gray-500">Comprehensive incentive management system</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-sm font-medium text-gray-900">{authState.user?.username}</div>
                  <div className="text-xs text-gray-500 capitalize">{authState.user?.role}</div>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden">
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
                >
                  {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Navigation */}
        <nav className={`bg-white shadow-sm border-b border-gray-200 ${mobileMenuOpen ? 'block' : 'hidden'} md:block`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:space-x-8 py-4">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors mb-2 md:mb-0 ${activeTab === tab.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                    }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.name}</span>
                  {tab.count > 0 && (
                    <span className="bg-gray-200 text-gray-700 text-xs rounded-full px-2 py-1 min-w-[1.5rem] text-center">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === 'cycles' && (
            <IncentiveCycleManager
              candidates={candidates}
              cycles={incentiveCycles}
              setCycles={setIncentiveCycles}
              retroactiveIncentives={retroactiveIncentives}
              setRetroactiveIncentives={setRetroactiveIncentives}
              coordinators={coordinators}
            />
          )}

          {activeTab.toLowerCase() === 'approved-cycles' && (
            <ApprovedCyclesManager
              cycles={incentiveCycles}
              coordinators={coordinators}
              candidates={candidates}
            />
          )}

          {activeTab === 'candidates' && (
            hasPermission('ADD_CANDIDATES') ? (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Candidate Management</h2>
                    <p className="text-gray-600">Manage candidate information and calculate margins</p>
                  </div>
                  <div className="flex space-x-3">
                    <button
                      onClick={exportCandidatesToExcel}
                      className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
                    >
                      <Upload className="w-4 h-4"/>
                      <span>Export Excel</span> 
                    </button>
                    <button
                      onClick={() => setShowMarginRevisionsReport(true)}
                      className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2"
                    >
                      <TrendingUp className="w-4 h-4" />
                      <span>View Margin Revisions</span>
                    </button>
                    {hasPermission('ADD_CANDIDATES') && (
                      <button
                        onClick={() => setShowCandidateImportModal(true)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                      >
                        <Download className="w-4 h-4" />
                        <span>Import Excel</span>
                      </button>
                    )}
                    <button
                      onClick={() => setShowCandidateForm(true)}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Candidate</span>
                    </button>
                  </div>
                </div>

                <CandidateList
                  candidates={candidates}
                  onEdit={hasPermission('ADD_CANDIDATES') ? handleEditCandidate : undefined}
                  onDelete={handleDeleteCandidate}
                  onMarginRevision={hasPermission('MARGIN_REVISION') ? handleMarginRevision : undefined}
                />
              </div>
            ) : (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
                <p className="text-gray-500">You don't have permission to access candidate management.</p>
              </div>
            )
          )}

          {activeTab === 'coordinators' && (
            hasPermission('COORDINATORS') ? (
              <CoordinatorManager
                coordinators={coordinators}
                onSave={setCoordinators}
              />
            ) : (
              <div className="text-center py-12">
                <UserCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
                <p className="text-gray-500">You don't have permission to access coordinator management.</p>
              </div>
            )
          )}

          {activeTab === 'custom-reports' && (
            hasPermission('CUSTOM_REPORTS') ? (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Custom Reports</h2>
                    <p className="text-gray-600">Generate detailed reports with custom filters and all candidate fields</p>
                  </div>
                  <button
                    onClick={() => setShowCustomReportModal(true)}
                    className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Generate Custom Report</span>
                  </button>
                </div>

                <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Custom Report Generator</h3>
                    <p className="text-gray-500 mb-4">
                      Create comprehensive reports with all candidate fields, incentive details, and custom filters.
                    </p>
                    <p className="text-sm text-gray-400">
                      Click "Generate Custom Report" to get started with advanced filtering and reporting options.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
                <p className="text-gray-500">You don't have permission to access custom reports.</p>
              </div>
            )
          )}

          {activeTab === 'reports' && (
            hasPermission('LEGACY_REPORTS') ? (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Legacy Incentive Reports</h2>
                  <p className="text-gray-600">Month-wise incentive calculations and summaries with advanced filtering</p>
                </div>

                <IncentiveReports incentives={incentiveCalculations} />
              </div>
            ) : (
              <div className="text-center py-12">
                <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
                <p className="text-gray-500">You don't have permission to access legacy reports.</p>
              </div>
            )
          )}

          {activeTab === 'users' && hasPermission('USER_MANAGEMENT') && (
            <UserManagement
              users={users}
              currentUser={authState.user!}
              onSave={setUsers}
            />
          )}
        </main>

        {/* Modals */}
        {showCandidateForm && hasPermission('ADD_CANDIDATES') && (
          <CandidateForm
            candidate={editingCandidate || undefined}
            coordinators={coordinators}
            onSave={handleSaveCandidate}
            onCancel={() => {
              setShowCandidateForm(false);
              setEditingCandidate(null);
            }}
          />
        )}

        {showMarginRevisionModal && revisionCandidate && hasPermission('MARGIN_REVISION') && (
          <MarginRevisionModal
            candidate={revisionCandidate}
            onSave={handleSaveMarginRevision}
            onCancel={() => {
              setShowMarginRevisionModal(false);
              setRevisionCandidate(null);
            }}
          />
        )}

        {showEditMarginRevisionModal && editingRevision && hasPermission('MARGIN_REVISION') && (
          <EditMarginRevisionModal
            candidate={editingRevision.candidate}
            revision={editingRevision.revision}
            onSave={handleUpdateMarginRevision}
            onCancel={() => {
              setShowEditMarginRevisionModal(false);
              setEditingRevision(null);
            }}
          />
        )}

        {showCandidateImportModal && hasPermission('ADD_CANDIDATES') && (
          <CandidateImportModal
            onSave={handleImportCandidates}
            onCancel={() => setShowCandidateImportModal(false)}
            coordinators={coordinators}
          />
        )}

        {showCycleHoursForm && selectedCycle && hasPermission('ADD_HOURS') && (
          <CycleHoursForm
            cycle={selectedCycle}
            candidates={candidates}
            retroactiveIncentives={retroactiveIncentives}
            approvedCycles={incentiveCycles.filter(c => c.status === 'approved' || c.status === 'APPROVED')}
            allCycles={incentiveCycles}
            onSave={handleSaveCycleHours}
            onCancel={() => {
              setShowCycleHoursForm(false);
              setSelectedCycle(null);
            }}
          />
        )}

        {showCustomReportModal && hasPermission('CUSTOM_REPORTS') && (
          <CustomReportModal
            cycles={incentiveCycles.filter(c => c.status === 'approved' || c.status === 'APPROVED')}
            candidates={candidates}
            onClose={() => setShowCustomReportModal(false)}
          />
        )}

        {showMarginRevisionsReport && (
          <MarginRevisionsModal
            candidates={candidates}
            onClose={() => setShowMarginRevisionsReport(false)}
            
            onEditRevision={handleEditRevision}
          />
        )}

        {showTotalIncentiveReport && (
          <TotalIncentiveReportModal
            cycle={showTotalIncentiveReport}
            candidates={candidates}
            onClose={() => setShowTotalIncentiveReport(null)}
          />
        )}
        {sessionExpired && (
          <div style={{
            position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
            background: 'rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
          }}>
            <div style={{ background: 'white', padding: 32, borderRadius: 8, boxShadow: '0 2px 16px rgba(0,0,0,0.2)', minWidth: 300, textAlign: 'center' }}>
              <h2 style={{ marginBottom: 16 }}>Session has expired</h2>
              <p style={{ marginBottom: 24 }}>Please login again to continue.</p>
              <button onClick={handleSessionExpiredOk} style={{ background: '#2563eb', color: 'white', padding: '8px 24px', border: 'none', borderRadius: 4, fontWeight: 600 }}>OK</button>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}

export default App;