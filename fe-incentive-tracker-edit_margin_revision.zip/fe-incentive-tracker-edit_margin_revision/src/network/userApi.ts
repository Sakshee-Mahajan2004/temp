import axiosClient from './axiosClient';
import { User } from '../types';

// Backend expects some fields not present in our User interface, so we define a payload type for creation
export interface CreateUserPayload {
  username: string;
  email: string;
  password: string;
  firstName?: string; // optional
  middleName?: string; // optional
  lastName: string; // required
  phoneNumber: string; // required
  role: string; // Backend expects 'USER' or 'ADMIN'
  permissions?: string[] | null;
  isActive: boolean;
}

export interface UpdateUserPayload {
    username?: string;
    email?: string;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    phoneNumber?: string;
    role?: string;
    permissions?: string[] | null;
    isActive?: boolean;
  }

export async function addUser(payload: CreateUserPayload) {
  const response = await axiosClient.post('/users', payload);
  return response.data;
}

export async function deleteUser(id: string) {
  const response = await axiosClient.delete(`/users/${id}`);
  return response.data;
} 

export async function updateUser(id: string, payload: UpdateUserPayload) {
    const response = await axiosClient.put(`/users/${id}`, payload);
    return response.data;
  }