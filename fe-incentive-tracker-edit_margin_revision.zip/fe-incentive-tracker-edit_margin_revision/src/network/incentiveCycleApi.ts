import axiosClient from './axiosClient';
import { IncentiveCalculation, IncentiveCycle } from '../types';


export interface IncentiveCyclePayload {
  month: string;
  type: 'regular' | 'additional' | 'REGULAR' | 'ADDITIONAL'; // allow both cases
  status?: 'draft' | 'calculating' | 'calculated' | 'approved' | 'cancelled'|'CALCULATED'; // now optional
  startedAt?: string;
  calculatedAt?: string;
  approvedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
  monthlyHours?: any[];
  incentiveCalculations?: any[];
  incentiveAdjustments?: any[];
  coordinatorReports?: any[];
  notes?: string;
  createdBy?: string;
}


export interface MonthlyHoursPayload {
    candidateId: string;
    month: string; // YYYY-MM format
    hoursWorked: number;
    isRetroactive?: boolean; // Flag to indicate if this was added retroactively
  }
  

export interface UpdateIncentiveCyclePayload extends IncentiveCyclePayload {
  id: string;
}

export async function createIncentiveCycle(payload: IncentiveCyclePayload) {
  const response = await axiosClient.post('/incentive-cycles', payload);
  return response.data;
}

export async function getIncentiveCycles(): Promise<IncentiveCycle[]> {
  const response:any = await axiosClient.get('/incentive-cycles?page=0&size=100');
  console.log("Response >>>", response)
  return response.data.content;
}

export async function updateIncentiveCycle(payload: UpdateIncentiveCyclePayload) {
  const response = await axiosClient.put(`/incentive-cycles/${payload.id}`, payload);
  return response.data;
}

export async function deleteIncentiveCycle(id: string) {
  const response = await axiosClient.delete(`/incentive-cycles/${id}`);
  return response.data;
}

export async function addHoursToIncentiveCycle(cycleId: string, payload: MonthlyHoursPayload[]) {
  const response = await axiosClient.post(`/incentive-cycles/${cycleId}/add-hours`, payload);
  return response.data;
}

export async function calculateIncentivesForCycleApi(cycleId: string) {
  const response = await axiosClient.post(`/incentive-cycles/${cycleId}/calculate-incentives`);
  // Ensure the response includes incentiveCalculations
  return {
    ...response.data,
    incentiveCalculations: response.data.incentiveCalculations || []
  };
}
export async function approveIncentiveCycle(cycleId: string) {
  const response = await axiosClient.post(`/incentive-cycles/${cycleId}/approve`);
  return response.data;
}

export async function cancelIncentiveCycle(cycleId: string, reason: string) {
  const response = await axiosClient.post(`/incentive-cycles/${cycleId}/cancel`, null, {
    params: { reason }
  });
  return response.data;
}


export async function updatecalculateIncentivesForCycleApi(cycleId: string,  payload: IncentiveCalculation[]) {
  const response = await axiosClient.post(`/incentive-cycles/${cycleId}/add-calculations`,payload);
  // Ensure the response includes incentiveCalculations
  return {
    ...response.data,
    incentiveCalculations: response.data.incentiveCalculations || []
  };
}

export async function deleteAllApprovedCycles() {
  const response = await axiosClient.delete('/incentive-cycles/approved');
  return response.data;
}


