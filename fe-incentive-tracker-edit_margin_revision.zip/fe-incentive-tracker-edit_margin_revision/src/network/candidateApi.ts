import { Candidate, Coordinator, MarginRevision } from '../types';
import axiosClient from './axiosClient';



// export interface MarginRevision {
//   id: string;
//   effectiveDate: string;
//   contractType: string;
//   payRate: number;
//   w2PayrollAdminTaxesPercentage: number;
//   w2C2COverheadCostPercentage: number;
//   healthBenefits: number;
//   billRate: number;
//   mspFeesPercentage: number;
//   finderFees: number;
//   w2PayrollAdminTaxes: number;
//   w2C2COverheadCost: number;
//   netPurchase: number;
//   mspFeesDollar: number;
//   netBillRate: number;
//   margin: number;
//   reason: string;
//   createdBy: string;
// }

// export interface Candidate {
//     id: string;
//     candidateId: string;
//     candidateName: string;
//     clientName: string;
//     contractType: 'C2C' | 'W2' | 'Fulltime';
//     startDate: string;
//     endDate?: string;
//     payRate: number;
//     w2PayrollAdminTaxesPercentage: number;
//     w2PayrollAdminTaxes: number; // Calculated: payRate * w2PayrollAdminTaxesPercentage
//     w2C2COverheadCostPercentage: number;
//     w2C2COverheadCost: number; // Calculated: payRate * w2C2COverheadCostPercentage
//     healthBenefits: number;
//     netPurchase: number; // Calculated: payRate + w2PayrollAdminTaxes + w2C2COverheadCost + healthBenefits
//     billRate: number;
//     mspFeesPercentage: number;
//     mspFeesDollar: number; // Calculated: billRate * mspFeesPercentage
//     netBillRate: number; // Calculated: billRate - mspFeesDollar
//     margin: number; // Calculated: netBillRate - netPurchase
//     // Full-time specific fields
//     finderFees?: number; // Only for Fulltime contracts
//     crm?: Coordinator;
//     lead?: Coordinator;
//     manager?: Coordinator;
//     seniorManager?: Coordinator;
//     assoDirector?: Coordinator;
//     centerHead?: Coordinator;
//     recruiter?: Coordinator;
//     marginRevisions?: MarginRevision[];
//   }
  

export interface CandidatePayload {
  id?: string;
  candidateId: string;
  candidateName: string;
  clientName: string;
  contractType: 'C2C' | 'W2' | 'FULLTIME';
  startDate: string;
  endDate?: string;
  payRate: number;
  w2PayrollAdminTaxesPercentage: number;
  w2PayrollAdminTaxes: number;
  w2C2COverheadCostPercentage: number;
  w2C2COverheadCost: number;
  healthBenefits: number;
  netPurchase: number;
  billRate: number;
  mspFeesPercentage: number;
  mspFeesDollar: number;
  netBillRate: number;
  margin: number;
  finderFees?: number; // Only for Fulltime contracts
  recruiter?: Coordinator;
  lead?: Coordinator;
  manager?: Coordinator;
  seniorManager?: Coordinator;
  crm?: Coordinator;
  assoDirector?: Coordinator;
  centerHead?: Coordinator;
  marginRevisions?: MarginRevision[];
  otherName?: string;
  candidateSource?: string;
  placementType?: 'Below Manager' | 'Above Manager';
}

export interface UpdateCandidatePayload {
  id: string;
  candidateId: string;
  candidateName: string;
  clientName: string;
  contractType: 'C2C' | 'W2' | 'FULLTIME';
  startDate: string;
  endDate?: string;
  payRate: number;
  w2PayrollAdminTaxesPercentage: number;
  w2PayrollAdminTaxes: number;
  w2C2COverheadCostPercentage: number;
  w2C2COverheadCost: number;
  healthBenefits: number;
  netPurchase: number;
  billRate: number;
  mspFeesPercentage: number;
  mspFeesDollar: number;
  netBillRate: number;
  margin: number;
  finderFees?: number; // Only for Fulltime contracts
  recruiter?: Coordinator;
  lead?: Coordinator;
  manager?: Coordinator;
  seniorManager?: Coordinator;
  crm?: Coordinator;
  assoDirector?: Coordinator;
  centerHead?: Coordinator;
  marginRevisions?: MarginRevision[];
  otherName?: string;
  candidateSource?: string;
  placementType?: 'Below Manager' | 'Above Manager';
}

export interface MarginRevisionPayload {
  effectiveDate: string;
  contractType?: 'C2C' | 'W2' | 'FULLTIME';
  payRate?: number;
  w2PayrollAdminTaxesPercentage?: number;
  w2C2COverheadCostPercentage?: number;
  healthBenefits?: number;
  billRate?: number;
  mspFeesPercentage?: number;
  finderFees?: number;
  w2PayrollAdminTaxes: number;
  w2C2COverheadCost: number;
  netPurchase: number;
  mspFeesDollar: number;
  netBillRate: number;
  margin: number;
  reason?: string;
  createdAt: string;
  createdBy?: string;
}


export async function createCandidate(payload: CandidatePayload) {
  const response = await axiosClient.post('/candidates', payload);
  return response.data;
}

export async function getCandidates(): Promise<Candidate[]> {
  const response = await axiosClient.get('/candidates/list');
  return response.data;
}

export async function updateCandidate(payload: UpdateCandidatePayload) {
  const response = await axiosClient.put(`/candidates/${payload.id}`, payload);
  return response.data;
} 

export async function createMarginRevision(candidateId: string, payload: MarginRevisionPayload) {
  const response = await axiosClient.post(`/candidates/${candidateId}/margin-revisions`, payload);
  return response.data;
} 

export async function updateMarginRevision(candidateId: string, revisionId: string, payload: MarginRevisionPayload) {
  const response = await axiosClient.put(`/candidates/${candidateId}/margin-revisions/${revisionId}`, payload);
  return response.data;
}

export async function deleteCandidate(id: string) {
  const response = await axiosClient.delete(`/candidates/${id}`);
  return response.data;
} 