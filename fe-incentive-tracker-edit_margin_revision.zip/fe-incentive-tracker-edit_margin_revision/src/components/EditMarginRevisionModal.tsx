import React, { useState, useEffect } from 'react';
import { Candidate, MarginRevision } from '../types';
import { calculateMarginRevisionFields } from '../utils/calculations';
import { Save, X, TrendingUp, AlertCircle } from 'lucide-react';

interface EditMarginRevisionModalProps {
  candidate: Candidate;
  revision: MarginRevision;
  onSave: (revision: MarginRevision) => void;
  onCancel: () => void;
}

export const EditMarginRevisionModal: React.FC<EditMarginRevisionModalProps> = ({
  candidate,
  revision,
  onSave,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    effectiveDate: revision.effectiveDate,
    contractType: revision.contractType || candidate.contractType,
    payRate: revision.payRate || candidate.payRate,
    w2PayrollAdminTaxesPercentage: revision.w2PayrollAdminTaxesPercentage || candidate.w2PayrollAdminTaxesPercentage,
    w2C2COverheadCostPercentage: revision.w2C2COverheadCostPercentage || candidate.w2C2COverheadCostPercentage,
    healthBenefits: revision.healthBenefits || candidate.healthBenefits,
    billRate: revision.billRate || candidate.billRate,
    mspFeesPercentage: revision.mspFeesPercentage || candidate.mspFeesPercentage,
    finderFees: revision.finderFees || candidate.finderFees || 0,
    reason: revision.reason || ''
  });

  const [calculatedFields, setCalculatedFields] = useState(() => 
    calculateMarginRevisionFields(formData, candidate)
  );

  // Update calculated fields when form data changes
  useEffect(() => {
    setCalculatedFields(calculateMarginRevisionFields(formData, candidate));
  }, [formData, candidate]);

  const handleChange = (field: string, value: string | number) => {
    const newFormData = { ...formData, [field]: value };
    setFormData(newFormData);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const updatedRevision: MarginRevision = {
      ...revision,
      effectiveDate: formData.effectiveDate,
      contractType: formData.contractType !== candidate.contractType ? formData.contractType : undefined,
      payRate: formData.payRate !== candidate.payRate ? formData.payRate : undefined,
      w2PayrollAdminTaxesPercentage: formData.w2PayrollAdminTaxesPercentage !== candidate.w2PayrollAdminTaxesPercentage ? formData.w2PayrollAdminTaxesPercentage : undefined,
      w2C2COverheadCostPercentage: formData.w2C2COverheadCostPercentage !== candidate.w2C2COverheadCostPercentage ? formData.w2C2COverheadCostPercentage : undefined,
      healthBenefits: formData.healthBenefits !== candidate.healthBenefits ? formData.healthBenefits : undefined,
      billRate: formData.billRate !== candidate.billRate ? formData.billRate : undefined,
      mspFeesPercentage: formData.mspFeesPercentage !== candidate.mspFeesPercentage ? formData.mspFeesPercentage : undefined,
      finderFees: formData.finderFees !== (candidate.finderFees || 0) ? formData.finderFees : undefined,
      ...calculatedFields,
      reason: formData.reason
    };

    onSave(updatedRevision);
  };

  const formatDateDisplay = (dateString: string) => {
    if (!dateString) return 'No date selected';
    
    try {
      const [year, month, day] = dateString.split('-').map(Number);
      const date = new Date(year, month - 1, day);
      
      return date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        timeZone: 'America/New_York'
      });
    } catch (error) {
      return 'Invalid date';
    }
  };

  const getEffectiveMonth = (effectiveDate: string) => {
    if (!effectiveDate) return '';
    
    const [year, month, day] = effectiveDate.split('-').map(Number);
    const dayOfMonth = day;
    
    let effectiveMonth = month;
    let effectiveYear = year;
    
    // If effective date is between 11th and last day, apply from next month
    if (dayOfMonth >= 11) {
      effectiveMonth += 1;
      if (effectiveMonth > 12) {
        effectiveMonth = 1;
        effectiveYear += 1;
      }
    }
    
    return new Date(effectiveYear, effectiveMonth - 1).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long',
      timeZone: 'America/New_York'
    });
  };

  const marginChange = calculatedFields.margin - candidate.margin;
  const marginChangePercent = candidate.margin !== 0 ? (marginChange / candidate.margin) * 100 : 0;

  const isFullTime = formData.contractType === 'FULLTIME';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Edit Margin Revision</h2>
              <p className="text-sm text-gray-500">{candidate.candidateName} ({candidate.candidateId})</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Effective Date and Rules */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-blue-900 mb-2">Margin Revision Rules (EST Timezone)</h3>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• <strong>1st-10th of month:</strong> Revised margin applies to the same month</li>
                  <li>• <strong>11th-End of month:</strong> Revised margin applies from the following month</li>
                  <li>• All dates are processed in Eastern Standard Time (EST)</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Revision Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Revision Details</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Effective Date (EST)</label>
                <input
                  type="date"
                  value={formData.effectiveDate}
                  onChange={(e) => handleChange('effectiveDate', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
                {formData.effectiveDate && (
                  <div className="mt-2 space-y-1">
                    <p className="text-xs text-green-600 font-medium">
                      ✅ Selected: {formatDateDisplay(formData.effectiveDate)}
                    </p>
                    <p className="text-xs text-blue-600 font-medium">
                      📅 Applies from: {getEffectiveMonth(formData.effectiveDate)}
                    </p>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contract Type</label>
                <select
                  value={formData.contractType}
                  onChange={(e) => handleChange('contractType', e.target.value as 'C2C' | 'W2' | 'FULLTIME')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="C2C">C2C</option>
                  <option value="W2">W2</option>
                  <option value="FULLTIME">Full-Time</option>
                </select>
                {formData.contractType !== candidate.contractType && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from {candidate.contractType}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Reason for Revision</label>
                <textarea
                  value={formData.reason}
                  onChange={(e) => handleChange('reason', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                  placeholder="Explain the reason for this margin revision..."
                  required
                />
              </div>
            </div>

            {/* Current vs New Comparison */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Margin Impact</h3>
              
              {!isFullTime ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">Current Margin</p>
                      <p className="text-lg font-semibold text-gray-900">${candidate.margin.toFixed(2)}</p>
                    </div>
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="text-xs text-blue-600 uppercase tracking-wide">New Margin</p>
                      <p className="text-lg font-semibold text-blue-700">${calculatedFields.margin.toFixed(2)}</p>
                    </div>
                  </div>

                  <div className={`p-3 rounded-lg ${marginChange >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
                    <p className={`text-xs uppercase tracking-wide ${marginChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      Margin Change
                    </p>
                    <p className={`text-lg font-semibold ${marginChange >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                      {marginChange >= 0 ? '+' : ''}${marginChange.toFixed(2)} ({marginChangePercent >= 0 ? '+' : ''}{marginChangePercent.toFixed(1)}%)
                    </p>
                  </div>
                </>
              ) : (
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-purple-700 text-sm">
                    <strong>Full-Time Contract:</strong> Margin calculations are not applicable for full-time placements. 
                    Incentives are based on finder fees and placement counts.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Financial Fields - Only for non-fulltime */}
          {!isFullTime ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Pay Rate and Taxes */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Pay Rate & Taxes</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pay Rate ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.payRate}
                  onChange={(e) => handleChange('payRate', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.payRate !== candidate.payRate && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from ${candidate.payRate.toFixed(2)}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">W2 Payroll and Admin Taxes %</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.w2PayrollAdminTaxesPercentage}
                  onChange={(e) => handleChange('w2PayrollAdminTaxesPercentage', parseFloat(e.target.value) || 0)}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    formData.contractType === 'C2C' ? 'bg-gray-100' : ''
                  }`}
                  disabled={formData.contractType === 'C2C'}
                />
                {formData.w2PayrollAdminTaxesPercentage !== candidate.w2PayrollAdminTaxesPercentage && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from {candidate.w2PayrollAdminTaxesPercentage.toFixed(2)}%
                  </p>
                )}
                {formData.contractType === 'C2C' && (
                  <p className="text-xs text-gray-500 mt-1">
                    Not applicable for C2C contracts
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">W2 / C2C Overhead Cost %</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.w2C2COverheadCostPercentage}
                  onChange={(e) => handleChange('w2C2COverheadCostPercentage', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.w2C2COverheadCostPercentage !== candidate.w2C2COverheadCostPercentage && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from {candidate.w2C2COverheadCostPercentage.toFixed(2)}%
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Health Benefits ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.healthBenefits}
                  onChange={(e) => handleChange('healthBenefits', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.healthBenefits !== candidate.healthBenefits && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from ${candidate.healthBenefits.toFixed(2)}
                  </p>
                )}
              </div>
            </div>

            {/* Bill Rate and MSP */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Bill Rate & MSP</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bill Rate ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.billRate}
                  onChange={(e) => handleChange('billRate', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.billRate !== candidate.billRate && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from ${candidate.billRate.toFixed(2)}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">MSP Fees (%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.mspFeesPercentage}
                  onChange={(e) => handleChange('mspFeesPercentage', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.mspFeesPercentage !== candidate.mspFeesPercentage && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from {candidate.mspFeesPercentage.toFixed(2)}%
                  </p>
                )}
              </div>
            </div>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Full-Time Contract Details</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Finder Fees ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.finderFees}
                  onChange={(e) => handleChange('finderFees', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.finderFees !== (candidate.finderFees || 0) && (
                  <p className="text-xs text-blue-600 mt-1">
                    Changed from ${(candidate.finderFees || 0).toFixed(2)}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Calculated Fields Display - Only for non-fulltime */}
          {!isFullTime && (
            <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-900 mb-3">Calculated Values</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">W2 Payroll and Admin Taxes</p>
                <p className="text-sm font-semibold text-gray-900">${calculatedFields.w2PayrollAdminTaxes.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">W2 / C2C Overhead Cost</p>
                <p className="text-sm font-semibold text-gray-900">${calculatedFields.w2C2COverheadCost.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">Net Purchase</p>
                <p className="text-sm font-semibold text-gray-900">${calculatedFields.netPurchase.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">MSP Fees ($)</p>
                <p className="text-sm font-semibold text-gray-900">${calculatedFields.mspFeesDollar.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">Net Bill Rate</p>
                <p className="text-sm font-semibold text-gray-900">${calculatedFields.netBillRate.toFixed(2)}</p>
              </div>
            </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 border-t pt-6">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Update Revision</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
