import React, { useState, useRef } from 'react';
import { MonthlyHours, Candidate, IncentiveCycle } from '../types';
import { isCandidateMonthProcessed } from '../utils/calculations';
import { Upload, X, FileText, AlertCircle, CheckCircle, Download } from 'lucide-react';

interface FileUploadModalProps {
  cycleId: string;
  cycleMonth: string;
  candidates: Candidate[];
  approvedCycles: IncentiveCycle[];
  onSave: (cycleId: string, monthlyHours: MonthlyHours[]) => void;
  onClose: () => void;
}

interface ParsedRow {
  candidateId: string;
  candidateName?: string;
  hoursWorked: number;
  isValid: boolean;
  error?: string;
}

export const FileUploadModal: React.FC<FileUploadModalProps> = ({
  cycleId,
  cycleMonth,
  candidates,
  approvedCycles,
  onSave,
  onClose
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadStep, setUploadStep] = useState<'upload' | 'review' | 'confirm'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (selectedFile: File) => {
    if (!selectedFile.name.endsWith('.csv')) {
      alert('Please upload a CSV file');
      return;
    }

    setFile(selectedFile);
    setIsProcessing(true);

    try {
      const text = await selectedFile.text();
      const parsed = parseCSV(text);
      setParsedData(parsed);
      setUploadStep('review');
    } catch (error) {
      alert('Error reading file. Please check the file format.');
    } finally {
      setIsProcessing(false);
    }
  };

  
  const parseCSV = (csvText: string): ParsedRow[] => {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
    
    // Find column indices
    const candidateIdIndex = headers.findIndex(h => 
      h.includes('candidate') && h.includes('id') || h === 'candidateid'
    );
    const candidateNameIndex = headers.findIndex(h => 
      h.includes('candidate') && h.includes('name') || h === 'candidatename'
    );
    const hoursIndex = headers.findIndex(h => 
      h.includes('hours') || h.includes('hour') || h === 'hoursworked'
    );

    if (candidateIdIndex === -1 || hoursIndex === -1) {
      throw new Error('Required columns not found. Please ensure CSV has Candidate ID and Hours columns.');
    }

    const parsed: ParsedRow[] = [];
    
    for (let i = 1; i < lines.length; i++) {
      const row = lines[i].split(',').map(cell => cell.trim());
      
      if (row.length < Math.max(candidateIdIndex, hoursIndex) + 1) continue;
      
      const candidateId = row[candidateIdIndex];
      const candidateName = candidateNameIndex !== -1 ? row[candidateNameIndex] : undefined;
      const hoursText = row[hoursIndex];
      
      if (!candidateId || !hoursText) continue;
      
      const hoursWorked = parseFloat(hoursText);
      const candidate = candidates.find(c => c.candidateId === candidateId);
      
      let isValid = true;
      let error = '';
      
      if (!candidate) {
        isValid = false;
        error = 'Candidate ID not found in system';
      } else if (isCandidateMonthProcessed(candidateId, cycleMonth, approvedCycles)) {
        isValid = false;
        error = 'Hours already processed in approved cycle';
      } else if (isNaN(hoursWorked) || hoursWorked < 0) {
        isValid = false;
        error = 'Invalid hours value';
      } else if (hoursWorked > 744) {
        isValid = false;
        error = 'Hours exceed maximum (744)';
      }
      
      parsed.push({
        candidateId,
        candidateName: candidateName || candidate?.candidateName,
        hoursWorked,
        isValid,
        error
      });
    }
    
    return parsed;
  };

  const handleConfirm = () => {
    try {
      const validRows = parsedData.filter(row => row.isValid);
      if (validRows.length === 0) {
        alert('No valid records to import');
        return;
      }
      
      const monthlyHours: MonthlyHours[] = validRows.map(row => ({
        candidateId: row.candidateId,
        month: cycleMonth,
        hoursWorked: row.hoursWorked
      }));
      onSave(cycleId, monthlyHours);
    } catch (error) {
      console.error('Error in handleConfirm:', error);
      alert('Error processing data: ' + (error as Error).message);
    }
  };

  const downloadTemplate = () => {
    const activeCandidates = candidates.filter(c => {
      const startDate = new Date(c.startDate);
      const cycleDate = new Date(cycleMonth + '-01');
      const endDate = c.endDate ? new Date(c.endDate) : null;
      
      return startDate <= cycleDate && (!endDate || endDate >= cycleDate) &&
             !isCandidateMonthProcessed(c.candidateId, cycleMonth, approvedCycles);
    });

    const csvContent = [
      ['Candidate ID', 'Candidate Name', 'Client Name', 'Hours Worked', 'Month'],
      ...activeCandidates.map(c => [c.candidateId, c.candidateName, c.clientName, '0', cycleMonth])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hours-template-${cycleMonth}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const validCount = parsedData.filter(row => row.isValid).length;
  const invalidCount = parsedData.length - validCount;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Upload className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Upload Hours File</h2>
              <p className="text-sm text-gray-500">
                {new Date(cycleMonth + '-01').toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long' 
                })}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {uploadStep === 'upload' && (
            <div className="space-y-6">
              <div className="text-center">
                <button
                  onClick={downloadTemplate}
                  className="mb-4 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 mx-auto"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Template</span>
                </button>
                <p className="text-sm text-gray-600">
                  Download a template with active candidates for this month
                </p>
              </div>

              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive 
                    ? 'border-blue-400 bg-blue-50' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  Drop your CSV file here, or click to browse
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  CSV file with Candidate ID and Hours columns
                </p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  disabled={isProcessing}
                >
                  {isProcessing ? 'Processing...' : 'Choose File'}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileInput}
                  className="hidden"
                />
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-gray-900 mb-2">CSV Format Requirements:</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• First row should contain headers</li>
                  <li>• Required columns: "Candidate ID" and "Hours" (or similar)</li>
                  <li>• Optional: "Candidate Name" for verification</li>
                  <li>• Hours should be numeric (0-744)</li>
                  <li>• Candidate IDs must match existing candidates</li>
                </ul>
              </div>
            </div>
          )}

          {uploadStep === 'review' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Review Uploaded Data</h3>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="text-sm text-green-700">{validCount} Valid</span>
                  </div>
                  {invalidCount > 0 && (
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <span className="text-sm text-red-700">{invalidCount} Invalid</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="max-h-96 overflow-y-auto border border-gray-200 rounded-lg">
                <table className="w-full">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Status
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Candidate ID
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Candidate Name
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Hours
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Error
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {parsedData.map((row, index) => (
                      <tr key={index} className={row.isValid ? 'bg-green-50' : 'bg-red-50'}>
                        <td className="px-4 py-3 whitespace-nowrap">
                          {row.isValid ? (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-red-600" />
                          )}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                          {row.candidateId}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                          {row.candidateName || '-'}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                          {row.hoursWorked}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-red-600">
                          {row.error || '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setUploadStep('upload')}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleConfirm}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  disabled={validCount === 0}
                >
                  Import {validCount} Records
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};