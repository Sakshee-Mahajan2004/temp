import React from 'react';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';



import { IncentiveCycle, MonthlyHours, Candidate } from '../types';
import { Download, FileText, FileSpreadsheet } from 'lucide-react';

interface ExportUtilsProps {
  data: any[];
  filename: string;
  title: string;
  type: 'cycle' | 'hours' | 'legacy' | 'coordinator-summary';
  cycle?: IncentiveCycle;
  candidates?: Candidate[];
}

export const ExportUtils: React.FC<ExportUtilsProps> = ({
  data,
  filename,
  title,
  type,
  cycle,
  candidates
}) => {

  const getCordinatorType = (type: string) => {
    switch (type) {
      case 'RECRUITER':
        return 'recruiter';
      case 'CRM':
        return 'crm';
      case 'TEAM_LEAD':
        return 'teamLead';
      case 'MANAGER':
        return 'manager';
      case 'SENIOR_MANAGER':
        return 'seniorManager';
      case 'ASSO_DIRECTOR':
        return 'assoDirector';
      case 'CENTER_HEAD':
        return 'centerHead';
      default:
        return type;
    }
  }

  function capitalizeFirstLetter(str: string) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  const exportToExcel = () => {
    let worksheetData: any[][] = [];

   
    if (type === 'cycle') {
      worksheetData = [
        ['Coordinator Name', 'Coordinator Type', 'Total Incentive (INR)', 'Adjustment Amount (INR)', 'Net Amount (INR)', 'Candidate ID', 'Candidate Name', 'Month', 'Contract Type', 'Margin/Finder Fees', 'Hours/Placements', 'Incentive Amount (INR)', 'Incentive Type'],
        ...data.map((item: any) => [
          item.coordinatorName || '',
          capitalizeFirstLetter(getCordinatorType(item.coordinatorType)?.replace(/([A-Z])/g, ' $1').trim() || ''),
          (item.totalIncentive || 0).toLocaleString('en-IN'),
          (item.adjustmentAmount || 0).toLocaleString('en-IN'),
          ((item.totalIncentive || 0) + (item.adjustmentAmount || 0)).toLocaleString('en-IN'),
          item.candidateId || '',
          item.candidateName || '',
          item.month ? new Date(item.month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' }) : '',
          item.contractType || '',
          item.isFullTime ? (item.finderFees ? `$${item.finderFees.toFixed(2)}` : 'N/A') : (item.margin ? `$${item.margin.toFixed(2)}` : 'N/A'),
          item.isFullTime ? (item.placementCount || 1) : (item.hoursWorked || 0),
          (item.incentiveAmount || 0).toLocaleString('en-IN'),
          item.isFullTime ? 'Full-time' : (item.isRecurring ? 'Recurring' : 'One-time')
        ])
      ];
    } else if (type === 'coordinator-summary') {
      
      worksheetData = [
        ['Coordinator Name', 'Role', 'Total Incentive (INR)', 'Placements', 'Candidates', 'Average per Placement (INR)'],
        ...data.map((item: any) => {
          const cType =  getCordinatorType(item.type);
          return [
          item.name || '',
          capitalizeFirstLetter(cType?.replace(/([A-Z])/g, ' $1').trim() || ''),
          (item.totalIncentive || 0).toLocaleString('en-IN'),
          item.placements || 0,
          item.candidateCount || 0,
          ((item.totalIncentive || 0) / (item.placements || 1)).toLocaleString('en-IN')
        ]})
      ];
    } else if (type === 'hours') {
      worksheetData = [
        ['Candidate ID', 'Candidate Name', 'Client Name', 'Contract Type', 'Month', 'Hours Worked', 'Is Retroactive', 'Finder Fees'],
        ...data.map((item: any) => {
          const candidate = candidates?.find(c => c.candidateId === item.candidateId);
          return [
            item.candidateId || '',
            candidate?.candidateName || '',
            candidate?.clientName || '',
            candidate?.contractType || '',
            new Date(item.month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' }),
            item.hoursWorked || 0,
            item.isRetroactive ? 'Yes' : 'No',
            candidate?.contractType === 'FULLTIME' ? (candidate.finderFees ? `$${candidate.finderFees.toFixed(2)}` : 'N/A') : 'N/A'
          ];
        })
      ];
    } else {
      worksheetData = [
        ['Coordinator Name', 'Type', 'Candidate', 'Month', 'Hours', 'Margin', 'Incentive Amount (INR)', 'Notes'],
        ...data.map((item: any) => [
          item.coordinatorName || '',
          capitalizeFirstLetter(getCordinatorType(item.coordinatorType)?.replace(/([A-Z])/g, ' $1').trim() || ''),
          item.candidateName || '',
          item.month ? new Date(item.month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' }) : '',
          item.hoursWorked || 0,
          item.margin ? `$${item.margin.toFixed(2)}` : 'N/A',
          (item.incentiveAmount || 0).toLocaleString('en-IN'),
          item.notes || ''
        ])
      ];
    }

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');
    
    // Auto-size columns
    const colWidths = worksheetData[0].map((_, colIndex) => {
      const maxLength = Math.max(
        ...worksheetData.map(row => (row[colIndex] || '').toString().length)
      );
      return { wch: Math.min(Math.max(maxLength + 2, 10), 50) };
    });
    worksheet['!cols'] = colWidths;

    XLSX.writeFile(workbook, `${filename}.xlsx`);
  };

  const exportToPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4'); // Landscape orientation
    
    doc.setFontSize(16);
    doc.text(title, 14, 20);
    
    if (cycle) {
      doc.setFontSize(10);
      doc.text(`Cycle: ${new Date(cycle.month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}`, 14, 30);
      doc.text(`Status: ${cycle.status.charAt(0).toUpperCase() + cycle.status.slice(1)}`, 14, 36);
      doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 42);
    }

    let tableData: any[][] = [];
    let headers: string[] = [];

    if (type === 'cycle') {
      headers = ['Coordinator', 'Type', 'Candidate', 'Month', 'Contract', 'Margin/Fees', 'Hours/Placements', 'Incentive'];
      tableData = data.map((item: any) => [
        item.coordinatorName || '',
        capitalizeFirstLetter(getCordinatorType(item.coordinatorType).replace(/([A-Z])/g, ' $1').trim() || ''),
        item.candidateName || '',
        item.month ? new Date(item.month + '-01').toLocaleDateString('en-US', { month: 'short', year: '2-digit' }) : '',
        item.contractType || '',
        item.isFullTime ? (item.finderFees ? `$${item.finderFees.toFixed(0)}` : 'N/A') : (item.margin ? `$${item.margin.toFixed(2)}` : 'N/A'),
        item.isFullTime ? (item.placementCount || 1) : (item.hoursWorked || 0),
        (item.incentiveAmount || 0).toLocaleString('en-IN')
      ]);
    } else if (type === 'coordinator-summary') {
      headers = ['Coordinator', 'Role', 'Total Incentive', 'Placements', 'Candidates', 'Avg/Placement'];
      tableData = data.map((item: any) =>[
        item.name || '',
        capitalizeFirstLetter(getCordinatorType(item.type)?.replace(/([A-Z])/g, ' $1').trim() || ''),
        (item.totalIncentive || 0).toLocaleString('en-IN'),
        item.placements || 0,
        item.candidateCount || 0,
        ((item.totalIncentive || 0) / (item.placements || 1)).toLocaleString('en-IN')
      ]);
    } else if (type === 'hours') {
      headers = ['Candidate ID', 'Name', 'Client', 'Month', 'Hours', 'Retroactive'];
      tableData = data.map((item: any) => {
        const candidate = candidates?.find(c => c.candidateId === item.candidateId);
        return [
          item.candidateId || '',
          candidate?.candidateName || '',
          candidate?.clientName || '',
          new Date(item.month + '-01').toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
          item.hoursWorked || 0,
          item.isRetroactive ? 'Yes' : 'No'
        ];
      });
    } else {
      headers = ['Coordinator', 'Type', 'Candidate', 'Month', 'Hours', 'Incentive'];
      tableData = data.map((item: any) => [
        item.coordinatorName || '',
        capitalizeFirstLetter(getCordinatorType(item.coordinatorType)?.replace(/([A-Z])/g, ' $1').trim() || ''),
        item.candidateName || '',
        item.month ? new Date(item.month + '-01').toLocaleDateString('en-US', { month: 'short', year: '2-digit' }) : '',
        item.hoursWorked || 0,
        (item.incentiveAmount || 0).toLocaleString('en-IN')
      ]);
    }

    (doc as any).autoTable({
      head: [headers],
      body: tableData,
      startY: cycle ? 50 : 30,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [59, 130, 246] },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      margin: { top: 20, right: 14, bottom: 20, left: 14 },
    });

    doc.save(`${filename}.pdf`);
  };

  return (
    <div className="flex items-center space-x-2">
      <button
        onClick={exportToExcel}
        className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
      >
        <FileSpreadsheet className="w-4 h-4" />
        <span>Excel</span>
      </button>
      <button
        onClick={exportToPDF}
        className="flex items-center space-x-2 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
      >
        <FileText className="w-4 h-4" />
        <span>PDF</span>
      </button>
    </div>
  );
};