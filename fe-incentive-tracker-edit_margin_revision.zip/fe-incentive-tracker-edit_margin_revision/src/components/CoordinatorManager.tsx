import React, { useEffect, useState } from 'react';
import { Coordinator } from '../types';
import { UserCheck, Plus, Edit, Trash2, Mail, User, X, Save, MapPin } from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { createCoordinator, CoordinatorPayload, getCoordinators, updateCoordinator, UpdateCoordinatorPayload, deleteCoordinator } from '../network/coordinatorApi';

interface CoordinatorManagerProps {
  coordinators: Coordinator[];
  onSave: (coordinators: Coordinator[]) => void;
}

interface CoordinatorFormData {
  name: string;
  email: string;
  location: string;
  status: 'ACTIVE' | 'NOTICE_PERIOD' | 'LEFT';
  activeFrom: string; // ISO string
  employeeId: string;
  bankName: string;
  ifscCode: string;
  accountNumber: string;
}

export const CoordinatorManager: React.FC<CoordinatorManagerProps> = ({
  coordinators,
  onSave
}) => {
  const [showForm, setShowForm] = useState(false);
  const [editingCoordinator, setEditingCoordinator] = useState<Coordinator | null>(null);
  const [formData, setFormData] = useState<CoordinatorFormData>({
    name: '',
    email: '',
    location: '',
    status: 'ACTIVE',
    activeFrom: '',
    employeeId: '',
    bankName: '',
    ifscCode: '',
    accountNumber: '',
  });

  // Helper function to get current EST date
  const getESTDate = () => {
    const now = new Date();
    // Convert to EST (UTC-5) or EDT (UTC-4) depending on daylight saving time
    const estOffset = -5; // EST is UTC-5
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const est = new Date(utc + (estOffset * 3600000));
    return est;
  };

  const { data: coordinators1, isLoading, error, refetch } = useQuery({
    queryKey: ['coordinators'],
    queryFn: getCoordinators,
  });


  const mutation = useMutation({
    mutationFn: (payload: CoordinatorPayload) => createCoordinator(payload),
    onSuccess: (data) => {
      // Handle success - maybe refetch coordinators list
      refetch();
      // You might want to refetch the coordinators list here
    },
    onError: (error) => {
      console.error('Error creating coordinator:', error);
      alert('Failed to create coordinator');
    }
  });

  const updateMutation = useMutation({
    mutationFn: (payload: UpdateCoordinatorPayload) => updateCoordinator(payload),
    onSuccess: (data) => {
      // Optionally refetch the coordinators list or show a success message
      refetch();
      // refetch(); // if you use useQuery for the list
    },
    onError: (error) => {
      alert('Failed to update coordinator');
      console.error(error);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteCoordinator(id),
    onSuccess: () => {
      // Optionally refetch the coordinators list or show a success message
      refetch();
    },
    onError: (error) => {
      alert('Cannot delete coordinator: This coordinator is assigned to one or more candidates. Please reassign or remove those candidates before deleting the coordinator.');
      console.error(error);
    }
  });

  useEffect(() => {
    if (coordinators1) {
      onSave(coordinators1);
    }
  }, [coordinators1]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingCoordinator) {
      const payload: UpdateCoordinatorPayload = {
        id: editingCoordinator?.id,
        name: formData.name,
        email: formData.email,
        location: formData.location,
        status: formData.status,
        activeFrom: formData.status === 'ACTIVE' ? formData.activeFrom : undefined,
        employeeId: formData.employeeId,
        bankName: formData.bankName,
        ifscCode: formData.ifscCode,
        bankAccountNumber: formData.accountNumber,
        effectiveDate: formData.activeFrom
      } as any;
      updateMutation.mutate(payload)
    } else {
      const payload: CoordinatorPayload = {
        name: formData.name,
        email: formData.email,
        location: formData.location,
        status: formData.status,
        activeFrom: formData.status === 'ACTIVE' ? formData.activeFrom : undefined,
        employeeId: formData.employeeId,
        bankName: formData.bankName,
        ifscCode: formData.ifscCode,
        bankAccountNumber: formData.accountNumber,
        ...(formData.activeFrom ? { effectiveDate: formData.activeFrom } : {})
      } as any;
      mutation.mutate(payload);
    }

    // TODO : Need to remove it once API integration is done

    // const coordinatorData: Coordinator = {
    //   id: editingCoordinator?.id || `coord-${Date.now()}`,
    //   name: formData.name,
    //   email: formData.email,
    //   location: formData.location,
    //   createdAt: editingCoordinator?.createdAt || getESTDate().toISOString()
    // };

    // if (editingCoordinator) {
    //   onSave(coordinators.map(c => c.id === coordinatorData.id ? coordinatorData : c));
    // } else {
    //   onSave([...coordinators, coordinatorData]);
    // }

    setShowForm(false);
    setEditingCoordinator(null);
    setFormData({ name: '', email: '', location: '', status: 'ACTIVE', activeFrom: '', employeeId: '', bankName: '', ifscCode: '', accountNumber: '' });
  };

  const handleEdit = (coordinator: Coordinator) => {
    setEditingCoordinator(coordinator);
    setFormData({
      name: coordinator.name,
      email: coordinator.email,
      location: coordinator.location,
      status: (coordinator.status as 'ACTIVE' | 'NOTICE_PERIOD' | 'LEFT') || 'NOTICE_PERIOD',
      activeFrom: coordinator.activeFrom || '',
      employeeId: coordinator.employeeId || '',
      bankName: coordinator.bankName || '',
      ifscCode: coordinator.ifscCode || '',
      accountNumber: coordinator.accountNumber || ''
    });
    setShowForm(true);
  };

  const handleDelete = (coordinatorId: string) => {
    if (window.confirm('Are you sure you want to delete this coordinator?')) {
      deleteMutation.mutate(coordinatorId)
      // onSave(coordinators.filter(c => c.id !== coordinatorId));
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingCoordinator(null);
    setFormData({ name: '', email: '', location: '', status: 'ACTIVE', activeFrom: '', employeeId: '', bankName: '', ifscCode: '', accountNumber: '' });
  };

  const formatESTDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric'
    });
  };

  if (isLoading) return <div>Loading coordinators...</div>;
  if (error) return <div>Error loading coordinators</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Coordinator Management</h2>
          <p className="text-gray-600">Manage coordinator information and email addresses for incentive reports</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Coordinator</span>
        </button>
      </div>

      {/* Coordinator List */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Coordinators</h3>
          <p className="text-sm text-gray-500 mt-1">
            All times are displayed in Eastern Standard Time (EST)
          </p>
        </div>

        {coordinators.length === 0 ? (
          <div className="text-center py-12">
            <UserCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Coordinators</h3>
            <p className="text-gray-500">Add coordinators to enable email reports for incentive cycles.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Location
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Added (EST)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {coordinators.map((coordinator) => (
                  <tr key={coordinator.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <User className="w-5 h-5 text-gray-400 mr-3" />
                        <div className="font-medium text-gray-900">{coordinator.name}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Mail className="w-4 h-4 text-gray-400 mr-2" />
                        <div className="text-gray-900">{coordinator.email}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 text-gray-400 mr-2" />
                        <div className="text-gray-900">{coordinator.location}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-block px-2 py-1 rounded text-xs font-semibold bg-gray-100 text-gray-700">
                        {(() => {
                          switch (coordinator.status) {
                            case 'ACTIVE': return 'Active';
                            case 'NOTICE_PERIOD': return 'Notice Period';
                            case 'LEFT': return 'Left';
                            default: return 'Active';
                          }
                        })()}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {formatESTDate(coordinator.createdAt || getESTDate().toISOString())}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleEdit(coordinator)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit Coordinator"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(coordinator.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Coordinator"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Coordinator Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-8">
          <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-2xl overflow-y-auto max-h-[90vh]">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingCoordinator ? 'Edit Coordinator' : 'Add New Coordinator'}
              </h3>
              <button
                onClick={handleCancel}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter coordinator name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="coordinator@company.com"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  This email will receive incentive reports when cycles are approved
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., New York, London, Mumbai"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Employee ID</label>
                <input
                  type="text"
                  value={formData.employeeId}
                  onChange={e => setFormData(prev => ({ ...prev, employeeId: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., EMP12345"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
                <input
                  type="text"
                  value={formData.bankName}
                  onChange={e => setFormData(prev => ({ ...prev, bankName: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., HDFC Bank"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">IFSC Code</label>
                <input
                  type="text"
                  value={formData.ifscCode}
                  onChange={e => setFormData(prev => ({ ...prev, ifscCode: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., HDFC0001234"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
                <input
                  type="text"
                  value={formData.accountNumber}
                  onChange={e => setFormData(prev => ({ ...prev, accountNumber: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., 1234567890"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={formData.status}
                  onChange={e => setFormData(prev => ({ ...prev, status: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="ACTIVE">Active</option>
                  <option value="NOTICE_PERIOD">Notice Period</option>
                  <option value="LEFT">Left</option>
                </select>
              </div>


              {(formData.status === 'NOTICE_PERIOD' || formData.status === 'LEFT') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Effective Date</label>
                  <input
                    type="date"
                    value={formData.activeFrom}
                    onChange={e => setFormData(prev => ({ ...prev, activeFrom: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              )}

              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-700">
                  <strong>Note:</strong> Coordinators can have multiple roles (CRM, Manager, etc.)
                  assigned to different candidates. The role is determined by the candidate's assignment.<br />
                  {/* If status is Notice Period or Left, this coordinator will not be considered for incentive. */}
                </p>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Coordinator</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};