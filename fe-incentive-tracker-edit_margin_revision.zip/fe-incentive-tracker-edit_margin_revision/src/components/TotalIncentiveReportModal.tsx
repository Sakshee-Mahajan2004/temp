import React from 'react';
import { IncentiveCycle, Candidate } from '../types';
import { formatCurrencyForReport } from '../utils/calculations';
import { ExportUtils } from './ExportUtils';
import { X, Users, DollarSign, TrendingUp, MapPin } from 'lucide-react';

interface TotalIncentiveReportModalProps {
  cycle: IncentiveCycle;
  candidates: Candidate[];
  onClose: () => void;
}

export const TotalIncentiveReportModal: React.FC<TotalIncentiveReportModalProps> = ({
  cycle,
  candidates,
  onClose
}) => {
  const formatMonth = (month: string) => {
    const [year, monthNum] = month.split('-');
    return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };

  const getCoordinatorSummary = () => {
    const summary = new Map();
    
    cycle.incentiveCalculations.forEach(calc => {
      const key = calc.coordinatorName;
      if (!summary.has(key)) {
        summary.set(key, {
          name: calc.coordinatorName,
          type: calc.coordinatorType,
          totalIncentive: 0,
          placements: 0,
          candidates: new Set(),
          details: []
        });
      }

      

      
      const coord = summary.get(key);
      coord.totalIncentive += calc.incentiveAmount;
      coord.placements += 1;
      coord.candidates.add(calc.candidateId);
      coord.details.push(calc);
    });

    return Array.from(summary.values()).map(coord => ({
      ...coord,
      candidateCount: coord.candidates.size
    }));
  };

  const getCordinatorType = (type: string) => {
    switch (type) {
      case 'RECRUITER':
        return 'recruiter';
      case 'CRM':
        return 'crm';
      case 'TEAM_LEAD':
        return 'teamLead';
      case 'MANAGER':
        return 'manager';
      case 'SENIOR_MANAGER':
        return 'seniorManager';
      case 'ASSO_DIRECTOR':
        return 'assoDirector';
      case 'CENTER_HEAD':
        return 'centerHead';
      default:
        return type;
    }
  }


  const coordinatorSummary = getCoordinatorSummary();
  const totalIncentives = cycle.incentiveCalculations.reduce((sum, calc) => sum + calc.incentiveAmount, 0);
  const totalAdjustments = cycle.incentiveAdjustments?.reduce((sum, adj) => 
    sum + (adj.adjustmentType === 'shortfall' ? adj.adjustmentAmount : -adj.adjustmentAmount), 0) || 0;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Total Incentive Report</h2>
              <p className="text-sm text-gray-500">
                {formatMonth(cycle.month)} • {cycle.type === 'additional' ? 'Additional' : 'Regular'} Cycle
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <ExportUtils
              data={coordinatorSummary}
              filename={`total-incentive-report-${cycle.month}`}
              title={`Total Incentive Report - ${formatMonth(cycle.month)}`}
              type="coordinator-summary"
              cycle={cycle}
              candidates={candidates}
            />
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 text-sm font-medium">Total Incentives</p>
                  <p className="text-2xl font-bold text-blue-900">{formatCurrencyForReport(totalIncentives)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600 text-sm font-medium">Adjustments</p>
                  <p className={`text-2xl font-bold ${totalAdjustments >= 0 ? 'text-green-900' : 'text-red-900'}`}>
                    {totalAdjustments >= 0 ? '+' : ''}{formatCurrencyForReport(totalAdjustments)}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-600 text-sm font-medium">Net Total</p>
                  <p className="text-2xl font-bold text-purple-900">
                    {formatCurrencyForReport(totalIncentives + totalAdjustments)}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
            </div>

            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-600 text-sm font-medium">Coordinators</p>
                  <p className="text-2xl font-bold text-orange-900">{coordinatorSummary.length}</p>
                </div>
                <Users className="w-8 h-8 text-orange-600" />
              </div>
            </div>
          </div>

          {/* Coordinator Summary Table */}
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
              <h3 className="text-lg font-semibold text-gray-900">Coordinator-wise Breakdown</h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Coordinator
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Role
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total Incentive
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Placements
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Candidates
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Avg per Placement
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {coordinatorSummary
                    .filter(coord => coord.totalIncentive > 0)
                    .sort((a, b) => b.totalIncentive - a.totalIncentive)
                    .map((coord, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Users className="w-5 h-5 text-gray-400 mr-3" />
                          <div className="font-medium text-gray-900">{coord.name}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                          {getCordinatorType(coord.type).replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-lg font-semibold text-green-600">
                          {formatCurrencyForReport(coord.totalIncentive)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                        {coord.placements}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                        {coord.candidateCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                        {formatCurrencyForReport(coord.totalIncentive / coord.placements)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Breakdown */}
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
              <h3 className="text-lg font-semibold text-gray-900">Detailed Breakdown</h3>
            </div>
            
            <div className="overflow-x-auto max-h-96">
              <table className="w-full">
                <thead className="bg-gray-50 sticky top-0">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Coordinator
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Candidate
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Contract Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Company Source
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Hours/Placements
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Margin/Finder Fees
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Incentive
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cycle.incentiveCalculations
                    .filter(calc => calc.incentiveAmount > 0)
                    .sort((a, b) => b.incentiveAmount - a.incentiveAmount)
                    .map((calc, index) => {
                      const candidate = candidates.find(c => c.candidateId === calc.candidateId);
                      return (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="font-medium text-gray-900">{calc.coordinatorName}</div>
                            <div className="text-sm text-gray-500 capitalize">
                              {getCordinatorType(calc.coordinatorType).replace(/([A-Z])/g, ' $1').trim()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-gray-900">{calc.candidateName}</div>
                            <div className="text-sm text-gray-500">{calc.candidateId}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              candidate?.contractType === 'FULLTIME' 
                                ? 'bg-purple-100 text-purple-800'
                                : candidate?.contractType === 'W2'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-green-100 text-green-800'
                            }`}>
                              {candidate?.contractType || 'Unknown'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <span className="text-gray-900">{candidate?.candidateSource || 'N/A'}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                            {calc.isFullTime ? (calc.placementCount || 1) : calc.hoursWorked}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                            {calc.isFullTime 
                              ? (calc.finderFees ? `$${calc.finderFees.toFixed(2)}` : 'N/A')
                              : `$${calc.margin.toFixed(2)}`
                            }
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="font-semibold text-green-600">
                              {formatCurrencyForReport(calc.incentiveAmount)}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              calc.isFullTime
                                ? 'bg-purple-100 text-purple-800'
                                : calc.isRecurring 
                                ? 'bg-blue-100 text-blue-800' 
                                : 'bg-orange-100 text-orange-800'
                            }`}>
                              {calc.isFullTime ? 'Full-time' : (calc.isRecurring ? 'Recurring' : 'One-time')}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Adjustments Section */}
          {cycle.incentiveAdjustments && cycle.incentiveAdjustments.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h3 className="text-lg font-semibold text-gray-900">Incentive Adjustments</h3>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Coordinator
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Candidate
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Affected Month
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Adjustment Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Amount
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {cycle.incentiveAdjustments.map((adjustment, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="font-medium text-gray-900">{adjustment.coordinatorName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-gray-900">{adjustment.candidateName}</div>
                          <div className="text-sm text-gray-500">{adjustment.candidateId}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                          {formatMonth(adjustment.affectedMonth)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            adjustment.adjustmentType === 'shortfall' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {adjustment.adjustmentType === 'shortfall' ? 'Additional Payment' : 'Overpayment'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className={`font-semibold ${
                            adjustment.adjustmentType === 'shortfall' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {adjustment.adjustmentType === 'shortfall' ? '+' : '-'}{formatCurrencyForReport(adjustment.adjustmentAmount)}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};