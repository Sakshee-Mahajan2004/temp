import React, { useState, useMemo } from 'react';
import { Candidate, MarginRevision } from '../types';
import { X, TrendingUp, Calendar, User, DollarSign, Filter, Eye, Download, Search, Edit } from 'lucide-react';
import { ExportUtils } from './ExportUtils';

interface MarginRevisionsModalProps {
  candidates: Candidate[];
  onClose: () => void;
  onEditRevision?: (candidate: Candidate, revision: MarginRevision) => void;
}

interface ReportRow {
  candidateId: string;
  candidateName: string;
  clientName: string;
  contractType: string;
  revisionDate: string;
  effectiveDate: string;
  effectiveMonth: string;
  reason: string;
  oldMargin: number;
  newMargin: number;
  marginChange: number;
  marginChangePercent: number;
  oldPayRate?: number;
  newPayRate?: number;
  oldBillRate?: number;
  newBillRate?: number;
  oldFinderFees?: number;
  newFinderFees?: number;
  createdBy?: string;
}

export const MarginRevisionsModal: React.FC<MarginRevisionsModalProps> = ({
  candidates,
  onClose,
  onEditRevision
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCandidate, setSelectedCandidate] = useState('');
  const [dateRange, setDateRange] = useState({ from: '', to: '' });
  const [sortBy, setSortBy] = useState<'date' | 'candidate' | 'change'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const reportData = useMemo(() => {
    const rows: ReportRow[] = [];
    
    candidates.forEach(candidate => {
      if (!candidate.marginRevisions || candidate.marginRevisions.length === 0) return;
      
      // Sort revisions by effective date
      const sortedRevisions = [...candidate.marginRevisions].sort((a, b) => 
        new Date(a.effectiveDate).getTime() - new Date(b.effectiveDate).getTime()
      );
      
      sortedRevisions.forEach((revision, index) => {
        const revisionDate = new Date(revision.effectiveDate);
        const revisionDay = revisionDate.getDate();
        
        let effectiveMonth: string;
        if (revisionDay <= 10) {
          effectiveMonth = revision.effectiveDate.substring(0, 7);
        } else {
          const nextMonth = new Date(revisionDate);
          nextMonth.setMonth(nextMonth.getMonth() + 1);
          effectiveMonth = nextMonth.toISOString().substring(0, 7);
        }
        
        // Get previous margin (either from previous revision or original candidate margin)
        const previousMargin = index === 0 ? candidate.margin : sortedRevisions[index - 1].margin;
        const marginChange = revision.margin - previousMargin;
        const marginChangePercent = previousMargin !== 0 ? (marginChange / previousMargin) * 100 : 0;
        
        rows.push({
          candidateId: candidate.candidateId,
          candidateName: candidate.candidateName,
          clientName: candidate.clientName,
          contractType: candidate.contractType,
          revisionDate: revision.createdAt,
          effectiveDate: revision.effectiveDate,
          effectiveMonth,
          reason: revision.reason || 'No reason provided',
          oldMargin: previousMargin,
          newMargin: revision.margin,
          marginChange,
          marginChangePercent,
          oldPayRate: index === 0 ? candidate.payRate : sortedRevisions[index - 1].payRate,
          newPayRate: revision.payRate,
          oldBillRate: index === 0 ? candidate.billRate : sortedRevisions[index - 1].billRate,
          newBillRate: revision.billRate,
          oldFinderFees: index === 0 ? candidate.finderFees : sortedRevisions[index - 1].finderFees,
          newFinderFees: revision.finderFees,
          createdBy: revision.createdBy || 'Unknown'
        });
      });
    });
    
    return rows;
  }, [candidates]);

  const filteredData = useMemo(() => {
    let filtered = reportData;
    
    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(row => 
        row.candidateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.candidateId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.reason.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Candidate filter
    if (selectedCandidate) {
      filtered = filtered.filter(row => row.candidateId === selectedCandidate);
    }
    
    // Date range filter
    if (dateRange.from) {
      filtered = filtered.filter(row => row.effectiveDate >= dateRange.from);
    }
    if (dateRange.to) {
      filtered = filtered.filter(row => row.effectiveDate <= dateRange.to);
    }
    
    // Sort
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'date':
          comparison = new Date(a.effectiveDate).getTime() - new Date(b.effectiveDate).getTime();
          break;
        case 'candidate':
          comparison = a.candidateName.localeCompare(b.candidateName);
          break;
        case 'change':
          comparison = Math.abs(a.marginChange) - Math.abs(b.marginChange);
          break;
      }
      
      return sortOrder === 'desc' ? -comparison : comparison;
    });
    
    return filtered;
  }, [reportData, searchTerm, selectedCandidate, dateRange, sortBy, sortOrder]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      timeZone: 'America/New_York'
    });
  };

  const formatMonth = (month: string) => {
    const [year, monthNum] = month.split('-');
    return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };

  const formatCurrency = (amount: number) => `$${amount.toFixed(2)}`;

  const uniqueCandidates = useMemo(() => {
    const candidatesWithRevisions = candidates.filter(c => 
      c.marginRevisions && c.marginRevisions.length > 0
    );
    return candidatesWithRevisions.map(c => ({ 
      id: c.candidateId, 
      name: c.candidateName 
    })).sort((a, b) => a.name.localeCompare(b.name));
  }, [candidates]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCandidate('');
    setDateRange({ from: '', to: '' });
  };

  const exportData = filteredData.map(row => ({
    'Candidate ID': row.candidateId,
    'Candidate Name': row.candidateName,
    'Client Name': row.clientName,
    'Contract Type': row.contractType,
    'Revision Date': formatDate(row.revisionDate),
    'Effective Date': formatDate(row.effectiveDate),
    'Effective Month': formatMonth(row.effectiveMonth),
    'Reason': row.reason,
    'Old Margin': formatCurrency(row.oldMargin),
    'New Margin': formatCurrency(row.newMargin),
    'Margin Change': formatCurrency(row.marginChange),
    'Change %': `${row.marginChangePercent.toFixed(1)}%`,
    'Old Pay Rate': row.oldPayRate ? formatCurrency(row.oldPayRate) : 'N/A',
    'New Pay Rate': row.newPayRate ? formatCurrency(row.newPayRate) : 'N/A',
    'Old Bill Rate': row.oldBillRate ? formatCurrency(row.oldBillRate) : 'N/A',
    'New Bill Rate': row.newBillRate ? formatCurrency(row.newBillRate) : 'N/A',
    'Created By': row.createdBy
  }));

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-7xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Margin Revisions Report</h2>
              <p className="text-sm text-gray-500">
                Detailed view of all margin revisions • {filteredData.length} of {reportData.length} revisions
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <ExportUtils
              data={exportData}
              filename={`margin-revisions-report-${new Date().toISOString().split('T')[0]}`}
              title="Margin Revisions Report"
              type="legacy"
            />
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Filters */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Filter className="w-5 h-5 text-gray-600" />
                <h3 className="text-lg font-medium text-gray-900">Filters & Search</h3>
              </div>
              <button
                onClick={clearFilters}
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                Clear All Filters
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Search */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Search candidates, clients, reasons..."
                  />
                </div>
              </div>

              {/* Candidate Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Candidate</label>
                <select
                  value={selectedCandidate}
                  onChange={(e) => setSelectedCandidate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">All Candidates</option>
                  {uniqueCandidates.map(candidate => (
                    <option key={candidate.id} value={candidate.id}>
                      {candidate.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date Range */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                <input
                  type="date"
                  value={dateRange.from}
                  onChange={(e) => setDateRange(prev => ({ ...prev, from: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                <input
                  type="date"
                  value={dateRange.to}
                  onChange={(e) => setDateRange(prev => ({ ...prev, to: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Sort Options */}
            <div className="flex items-center space-x-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'date' | 'candidate' | 'change')}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="date">Effective Date</option>
                  <option value="candidate">Candidate Name</option>
                  <option value="change">Margin Change</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Order</label>
                <select
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as 'asc' | 'desc')}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="desc">Descending</option>
                  <option value="asc">Ascending</option>
                </select>
              </div>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 text-sm font-medium">Total Revisions</p>
                  <p className="text-2xl font-bold text-blue-900">{filteredData.length}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600 text-sm font-medium">Margin Increases</p>
                  <p className="text-2xl font-bold text-green-900">
                    {filteredData.filter(row => row.marginChange > 0).length}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
            </div>

            <div className="bg-red-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-600 text-sm font-medium">Margin Decreases</p>
                  <p className="text-2xl font-bold text-red-900">
                    {filteredData.filter(row => row.marginChange < 0).length}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-red-600" />
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-600 text-sm font-medium">Candidates Affected</p>
                  <p className="text-2xl font-bold text-purple-900">
                    {new Set(filteredData.map(row => row.candidateId)).size}
                  </p>
                </div>
                <User className="w-8 h-8 text-purple-600" />
              </div>
            </div>
          </div>

          {/* Revisions Table */}
          {filteredData.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
              <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Margin Revisions Found</h3>
              <p className="text-gray-500">
                {reportData.length === 0 
                  ? 'No margin revisions have been created yet.'
                  : 'No revisions match your current filters. Try adjusting your search criteria.'
                }
              </p>
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Candidate
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Effective Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Effective Month
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Margin Change
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Rate Changes
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Reason
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created
                      </th>
                      {onEditRevision && (
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredData.map((row, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="font-medium text-gray-900">{row.candidateName}</div>
                            <div className="text-sm text-gray-500">{row.candidateId}</div>
                            <div className="text-sm text-gray-500">{row.clientName}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {formatDate(row.effectiveDate)}
                              </div>
                              <div className="text-xs text-gray-500">
                                {row.contractType}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                            {formatMonth(row.effectiveMonth)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm text-gray-500">
                              {formatCurrency(row.oldMargin)} → {formatCurrency(row.newMargin)}
                            </div>
                            <div className={`text-sm font-medium ${
                              row.marginChange >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {row.marginChange >= 0 ? '+' : ''}{formatCurrency(row.marginChange)} 
                              ({row.marginChangePercent >= 0 ? '+' : ''}{row.marginChangePercent.toFixed(1)}%)
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-xs space-y-1">
                            {row.contractType === 'Fulltime' ? (
                              row.newFinderFees !== row.oldFinderFees && (
                                <div>
                                  <span className="text-gray-500">Finder Fees:</span>
                                  <span className="ml-1">
                                    {formatCurrency(row.oldFinderFees || 0)} → {formatCurrency(row.newFinderFees || 0)}
                                  </span>
                                </div>
                              )
                            ) : (
                              <>
                                {row.newPayRate !== row.oldPayRate && (
                                  <div>
                                    <span className="text-gray-500">Pay:</span>
                                    <span className="ml-1">
                                      {formatCurrency(row.oldPayRate || 0)} → {formatCurrency(row.newPayRate || 0)}
                                    </span>
                                  </div>
                                )}
                                {row.newBillRate !== row.oldBillRate && (
                                  <div>
                                    <span className="text-gray-500">Bill:</span>
                                    <span className="ml-1">
                                      {formatCurrency(row.oldBillRate || 0)} → {formatCurrency(row.newBillRate || 0)}
                                    </span>
                                  </div>
                                )}
                              </>
                            )}
                            {!((row.contractType === 'Fulltime' && row.newFinderFees !== row.oldFinderFees) ||
                               (row.contractType !== 'Fulltime' && (row.newPayRate !== row.oldPayRate || row.newBillRate !== row.oldBillRate))) && (
                              <span className="text-gray-400">No rate changes</span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900 max-w-xs truncate" title={row.reason}>
                            {row.reason}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-500">
                            {formatDate(row.revisionDate)}
                          </div>
                          <div className="text-xs text-gray-400">
                            by {row.createdBy}
                          </div>
                        </td>
                        {onEditRevision && (
                          <td className="px-6 py-4 whitespace-nowrap">
                            <button
                              onClick={() => {
                                const candidate = candidates.find(c => c.candidateId === row.candidateId);
                                // Find revision by matching the effective date and creation date
                                const revision = candidate?.marginRevisions?.find(r => 
                                  r.effectiveDate === row.effectiveDate && 
                                  r.createdAt === row.revisionDate
                                );
                                if (candidate && revision && onEditRevision) {
                                  onEditRevision(candidate, revision);
                                }
                              }}
                              className="inline-flex items-center px-3 py-1 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            >
                              <Edit className="w-4 h-4 mr-1" />
                              Edit
                            </button>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};