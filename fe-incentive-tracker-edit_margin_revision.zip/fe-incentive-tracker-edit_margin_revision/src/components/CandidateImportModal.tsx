import React, { useState, useRef } from 'react';
import { Candidate, Coordinator } from '../types';
import { calculateCandidateFields } from '../utils/calculations';
import { Upload, X, FileText, AlertCircle, CheckCircle, Download } from 'lucide-react';

interface CandidateImportModalProps {
  onSave: (candidates: Candidate[]) => void;
  onCancel: () => void;
  coordinators: Coordinator[]; // <-- Add coordinators prop
}

interface ParsedCandidate {
  candidateId: string;
  candidateName: string;
  clientName: string;
  contractType: string; // <-- Add contractType
  startDate: string;
  endDate?: string;
  payRate: number;
  w2PayrollAdminTaxesPercentage: number;
  w2C2COverheadCostPercentage: number;
  healthBenefits: number;
  billRate: number;
  mspFeesPercentage: number;
  crm: string;
  lead: string;
  manager: string;
  seniorManager: string;
  assoDirector: string;
  centerHead: string;
  recruiter?: string;
  placementType?: string;
  isValid: boolean;
  error?: string;
  [key: string]: any; // allow dynamic access for team member fields
}

export const CandidateImportModal: React.FC<CandidateImportModalProps> = ({
  onSave,
  onCancel,
  coordinators // <-- Accept coordinators
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedCandidate[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadStep, setUploadStep] = useState<'upload' | 'review' | 'confirm'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (selectedFile: File) => {
    if (!selectedFile.name.endsWith('.csv') && !selectedFile.name.endsWith('.xlsx')) {
      alert('Please upload a CSV or Excel file');
      return;
    }

    setFile(selectedFile);
    setIsProcessing(true);

    try {
      const text = await selectedFile.text();
      const parsed = parseCSV(text);
      setParsedData(parsed);
      setUploadStep('review');
    } catch (error) {
      console.error(error); 
      alert('Error reading file. Please check the file format.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Enhanced date parsing for EST timezone
  const parseESTDate = (dateString: string): string => {
    if (!dateString) return '';

    // Remove any quotes and trim
    const cleanDate = dateString.replace(/['"]/g, '').trim();

    // If already in YYYY-MM-DD format, return as is
    if (cleanDate.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return cleanDate;
    }

    // Try to parse various date formats in EST
    let year: number, month: number, day: number;

    // Handle MM/DD/YYYY format
    if (cleanDate.match(/^\d{1,2}\/\d{1,2}\/\d{4}$/)) {
      const [monthStr, dayStr, yearStr] = cleanDate.split('/');
      month = parseInt(monthStr);
      day = parseInt(dayStr);
      year = parseInt(yearStr);
    }
    // Handle DD/MM/YYYY format (assume if day > 12)
    else if (cleanDate.match(/^\d{1,2}\/\d{1,2}\/\d{4}$/)) {
      const parts = cleanDate.split('/');
      if (parseInt(parts[0]) > 12) {
        day = parseInt(parts[0]);
        month = parseInt(parts[1]);
        year = parseInt(parts[2]);
      } else {
        month = parseInt(parts[0]);
        day = parseInt(parts[1]);
        year = parseInt(parts[2]);
      }
    }
    // Handle other formats by creating a date in EST
    else {
      // Create date object and adjust for EST
      const tempDate = new Date(cleanDate);
      if (isNaN(tempDate.getTime())) {
        return '';
      }

      // Adjust for EST timezone (UTC-5)
      const estOffset = -5 * 60; // EST is UTC-5
      const utc = tempDate.getTime() + (tempDate.getTimezoneOffset() * 60000);
      const estDate = new Date(utc + (estOffset * 60000));

      year = estDate.getFullYear();
      month = estDate.getMonth() + 1;
      day = estDate.getDate();
    }

    // Validate date components
    if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) {
      return '';
    }

    // Return in YYYY-MM-DD format with proper padding
    return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  // Helper to find Coordinator object by name
  const findCoordinatorByName = (name: string): Coordinator | undefined => {
    if (!name || !Array.isArray(coordinators)) return undefined;
    return coordinators.find(c => c.name.trim().toLowerCase() === name.trim().toLowerCase());
  };

  const parseCSV = (csvText: string): ParsedCandidate[] => {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].toLowerCase().split(',').map(h => h.trim());

    // Find column indices
    const columnMap = {
      candidateId: findColumnIndex(headers, ['candidate id', 'candidateid', 'id', 'cand id', 'cand']),
      candidateName: findColumnIndex(headers, ['candidate name', 'candidatename', 'name']),
      clientName: findColumnIndex(headers, ['client name', 'clientname', 'client']),
      contractType: findColumnIndex(headers, ['contract type', 'contracttype', 'contract t', 'contract']),
      startDate: findColumnIndex(headers, ['start date', 'startdate', 'start']),
      endDate: findColumnIndex(headers, ['end date', 'enddate', 'end']),
      payRate: findColumnIndex(headers, ['pay rate', 'payrate', 'pay']),
      w2PayrollAdminTaxesPercentage: findColumnIndex(headers, ['w2 payroll and admin taxes %', 'payroll and admin taxes %']),
      w2C2COverheadCostPercentage: findColumnIndex(headers, ['w2 / c2c overhead cost %', 'overhead cost %']),
      healthBenefits: findColumnIndex(headers, ['health benefits', 'healthbenefits', 'health be']),
      billRate: findColumnIndex(headers, ['bill rate', 'billrate', 'bill']),
      mspFeesPercentage: findColumnIndex(headers, ['msp fees percentage', 'mspfeespercentage', 'msp fees %', 'msp fees']),
      crm: findColumnIndex(headers, ['crm']),
      lead: findColumnIndex(headers, ['lead', 'team lead', 'teamlead']),
      manager: findColumnIndex(headers, ['manager']),
      seniorManager: findColumnIndex(headers, ['senior manager', 'seniormanager', 'senior ma']),
      assoDirector: findColumnIndex(headers, ['associate director', 'assodirector', 'asso director', 'associate']),
      centerHead: findColumnIndex(headers, ['center head', 'centerhead', 'center he']),
      recruiter: findColumnIndex(headers, ['recruiter']),
      // Add new fields
      otherName: findColumnIndex(headers, ['other name', 'othername', 'other na', 'other']),
      candidateSource: findColumnIndex(headers, ['candidate source', 'candidatesource', 'candidate sou','source','candidate']),
      placementType: findColumnIndex(headers, ['placement type', 'placementtype'])
    };
    const requiredFields = ['candidateId', 'candidateName', 'clientName', 'contractType', 'startDate', 'payRate', 'billRate', 'crm', 'lead', 'manager', 'seniorManager', 'assoDirector', 'centerHead'];
    const missingFields = requiredFields.filter(field => columnMap[field as keyof typeof columnMap] === -1);

    if (missingFields.length > 0) {
      throw new Error(`Required columns not found: ${missingFields.join(', ')}`);
    }

    const parsed: ParsedCandidate[] = [];

    for (let i = 1; i < lines.length; i++) {
      const row = lines[i].split(',').map(cell => cell.trim());

      if (row.length < Math.max(...Object.values(columnMap).filter(v => v !== -1)) + 1) continue;

      const candidateData: any = {};

      const contractType = (candidateData.contractType || '').toUpperCase();
      if (contractType === 'C2C') {
        candidateData.w2PayrollAdminTaxesPercentage = 0;
      }
      if (contractType === 'W2') {
        candidateData.w2C2COverheadCostPercentage = 0;
      }

      Object.entries(columnMap).forEach(([field, index]) => {
        if (index !== -1 && row[index]) {
          if (
            field === 'payRate' ||
            field === 'w2PayrollAdminTaxesPercentage' ||
            field === 'w2C2COverheadCostPercentage' ||
            field === 'taxesPercentage' ||
            field === 'healthBenefits' ||
            field === 'billRate' ||
            field === 'mspFeesPercentage'
          ) {
            candidateData[field] = parseFloat(row[index]) || 0;
          } else if (field === 'startDate' || field === 'endDate') {
            candidateData[field] = parseESTDate(row[index]);
          } else {
            candidateData[field] = row[index];
          }
        }
      });

      let isValid = true;
      let error = '';

      // Validation
      if (!candidateData.candidateId) {
        isValid = false;
        error = 'Missing Candidate ID';
      } else if (!candidateData.candidateName) {
        isValid = false;
        error = 'Missing Candidate Name';
      } else if (!candidateData.contractType || !['C2C', 'W2', 'FULLTIME'].includes(candidateData.contractType.toUpperCase())) {
        isValid = false;
        error = 'Missing or Invalid Contract Type';
      } else if (!candidateData.startDate) {
        isValid = false;
        error = 'Missing or Invalid Start Date';
      } else if (candidateData.payRate <= 0) {
        isValid = false;
        error = 'Invalid Pay Rate';
      } else if (candidateData.billRate <= 0) {
        isValid = false;
        error = 'Invalid Bill Rate';
      } else if (
        (candidateData.candidateSource || '').trim().toLowerCase() === 'ampcus tech in house' &&
        !candidateData.placementType
      ) {
        isValid = false;
        error = 'Placement Type required for Ampcus Tech In House source';
      }

      // Team member mapping
      const teamFields = ['crm', 'lead', 'manager', 'seniorManager', 'assoDirector', 'centerHead', 'recruiter'];
      for (const field of teamFields) {
        if (candidateData[field]) {
          const coord = findCoordinatorByName(candidateData[field]);
          if (!coord && field !== 'recruiter') {
            isValid = false;
            error = `Invalid or missing ${field} (not found in coordinators)`;
            break;
          }
        }
      }

      parsed.push({
        ...candidateData,
        isValid,
        error
      });
    }

    return parsed;
  };

  const findColumnIndex = (headers: string[], possibleNames: string[]): number => {
    for (const name of possibleNames) {
      // Try exact match, includes, and startsWith for flexibility
      const index = headers.findIndex(
        h =>
          h === name ||
          h.includes(name) ||
          h.startsWith(name) ||
          name.includes(h) // for truncated header in CSV
      );
      if (index !== -1) return index;
    }
    return -1;
  };

  const handleConfirm = () => {
    const validRows = parsedData.filter(row => row.isValid);
    const candidates: Candidate[] = validRows.map(row => {
      // Map team member fields to Coordinator objects
      const teamFields = ['crm', 'lead', 'manager', 'seniorManager', 'assoDirector', 'centerHead', 'recruiter'];
      const mapped: any = { ...row };
      teamFields.forEach(field => {
        if (row[field]) {
          mapped[field] = findCoordinatorByName(row[field]);
        }
      });
      // Normalize contractType
      mapped.contractType = mapped.contractType?.toUpperCase();
      // Normalize placementType if present
      if (mapped.placementType) {
        const val = String(mapped.placementType).toLowerCase();
        if (val.includes('below')) mapped.placementType = 'Below Manager';
        else if (val.includes('above')) mapped.placementType = 'Above Manager';
      }
      const calculated = calculateCandidateFields(mapped);
      return {
        ...calculated,
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
      } as Candidate;
    });

    onSave(candidates);
  };

  const downloadTemplate = () => {
    const csvContent = [
      [
        'Candidate ID',
        'Candidate Name',
        'Other Name',
        'Candidate Source',
        'Placement Type',
        'Client Name',
        'Contract Type',
        'Start Date(EST)',
        'End Date(EST) - Optional',
        'Pay Rate ($)',
        'Taxes Percentage',
        'Health Benefits',
        'Bill Rate',
        'MSP Fees Percentage',
        'CRM',
        'Team Lead',
        'Manager',
        'Senior Manager',
        'Associate Director',
        'Center Head',
        'Recruiter'
      ],
      [
        'EMP001',
        'John Doe',
        'John',
        'Ampcus Tech In House',
        'Below Manager',
        'ABC Corp',
        'C2C',
        '2024-03-01',
        '',
        '50',
        '25',
        '500',
        '75',
        '5',
        'Jane Smith',
        'Mike Johnson',
        'Sarah Wilson',
        'David Brown',
        'Lisa Davis',
        'Tom Anderson',
        'Emily Clark'
      ]
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'candidate-import-template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const formatESTDate = (dateString: string) => {
    if (!dateString) return '-';
    const [year, month, day] = dateString.split('-').map(Number);
    const date = new Date(year, month - 1, day);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      timeZone: 'America/New_York'
    });
  };

  const validCount = parsedData.filter(row => row.isValid).length;
  const invalidCount = parsedData.length - validCount;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Upload className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Import Candidates</h2>
              <p className="text-sm text-gray-500">Upload CSV or Excel file with candidate data (EST timezone)</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {uploadStep === 'upload' && (
            <div className="space-y-6">
              <div className="text-center">
                <button
                  onClick={downloadTemplate}
                  className="mb-4 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 mx-auto"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Template</span>
                </button>
                <p className="text-sm text-gray-600">
                  Download a template with the required column format
                </p>
              </div>

              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${dragActive
                  ? 'border-blue-400 bg-blue-50'
                  : 'border-gray-300 hover:border-gray-400'
                  }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  Drop your CSV or Excel file here, or click to browse
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  File should contain candidate information with required columns
                </p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  disabled={isProcessing}
                >
                  {isProcessing ? 'Processing...' : 'Choose File'}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.xlsx"
                  onChange={handleFileInput}
                  className="hidden"
                />
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-medium text-blue-900 mb-2">📅 EST Timezone Handling:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-700">
                  <div>
                    <p className="font-medium mb-1">✅ Supported Date Formats:</p>
                    <ul className="space-y-1">
                      <li>• YYYY-MM-DD (2024-03-01)</li>
                      <li>• MM/DD/YYYY (03/01/2024)</li>
                      <li>• DD/MM/YYYY (01/03/2024)</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">🔒 Date Preservation:</p>
                    <ul className="space-y-1">
                      <li>• All dates stored in EST</li>
                      <li>• No timezone shifts</li>
                      <li>• Exact date preservation</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-gray-900 mb-2">Required Columns:</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm text-gray-600">
                  <div>• Candidate ID</div>
                  <div>• Candidate Name</div>
                  <div>• Client Name</div>
                  <div>• Contract Type</div>
                  <div>• Start Date</div>
                  <div>• Pay Rate</div>
                  <div>• Bill Rate</div>
                  <div>• CRM</div>
                  <div>• Lead</div>
                  <div>• Manager</div>
                  <div>• Senior Manager</div>
                  <div>• Associate Director</div>
                  <div>• Center Head</div>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Optional: End Date, Taxes Percentage, Health Benefits, MSP Fees Percentage, Recruiter
                </p>
              </div>
            </div>
          )}

          {uploadStep === 'review' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Review Imported Data (EST Timezone)</h3>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="text-sm text-green-700">{validCount} Valid</span>
                  </div>
                  {invalidCount > 0 && (
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <span className="text-sm text-red-700">{invalidCount} Invalid</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="max-h-96 overflow-y-auto border border-gray-200 rounded-lg">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Candidate ID</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Contract Type</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Start Date (EST)</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Pay Rate</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Bill Rate</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Error</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {parsedData.map((row, index) => (
                      <tr key={index} className={row.isValid ? 'bg-green-50' : 'bg-red-50'}>
                        <td className="px-3 py-2 whitespace-nowrap">
                          {row.isValid ? (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-red-600" />
                          )}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap font-medium">{row.candidateId}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{row.candidateName}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{row.clientName}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{row.contractType || '-'}</td>
                        <td className="px-3 py-2 whitespace-nowrap">
                          {formatESTDate(row.startDate)}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap">${row.payRate}</td>
                        <td className="px-3 py-2 whitespace-nowrap">${row.billRate}</td>
                        <td className="px-3 py-2 whitespace-nowrap text-red-600">{row.error || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setUploadStep('upload')}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleConfirm}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  disabled={validCount === 0}
                >
                  Import {validCount} Candidates
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};