import React from 'react';
import { Candidate } from '../types';
import { Edit, Trash2, User, DollarSign, TrendingUp, History } from 'lucide-react';

interface CandidateListProps {
  candidates: Candidate[];
  onEdit?: (candidate: Candidate) => void;
  onDelete: (candidateId: string) => void;
  onMarginRevision?: (candidate: Candidate) => void;
}

export const CandidateList: React.FC<CandidateListProps> = ({ 
  candidates, 
  onEdit, 
  onDelete, 
  onMarginRevision 
}) => {
  const formatCurrency = (amount: number | undefined | null) => {
    if (amount === undefined || amount === null || isNaN(amount)) {
      return '$0.00';
    }
    return `$${amount.toFixed(2)}`;
  };
  const formatDate = (date: string) => new Date(date).toLocaleDateString();


  if (candidates.length === 0) {
    return (
      <div className="text-center py-12">
        <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Candidates</h3>
        <p className="text-gray-500">Add your first candidate to get started.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {candidates.map((candidate) => (
        <div key={candidate.id} className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{candidate.candidateName}</h3>
                <p className="text-sm text-gray-600">ID: {candidate.candidateId} • Client: {candidate.clientName}</p>
                <div className="flex items-center mt-2 space-x-4">
                  <span className="text-sm text-gray-500">
                    Start: {formatDate(candidate.startDate)}
                  </span>
                  {candidate.endDate ? (
                    <span className="text-sm text-gray-500">
                      End: {formatDate(candidate.endDate)}
                    </span>
                  ) : (
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                      Active
                    </span>
                  )}
                  {candidate.marginRevisions && candidate.marginRevisions.length > 0 && (
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full flex items-center space-x-1">
                      <History className="w-3 h-3" />
                      <span>{candidate.marginRevisions.length} Revision{candidate.marginRevisions.length !== 1 ? 's' : ''}</span>
                    </span>
                  )}
                </div>
              </div>
              <div className="flex space-x-2">
                {onMarginRevision && (
                  <button
                    onClick={() => onMarginRevision(candidate)}
                    className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                    title="Margin Revision"
                  >
                    <TrendingUp className="w-4 h-4" />
                  </button>
                )}
                {onEdit && (
                  <button
                    onClick={() => onEdit(candidate)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Edit Candidate"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => onDelete(candidate.id || '')}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Delete Candidate"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-xs text-gray-500 uppercase tracking-wide">Pay Rate</p>
                <p className="text-lg font-semibold text-gray-900">{formatCurrency(candidate.payRate)}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-xs text-gray-500 uppercase tracking-wide">Bill Rate</p>
                <p className="text-lg font-semibold text-gray-900">{formatCurrency(candidate.billRate)}</p>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-xs text-blue-600 uppercase tracking-wide">Net Bill Rate</p>
                <p className="text-lg font-semibold text-blue-700">{formatCurrency(candidate.netBillRate)}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-xs text-green-600 uppercase tracking-wide flex items-center">
                  <DollarSign className="w-3 h-3 mr-1" />
                  Current Margin
                </p>
                <p className="text-lg font-semibold text-green-700">{formatCurrency(candidate.margin)}</p>
              </div>
            </div>

            {/* Margin Revision History */}
            {candidate.marginRevisions && candidate.marginRevisions.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                  <History className="w-4 h-4 mr-1" />
                  Recent Margin Revisions
                </h4>
                <div className="space-y-2">
                  {candidate.marginRevisions
                    .sort((a, b) => new Date(b.effectiveDate).getTime() - new Date(a.effectiveDate).getTime())
                    .slice(0, 2)
                    .map((revision) => (
                      <div key={revision.id} className="flex items-center justify-between text-sm bg-gray-50 p-2 rounded">
                        <div>
                          <span className="font-medium">{formatDate(revision.effectiveDate)}</span>
                          <span className="text-gray-500 ml-2">{revision.reason}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-green-600">{formatCurrency(revision.margin)}</span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                <div>
                  <span className="text-gray-500">Recruiter:</span>
                  <span className="ml-1 font-medium">{candidate.recruiter?.name || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-gray-500">Team Lead:</span>
                  <span className="ml-1 font-medium">{candidate.lead?.name}</span>
                </div>
                <div>
                  <span className="text-gray-500">Manager:</span>
                  <span className="ml-1 font-medium">{candidate.manager?.name}</span>
                </div>
                <div>
                  <span className="text-gray-500">CRM:</span>
                  <span className="ml-1 font-medium">{candidate.crm?.name}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};