-- Insert default admin user
INSERT INTO users (username, email, password, role, is_active, created_by) 
VALUES (
    'admin', 
    'admin@incentivetracker.com', 
    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', -- BCrypt hash for 'admin123'
    'ADMIN', 
    true, 
    'SYSTEM'
);

-- Insert admin permissions
INSERT INTO user_permissions (user_id, permission) 
SELECT 
    u.id,
    p.permission
FROM users u
CROSS JOIN (
    VALUES 
        ('ADD_CANDIDATES'),
        ('MARGIN_REVISION'),
        ('COORDINATORS'),
        ('START_INCENTIVE_CYCLE'),
        ('CALCULATE_INCENTIVE_CYCLE'),
        ('ADD_HOURS'),
        ('APPROVE_INCENTIVE_CYCLE'),
        ('CUSTOM_REPORTS'),
        ('LEGACY_REPORTS'),
        ('DOWNLOAD'),
        ('USER_MANAGEMENT'),
        ('DELETE_APPROVED_CYCLES')
) AS p(permission)
WHERE u.username = 'admin';