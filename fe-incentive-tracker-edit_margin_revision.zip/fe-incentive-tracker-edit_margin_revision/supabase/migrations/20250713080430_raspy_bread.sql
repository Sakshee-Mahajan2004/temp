-- Insert sample coordinators
INSERT INTO coordinators (name, email, location) VALUES
('John Smith', 'john.smith@company.com', 'New York'),
('Sarah Johnson', 'sarah.johnson@company.com', 'London'),
('Michael Brown', 'michael.brown@company.com', 'Mumbai'),
('Emily Davis', 'emily.davis@company.com', 'Toronto'),
('David Wilson', 'david.wilson@company.com', 'Sydney'),
('Lisa Anderson', 'lisa.anderson@company.com', 'Berlin'),
('Robert Taylor', 'robert.taylor@company.com', 'Singapore'),
('Jennifer Martinez', 'jennifer.martinez@company.com', 'Dubai');