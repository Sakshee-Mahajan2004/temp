import React, { useState } from 'react';
import { IncentiveCycle, Coordinator, CoordinatorReport } from '../types';
import { formatCurrencyForReport } from '../utils/calculations';
import { ExportUtils } from './ExportUtils';
import { CycleHoursReportModal } from './CycleHoursReportModal';
import { Check, Mail, Send, Download, FileText, Users, MapPin, DollarSign, Clock, Eye } from 'lucide-react';

interface ApprovedCyclesManagerProps {
  cycles: IncentiveCycle[];
  coordinators: Coordinator[];
  candidates: any[];
}

export const ApprovedCyclesManager: React.FC<ApprovedCyclesManagerProps> = ({
  cycles,
  coordinators,
  candidates
}) => {
  const [selectedCoordinators, setSelectedCoordinators] = useState<string[]>([]);
  const [selectedCycle, setSelectedCycle] = useState<string>('');
  const [showHoursReport, setShowHoursReport] = useState<IncentiveCycle | null>(null);
  const [showCycleDetails, setShowCycleDetails] = useState<string | null>(null);

  const approvedCycles = cycles.filter(c => c.status === 'APPROVED' || c.status === 'approved' );

  const formatMonth = (month: string) => {
    const [year, monthNum] = month.split('-');
    return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };

  const handleCoordinatorSelect = (coordinatorName: string) => {
    setSelectedCoordinators(prev => 
      prev.includes(coordinatorName)
        ? prev.filter(name => name !== coordinatorName)
        : [...prev, coordinatorName]
    );
  };

  const handleSelectAllCoordinators = (cycleId: string) => {
    const cycle = approvedCycles.find(c => c.id === cycleId);
    if (cycle && cycle.coordinatorReports) {
      const allCoordinators = cycle.coordinatorReports.map(r => r.coordinatorName);
      setSelectedCoordinators(allCoordinators);
    }
  };

  const generateCoordinatorReport = (coordinatorName: string, cycleId: string) => {
    const cycle = approvedCycles.find(c => c.id === cycleId);
    if (!cycle || !cycle.coordinatorReports) return;

    const report = cycle.coordinatorReports.find(r => r.coordinatorName === coordinatorName);
    if (!report) return;

    const csvContent = [
      ['Incentive Report'],
      [`Coordinator: ${report.coordinatorName}`],
      [`Email: ${report.coordinatorEmail}`],
      [`Location: ${report.coordinatorLocation}`],
      [`Month: ${formatMonth(cycle.month)}`],
      [`Total Incentive: ${formatCurrencyForReport(report.totalIncentive)}`],
      [`Adjustment Amount: ${formatCurrencyForReport(report.adjustmentAmount || 0)}`],
      [`Net Amount: ${formatCurrencyForReport(report.totalIncentive + (report.adjustmentAmount || 0))}`],
      [''],
      ['Placements:'],
      ['Candidate ID', 'Candidate Name', 'Client Name', 'Contract Type', 'Role', 'Margin/Finder Fees', 'Hours/Placements', 'Incentive Amount', 'Incentive Type'],
      ...report.placements.map(p => [
        p.candidateId,
        p.candidateName,
        p.clientName,
        p.contractType,
        p.role,
        p.contractType === 'Fulltime' ? (p.finderFees ? `$${p.finderFees.toFixed(2)}` : 'N/A') : `$${p.margin.toFixed(2)}`,
        p.hoursWorked.toString(),
        formatCurrencyForReport(p.incentiveAmount),
        p.incentiveType
      ])
    ];

    if (report.adjustments && report.adjustments.length > 0) {
      csvContent.push(
        [''],
        ['Adjustments:'],
        ['Candidate ID', 'Candidate Name', 'Affected Month', 'Adjustment Amount', 'Adjustment Type', 'Reason'],
        ...report.adjustments.map(a => [
          a.candidateId,
          a.candidateName,
          formatMonth(a.affectedMonth),
          formatCurrencyForReport(a.adjustmentAmount),
          a.adjustmentType,
          a.reason
        ])
      );
    }

    const csvString = csvContent.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvString], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `incentive-report-${coordinatorName.replace(/\s+/g, '-')}-${cycle.month}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const sendReportsToSelectedCoordinators = () => {
    if (!selectedCycle || selectedCoordinators.length === 0) return;

    // In a real application, this would integrate with an email service
    alert(`Reports would be sent to ${selectedCoordinators.length} coordinator(s) for the selected cycle. Integration with email service required.`);
    
    // Clear selections after sending
    setSelectedCoordinators([]);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Approved Incentive Cycles</h2>
          <p className="text-gray-600">Generate and send coordinator-specific incentive reports</p>
        </div>
      </div>

      {approvedCycles.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Check className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Approved Cycles</h3>
          <p className="text-gray-500">Approved incentive cycles will appear here for report generation.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Cycle Selection and Bulk Actions */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Send Reports to Multiple Coordinators</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Cycle</label>
                <select
                  value={selectedCycle}
                  onChange={(e) => {
                    setSelectedCycle(e.target.value);
                    setSelectedCoordinators([]);
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Choose a cycle...</option>
                  {approvedCycles.map(cycle => (
                    <option key={cycle.id} value={cycle.id}>
                      {formatMonth(cycle.month)} - {formatCurrencyForReport(cycle.incentiveCalculations.reduce((sum, calc) => sum + calc.incentiveAmount, 0))}
                    </option>
                  ))}
                </select>
              </div>
              
              {selectedCycle && (
                <div className="flex items-end space-x-2">
                  <button
                    onClick={() => handleSelectAllCoordinators(selectedCycle)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Select All Coordinators
                  </button>
                  <button
                    onClick={sendReportsToSelectedCoordinators}
                    disabled={selectedCoordinators.length === 0}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Reports ({selectedCoordinators.length})</span>
                  </button>
                </div>
              )}
            </div>

            {selectedCycle && (
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-3">Select Coordinators:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {approvedCycles.find(c => c.id === selectedCycle)?.coordinatorReports?.map(report => (
                    <label key={report.coordinatorName} className="flex items-center space-x-2 p-2 border border-gray-200 rounded hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={selectedCoordinators.includes(report.coordinatorName)}
                        onChange={() => handleCoordinatorSelect(report.coordinatorName)}
                        className="rounded"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-gray-900 truncate">{report.coordinatorName}</div>
                        <div className="text-sm text-gray-500 truncate">{formatCurrencyForReport(report.totalIncentive)}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Individual Cycle Reports */}
          {approvedCycles.map(cycle => {
            const coordinators = cycle.coordinatorReports?.map(report => report.coordinatorName);
            return (
            <div key={cycle.id} className="bg-white rounded-lg border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{formatMonth(cycle.month)}</h3>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                      <span>Approved: {cycle.approvedAt ? new Date(cycle.approvedAt).toLocaleDateString() : 'N/A'}</span>
                      <span>Total: {formatCurrencyForReport(cycle.incentiveCalculations.reduce((sum, calc) => sum + calc.incentiveAmount, 0))}</span>
                      <span>Coordinators: {coordinators?.length || 0}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ExportUtils
                      data={cycle.incentiveCalculations}
                      filename={`approved-cycle-${cycle.month}`}
                      title={`Approved Cycle Report - ${formatMonth(cycle.month)}`}
                      type="cycle"
                      cycle={cycle}
                      candidates={candidates}
                    />
                    {cycle.monthlyHours.length > 0 && (
                      <button
                        onClick={() => setShowHoursReport(cycle)}
                        className="flex items-center space-x-2 px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm"
                      >
                        <Clock className="w-4 h-4" />
                        <span>Hours Report</span>
                      </button>
                    )}
                    <button
                      onClick={() => setShowCycleDetails(showCycleDetails === cycle.id ? null : cycle.id)}
                      className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors text-sm"
                    >
                      <Eye className="w-4 h-4" />
                      <span>{showCycleDetails === cycle.id ? 'Hide Details' : 'Show Details'}</span>
                    </button>
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 flex items-center space-x-1">
                      <Check className="w-3 h-3" />
                      <span>Approved</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Cycle Details */}
              {showCycleDetails === cycle.id && (
                <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                  <h4 className="font-medium text-gray-900 mb-3">Cycle Details</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white p-3 rounded border">
                      <div className="text-sm text-gray-500">Total Candidates</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {new Set(cycle.incentiveCalculations.map(calc => calc.candidateId)).size}
                      </div>
                    </div>
                    <div className="bg-white p-3 rounded border">
                      <div className="text-sm text-gray-500">Total Hours/Placements</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {cycle.monthlyHours.reduce((sum, h) => sum + h.hoursWorked, 0)}
                      </div>
                    </div>
                    <div className="bg-white p-3 rounded border">
                      <div className="text-sm text-gray-500">Adjustments</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {cycle.incentiveAdjustments?.length || 0}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {cycle.coordinatorReports && cycle.coordinatorReports.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Coordinator
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Location
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Placements
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Total Incentive
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Adjustments
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Net Amount
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {cycle.coordinatorReports.map(report => (
                        <tr key={report.coordinatorName} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Users className="w-5 h-5 text-gray-400 mr-3" />
                              <div>
                                <div className="font-medium text-gray-900">{report.coordinatorName}</div>
                                <div className="text-sm text-gray-500 flex items-center">
                                  <Mail className="w-3 h-3 mr-1" />
                                  {report.coordinatorEmail}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center text-gray-900">
                              <MapPin className="w-4 h-4 text-gray-400 mr-1" />
                              {report.coordinatorLocation}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                            {report.placements.length}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center text-green-600 font-semibold">
                              <DollarSign className="w-4 h-4 mr-1" />
                              {formatCurrencyForReport(report.totalIncentive)}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className={`font-medium ${
                              (report.adjustmentAmount || 0) >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {report.adjustmentAmount ? formatCurrencyForReport(report.adjustmentAmount) : '-'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="font-semibold text-blue-600">
                              {formatCurrencyForReport(report.totalIncentive + (report.adjustmentAmount || 0))}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => generateCoordinatorReport(report.coordinatorName, cycle.id)}
                                className="text-blue-600 hover:text-blue-900 flex items-center space-x-1"
                                title="Download Individual Report"
                              >
                                <Download className="w-4 h-4" />
                                <span>Download</span>
                              </button>
                              {report.sentAt && (
                                <span className="text-xs text-green-600 flex items-center">
                                  <Check className="w-3 h-3 mr-1" />
                                  Sent
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-6 text-center text-gray-500">
                  <FileText className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p>No coordinator reports available for this cycle</p>
                </div>
              )}
            </div>
          );
        } )}
        </div>
      )}

      {/* Hours Report Modal */}
      {showHoursReport && (
        <CycleHoursReportModal
          cycle={showHoursReport}
          candidates={candidates}
          onClose={() => setShowHoursReport(null)}
        />
      )}
    </div>
  );
};