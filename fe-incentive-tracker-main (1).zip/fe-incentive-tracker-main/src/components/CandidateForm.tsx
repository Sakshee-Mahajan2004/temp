import React, { useState, useEffect, useRef } from 'react';
import { Candidate, Coordinator } from '../types';
import { Save, X, ChevronDown } from 'lucide-react';

interface CandidateFormProps {
  candidate?: Candidate;
  coordinators: Coordinator[];
  onSave: (candidate: Candidate) => void;
  onCancel: () => void;
}

export const CandidateForm: React.FC<CandidateFormProps> = ({ candidate, coordinators, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Partial<Candidate>>({
    candidateId: '',
    candidateName: '',
    clientName: '',
    contractType: 'C2C',
    startDate: '',
    endDate: '',
    payRate: 0,
    w2PayrollAdminTaxesPercentage: 0,
    w2C2COverheadCostPercentage: 0,
    healthBenefits: 0,
    billRate: 0,
    mspFeesPercentage: 0,
    finderFees: 0,
    recruiter: undefined,
    lead: undefined,
    manager: undefined,
    seniorManager: undefined,
    crm: undefined,
    assoDirector: undefined,
    centerHead: undefined,
    otherName: '',
    candidateSource: '',
    ...candidate
  });

  const [dropdownStates, setDropdownStates] = useState<{[key: string]: boolean}>({});
  const [searchTerms, setSearchTerms] = useState<{[key: string]: string}>({});

  // Calculate derived fields whenever relevant inputs change
  useEffect(() => {
    if (formData.contractType !== 'FULLTIME') {
      const calculated = { ...formData };
      
      // 1. W2 Payroll and Admin Taxes ($) = Pay Rate * W2 Payroll and Admin Taxes %
      if (calculated.payRate && calculated.w2PayrollAdminTaxesPercentage) {
        calculated.w2PayrollAdminTaxes = (calculated.payRate * calculated.w2PayrollAdminTaxesPercentage) / 100;
      } else {
        calculated.w2PayrollAdminTaxes = 0;
      }
      
      // 2. W2 / C2C Overhead Cost ($) = Pay Rate * W2 / C2C Overhead Cost %
      if (calculated.payRate && calculated.w2C2COverheadCostPercentage) {
        calculated.w2C2COverheadCost = (calculated.payRate * calculated.w2C2COverheadCostPercentage) / 100;
      } else {
        calculated.w2C2COverheadCost = 0;
      }
      
      // 3. Net Purchase = Pay rate + W2 Payroll and Admin Taxes + W2 / C2C Overhead Cost + Health benefits
      calculated.netPurchase = (calculated.payRate || 0) + 
                              (calculated.w2PayrollAdminTaxes || 0) + 
                              (calculated.w2C2COverheadCost || 0) + 
                              (calculated.healthBenefits || 0);
      
      // 4. MSP Fees $ = Bill Rate * MSP fees %
      if (calculated.billRate && calculated.mspFeesPercentage) {
        calculated.mspFeesDollar = (calculated.billRate * calculated.mspFeesPercentage) / 100;
      } else {
        calculated.mspFeesDollar = 0;
      }
      
      // 5. Net Bill Rate = Bill Rate - MSP Fees $ (CORRECTED FORMULA)
      calculated.netBillRate = (calculated.billRate || 0) - (calculated.mspFeesDollar || 0);
      
      // 6. Margin = Net Bill Rate - Net Purchase
      calculated.margin = (calculated.netBillRate || 0) - (calculated.netPurchase || 0);
      
      setFormData(calculated);
    }
  }, [formData.payRate, formData.w2PayrollAdminTaxesPercentage, formData.w2C2COverheadCostPercentage, formData.healthBenefits, formData.billRate, formData.mspFeesPercentage, formData.contractType]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const candidateData = {
      ...formData,
      id: candidate?.id || Date.now().toString()
    } as Candidate;
    onSave(candidateData);
  };

  const handleChange = (field: keyof Candidate, value: Coordinator | string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleDateChange = (field: 'startDate' | 'endDate', value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const formatDateDisplay = (dateString: string) => {
    if (!dateString) return 'No date selected';
    
    try {
      const [year, month, day] = dateString.split('-').map(Number);
      const date = new Date(year, month - 1, day);
      
      return date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        timeZone: 'America/New_York'
      });
    } catch (error) {
      return 'Invalid date';
    }
  };

  const CoordinatorDropdown: React.FC<{
    field: keyof Candidate;
    label: string;
    required?: boolean;
  }> = ({ field, label, required = false }) => {
    const [inputValue, setInputValue] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);
    const currentValue = formData[field] as Coordinator || { id: '', name: '', email: '', location: '' };
    const dropdownRef = useRef<HTMLDivElement>(null);
  
    // Filter coordinators based on search term
    const filteredCoordinators = coordinators.filter(coord =>
      coord.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coord.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coord.location.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    // Initialize input value with current selection
    useEffect(() => {
      if (currentValue?.name) {
        setInputValue(currentValue.name);
      }
    }, [currentValue?.name]);
  
    const handleSelect = (coordinator: Coordinator) => {
      handleChange(field, coordinator);
      setInputValue(coordinator.name);
      setIsOpen(false);
      setSearchTerm('');
    };
  
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setInputValue(e.target.value);
    };
  
    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(e.target.value);
      setHighlightedIndex(-1);
    };
  
    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (!isOpen) return;
  
      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setHighlightedIndex(prev => 
            Math.min(prev + 1, filteredCoordinators.length - 1)
          );
          break;
        case 'ArrowUp':
          e.preventDefault();
          setHighlightedIndex(prev => Math.max(prev - 1, -1));
          break;
        case 'Enter':
          e.preventDefault();
          if (highlightedIndex >= 0 && highlightedIndex < filteredCoordinators.length) {
            handleSelect(filteredCoordinators[highlightedIndex]);
          }
          break;
        case 'Escape':
          e.preventDefault();
          setIsOpen(false);
          setSearchTerm('');
          break;
      }
    };
  
    // Close dropdown when clicking outside
    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
          setIsOpen(false);
          setSearchTerm('');
          if (currentValue?.name) {
            setInputValue(currentValue.name);
          }
        }
      };
  
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [currentValue?.name]);
  
    return (
      <div className="relative" ref={dropdownRef}>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
        <div className="relative">
          <input
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            onFocus={() => setIsOpen(true)}
            onClick={() => setIsOpen(true)}
            onKeyDown={handleKeyDown}
            className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder={`Select ${label.toLowerCase()}...`}
            required={required}
          />
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-gray-600"
          >
            <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'transform rotate-180' : ''}`} />
          </button>
        </div>
        
        {isOpen && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg overflow-hidden">
            {/* Search input inside dropdown */}
            <div className="p-2 border-b">
              <input
                type="text"
                value={searchTerm}
                onChange={handleSearchChange}
                onKeyDown={handleKeyDown}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search..."
                autoFocus
              />
            </div>
            
            <div className="max-h-60 overflow-y-auto">
              {filteredCoordinators.length > 0 ? (
                filteredCoordinators.map((coordinator, index) => (
                  <button
                    key={coordinator.id}
                    type="button"
                    onClick={() => handleSelect(coordinator)}
                    className={`w-full px-4 py-2 text-left hover:bg-blue-50 focus:bg-blue-50 focus:outline-none ${
                      highlightedIndex === index ? 'bg-blue-100' : ''
                    } ${currentValue?.id === coordinator.id ? 'bg-blue-50 font-medium' : ''}`}
                    onMouseEnter={() => setHighlightedIndex(index)}
                  >
                    <div className="font-medium text-gray-900">{coordinator.name}</div>
                    <div className="text-sm text-gray-500">
                      {coordinator.email} • {coordinator.location}
                    </div>
                  </button>
                ))
              ) : (
                <div className="px-4 py-3 text-center text-gray-500 text-sm">
                  No results found
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.relative')) {
        setDropdownStates({});
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isFullTime = formData.contractType === 'FULLTIME';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            {candidate ? 'Edit Candidate' : 'Add New Candidate'}
          </h2>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="bg-blue-50 p-4 rounded-lg mb-6">
            <p className="text-sm text-blue-700">
              <strong>📅 Date Handling:</strong> All dates are stored and displayed in Eastern Standard Time (EST). 
              The exact date you select will be preserved without timezone shifts.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Basic Information</h3>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Candidate ID</label>
                <input
                  type="text"
                  value={formData.candidateId}
                  onChange={(e) => handleChange('candidateId', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Candidate Name</label>
                <input
                  type="text"
                  value={formData.candidateName}
                  onChange={(e) => handleChange('candidateName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Other Name</label>
                <input
                  type="text"
                  value={formData.otherName || ''}
                  onChange={(e) => handleChange('otherName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {/* Candidate Source Dropdown */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Candidate Source</label>
                <select
                  value={formData.candidateSource || ''}
                  onChange={(e) => handleChange('candidateSource', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="N/A">N/A</option>
                  <option value="Bravens Inc">Bravens Inc</option>
                  <option value="Ampcus Inc"> Ampcus Inc</option>
                  <option value="ITech">ITech</option>
                  <option value="Apokrin LLC">Apokrin LLC</option>
                  <option value="BravensTech Inc">BravensTech Inc</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Client Name</label>
                <input
                  type="text"
                  value={formData.clientName}
                  onChange={(e) => handleChange('clientName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contract Type</label>
                <select
                  value={formData.contractType}
                  onChange={(e) => handleChange('contractType', e.target.value as 'C2C' | 'W2' | 'FULLTIME')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="C2C">C2C</option>
                  <option value="W2">W2</option>
                  <option value="FULLTIME">Full-Time</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Date (EST)</label>
                <input
                  type="date"
                  value={formData.startDate || ''}
                  onChange={(e) => handleDateChange('startDate', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
                <p className="text-xs text-green-600 mt-1 font-medium">
                  ✅ Selected: {formatDateDisplay(formData.startDate || '')}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">End Date (EST) - Optional</label>
                <input
                  type="date"
                  value={formData.endDate || ''}
                  onChange={(e) => handleDateChange('endDate', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {formData.endDate && (
                  <p className="text-xs text-green-600 mt-1 font-medium">
                    ✅ Selected: {formatDateDisplay(formData.endDate)}
                  </p>
                )}
              </div>

              {/* Full-time specific field */}
              {isFullTime && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Finder Fees ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.finderFees}
                    onChange={(e) => handleChange('finderFees', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required={isFullTime}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Required for full-time placements to calculate recruiter incentives
                  </p>
                </div>
              )}
            </div>

            {/* Financial Information - Only for non-fulltime */}
            {!isFullTime && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Financial Information</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Pay Rate ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.payRate}
                    onChange={(e) => handleChange('payRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">W2 Payroll and Admin Taxes %</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.w2PayrollAdminTaxesPercentage}
                    onChange={(e) => handleChange('w2PayrollAdminTaxesPercentage', parseFloat(e.target.value) || 0)}
                    className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      formData.contractType === 'C2C' ? 'bg-gray-100' : ''
                    }`}
                    required={formData.contractType !== 'C2C'}
                    disabled={formData.contractType === 'C2C'}
                  />
                  {formData.contractType === 'C2C' && (
                    <p className="text-xs text-gray-500 mt-1">
                      Not applicable for C2C contracts
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">W2 Payroll and Admin Taxes ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.w2PayrollAdminTaxes}
                    className={`w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 ${
                      formData.contractType === 'C2C' ? 'bg-gray-100' : ''
                    }`}
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {formData.contractType === 'C2C' 
                      ? 'Not applicable for C2C contracts' 
                      : 'Calculated: Pay Rate × W2 Payroll and Admin Taxes %'
                    }
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">W2 / C2C Overhead Cost %</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.w2C2COverheadCostPercentage}
                    onChange={(e) => handleChange('w2C2COverheadCostPercentage', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">W2 / C2C Overhead Cost ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.w2C2COverheadCost}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">Calculated: Pay Rate × W2 / C2C Overhead Cost %</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Health Benefits ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.healthBenefits}
                    onChange={(e) => handleChange('healthBenefits', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Net Purchase ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.netPurchase}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">Calculated: Pay Rate + W2 Payroll and Admin Taxes + W2 / C2C Overhead Cost + Health Benefits</p>
                </div>
              </div>
            )}

            {/* Billing Information - Only for non-fulltime */}
            {!isFullTime && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Billing Information</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bill Rate ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.billRate}
                    onChange={(e) => handleChange('billRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">MSP Fees (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.mspFeesPercentage}
                    onChange={(e) => handleChange('mspFeesPercentage', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">MSP Fees ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.mspFeesDollar}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">Calculated: Bill Rate - MSP Fees $</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Net Bill Rate ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.netBillRate}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">Calculated: Bill Rate - MSP Fees $</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Margin ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.margin}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 font-semibold"
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">Calculated: Net Bill Rate - Net Purchase</p>
                </div>
              </div>
            )}

            {/* Team Members */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Team Members</h3>
              
              <CoordinatorDropdown field="recruiter" label="Recruiter" />
              <CoordinatorDropdown field="lead" label="Team Lead" />
              <CoordinatorDropdown field="manager" label="Manager" />
              {!isFullTime && <CoordinatorDropdown field="seniorManager" label="Senior Manager" />}
              <CoordinatorDropdown field="crm" label="CRM" />
              <CoordinatorDropdown field="assoDirector" label="Associate Director" />
              <CoordinatorDropdown field="centerHead" label="Center Head" />
            </div>
          </div>

          {/* Full-time incentive structure info */}
          {isFullTime && (
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-medium text-green-900 mb-2">Full-Time Incentive Structure</h3>
              <div className="text-sm text-green-700 space-y-2">
                <div>
                  <strong>Recruiter Incentives (based on finder fees and monthly placements):</strong>
                  <ul className="ml-4 mt-1 space-y-1">
                    <li>• Finder fees ≤ $4,500: ₹15,000 (1), ₹18,000 (2), ₹20,000 (3+) per placement</li>
                    <li>• Finder fees &gt; $4,500: ₹20,000 (1), ₹25,000 (2), ₹30,000 (3+) per placement</li>
                  </ul>
                </div>
                <div>
                  <strong>Other Roles (fixed per placement):</strong>
                  <span className="ml-2">Team Lead: ₹1,000, Manager: ₹1,500, CRM: ₹1,500, Associate Director: ₹4,000, Center Head: ₹4,000</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 border-t pt-6">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Candidate</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};