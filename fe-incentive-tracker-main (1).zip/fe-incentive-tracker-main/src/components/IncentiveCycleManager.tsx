import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Calendar, Users, DollarSign, Clock, CheckCircle, XCircle, AlertCircle, TrendingUp, ChevronDown, ChevronRight, Play, Calculator, Edit, Trash } from 'lucide-react';
import { BarChart3 } from 'lucide-react';
import { Candidate, IncentiveCalculation, IncentiveCycle, RetroactiveIncentive } from '../types';
import { generateRetroactiveIncentives, calculateIncentivesForCycle } from '../utils/calculations';
import { CycleHoursForm } from './CycleHoursForm';
import { IncentiveReports } from './IncentiveReports';
import { TotalIncentiveReportModal } from './TotalIncentiveReportModal';
import { useMutation } from '@tanstack/react-query';
import {cloneDeep} from  "lodash";
import { createIncentiveCycle, IncentiveCyclePayload, calculateIncentivesForCycleApi, approveIncentiveCycle, updatecalculateIncentivesForCycleApi ,cancelIncentiveCycle, deleteAllApprovedCycles, deleteIncentiveCycle } from '../network/incentiveCycleApi';

interface IncentiveCycleManagerProps {
  candidates: Candidate[];
  cycles: IncentiveCycle[];
  setCycles: React.Dispatch<React.SetStateAction<IncentiveCycle[]>>;
  retroactiveIncentives: RetroactiveIncentive[];
  setRetroactiveIncentives: React.Dispatch<React.SetStateAction<RetroactiveIncentive[]>>;
  coordinators: any[];
}

const IncentiveCycleManager: React.FC<IncentiveCycleManagerProps> = ({
  candidates,
  cycles,
  setCycles,
  retroactiveIncentives,
  setRetroactiveIncentives,
  coordinators
}) => {
  
  const [showHoursForm, setShowHoursForm] = useState(false);
  const [selectedCycle, setSelectedCycle] = useState<IncentiveCycle | null>(null);
  const [showReports, setShowReports] = useState(false);
  const [cancellingCycle, setCancellingCycle] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [showRetroactiveDetails, setShowRetroactiveDetails] = useState(false);
  const [showTotalIncentiveReport, setShowTotalIncentiveReport] = useState<IncentiveCycle | null>(null);
  const [deletingAll, setDeletingAll] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Get current month in YYYY-MM format
  const getCurrentMonth = (): string => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  };

  // Get next month in YYYY-MM format
  const getNextMonth = (currentMonth: string): string => {
    const [year, month] = currentMonth.split('-').map(Number);
    const nextDate = new Date(year, month, 1); // month is already 1-based
    return `${nextDate.getFullYear()}-${String(nextDate.getMonth() + 1).padStart(2, '0')}`;
  };

  // Format month for display
  const formatMonth = (month: string): string => {
    try {
      const [year, monthNum] = month.split('-');
      return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long'
      });
    } catch (error) {
      return month;
    }
  };

  // Check if there's an active (non-approved) cycle
  const hasActiveCycle = (): boolean => {
    return cycles.some(cycle => {
      const status = cycle.status.toLowerCase();
      return status !== 'approved' && status !== 'cancelled';
    });
  };

  // Get the current active cycle
  const getActiveCycle = (): IncentiveCycle | null => {
    return cycles.find(cycle => {
      const status = cycle.status.toLowerCase();
      return status !== 'approved' && status !== 'cancelled';
    }) || null;
  };

  // Get the next available month for new cycle
  const getNextAvailableMonth = (): string => {
    const approvedCycles = cycles.filter(c => c.status.toLowerCase() === 'approved');
    if (approvedCycles.length === 0) {
      // Start from March of the current year
      const now = new Date();
      return `${now.getFullYear()}-03`;
    }

    // Get the latest approved month
    const latestApprovedMonth = approvedCycles
      .map(cycle => cycle.month)
      .sort()
      .pop();

    if (!latestApprovedMonth) {
      // Fallback to March if something goes wrong
      const now = new Date();
      return `${now.getFullYear()}-03`;
    }
    return getNextMonth(latestApprovedMonth);
  };

 

  useEffect(() => {
    try {
      // generateRetroactiveIncentives returns IncentiveData[], but we need RetroactiveIncentive[]
      const retroactiveData = generateRetroactiveIncentives(candidates, cycles.filter(c => c.status === 'approved' || c.status === 'APPROVED'));
      // Map IncentiveData[] to RetroactiveIncentive[]
      const retroactive: RetroactiveIncentive[] = retroactiveData.map((item) => ({
        candidateId: item.candidateId,
        candidateName: item.candidateName,
        // Try to infer month from the latest approved cycle, fallback to empty string
        month: cycles.filter(c => c.status === 'approved' || c.status === 'APPROVED').slice(-1)[0]?.month || '',
        reason: item.reason,
      }));
      setRetroactiveIncentives(retroactive);
    } catch (error) {
      console.error('Error generating retroactive incentives:', error);
      setRetroactiveIncentives([]);
    }
  }, [candidates, cycles]);

  // Type guard for error with message
  function isErrorWithMessage(err: unknown): err is { message: string } {
    return typeof err === 'object' && err !== null && 'message' in err && typeof (err as any).message === 'string';
  }

  // useMutation for creating incentive cycle
  const createCycleMutation = useMutation({
    mutationFn: (payload: IncentiveCyclePayload) => createIncentiveCycle(payload),
    onSuccess: (data) => {
      setCycles(prev => [...prev, data]);
      setSelectedCycle(data);
      setShowHoursForm(true);
    },
    onError: (error: unknown) => {
      const errMsg = error instanceof Error ? error.message : 'Unknown error';
      alert('Failed to create incentive cycle: ' + errMsg);
    }
  });

  const approveCycleMutation = useMutation({
    mutationFn: (cycleId: string) => approveIncentiveCycle(cycleId),
    onSuccess: (updatedCycle) => {
      const normalizedCycle = {
        ...updatedCycle,
        status: updatedCycle.status.toLowerCase(), // Normalize status
        // Preserve existing calculations if API doesn't return them
        incentiveCalculations: updatedCycle.incentiveCalculations || 
                             cycles.find(c => c.id === updatedCycle.id)?.incentiveCalculations || []
      };
      setCycles(prev => prev.map(c => c.id === updatedCycle.id ? normalizedCycle : c));
      alert(`Incentive cycle for ${formatMonth(updatedCycle.month)} has been approved and locked.`);
    },
    onError: (error: unknown) => {
      const errMsg = error instanceof Error ? error.message : 'Unknown error';
      alert('Failed to approve incentive cycle: ' + errMsg);
    }
  });

  // useMutation for cancelling incentive cycle
  const cancelCycleMutation = useMutation({
    mutationFn: ({ cycleId, reason }: { cycleId: string; reason: string }) => cancelIncentiveCycle(cycleId, reason),
    onSuccess: (updatedCycle) => {
      setCycles(prev => prev.map(c =>
        c.id === updatedCycle.id
          ? { ...c, ...updatedCycle, status: 'cancelled', cancelledAt: updatedCycle.cancelledAt, cancellationReason: updatedCycle.cancellationReason }
          : c
      ));
      setCancellingCycle(null);
      setCancelReason('');
      alert('Cycle cancelled successfully.');
    },
    onError: (error: unknown) => {
      const errMsg = isErrorWithMessage(error) ? error.message : 'Unknown error';
      alert('Failed to cancel cycle: ' + errMsg);
    }
  });

  const calculateIncentives1 = (cycle: IncentiveCycle) => {
    try {
      // Get approved cycles for total hours calculation
      const approvedCycles = cycles.filter(c => c.status === 'approved' || c.status === 'APPROVED');
      
      // Calculate incentives using the updated function
      const calculatedIncentives = calculateIncentivesForCycle(cycle, candidates, approvedCycles);

      // const updatedCycle = {
      //   ...cycle,
      //   status: 'CALCULATED' as const,
      //   calculatedAt: new Date().toISOString(),
      //   incentiveCalculations: calculatedIncentives
      // };
      
      const tempCal = cloneDeep(calculatedIncentives)
      for(let i=0;i<tempCal.length;i++) {
        tempCal[i].coordinatorType = getCordinatorType (tempCal[i].coordinatorType)
        tempCal[i].coordinatorName =  tempCal[i].coordinatorName.name
      }

      calculateIncentivesMutation.mutate({ cycleId: cycle.id, incentiveCalculation: tempCal });
      
    } catch (error) {
      console.error('Error calculating incentives:', error);
      let message = 'Please check the data and try again.';
      if (error instanceof Error) message = error.message;
      alert(`Error calculating incentives: ${message}`);
    }
  };

  const getCordinatorType = (type: string) => {
    // RECRUITER, CRM, TEAM_LEAD, MANAGER, SENIOR_MANAGER, ASSO_DIRECTOR, CENTER_HEAD
    switch (type) {
      case 'recruiter':
        return 'RECRUITER';
      case 'crm':
        return 'CRM';
      case 'teamLead':
        return 'TEAM_LEAD';
      case 'manager':
        return 'MANAGER';
      case 'seniorManager':
        return 'SENIOR_MANAGER';
      case 'assoDirector':
        return 'ASSO_DIRECTOR';
      case 'centerHead':
        return 'CENTER_HEAD';
      default:
        return type;
    }
  }


  // // useMutation for calculating incentives
  // const calculateIncentivesMutation = useMutation({
  //   mutationFn: (cycleId: string) => calculateIncentivesForCycleApi(cycleId),
  //   onSuccess: (updatedCycle) => {
  //     const normalizedCycle = {
  //       ...updatedCycle,
  //       incentiveCalculations: updatedCycle.incentiveCalculations || []
  //     };
  //     setCycles(prev => prev.map(c => c.id === normalizedCycle.id ? normalizedCycle : c));
  //   },
  //   onError: (error: unknown) => {
  //     const errMsg = error instanceof Error ? error.message : 'Unknown error';
  //     alert('Failed to calculate incentives: ' + errMsg);
  //   }
  // });


  const calculateIncentivesMutation = useMutation({
    mutationFn: ({ cycleId, incentiveCalculation }: { cycleId: string; incentiveCalculation: IncentiveCalculation[] }) => updatecalculateIncentivesForCycleApi(cycleId, incentiveCalculation),
    onSuccess: (updatedCycle, variables) => {
      setCycles(prev => prev.map(c => c.id == variables.cycleId ? updatedCycle : c));
      
    },
    onError: (error: unknown) => {
      const errMsg = error instanceof Error ? error.message : 'Unknown error';
      alert('Failed to calculate incentives: ' + errMsg);
    }
  });

  const deleteCycleMutation = useMutation({
    mutationFn: (cycleId: string) => deleteIncentiveCycle(cycleId),
    onSuccess: (_data, cycleId) => {
      setCycles(prev => prev.filter(c => c.id !== cycleId));
    },
    onError: (error: unknown) => {
      const errMsg = error instanceof Error ? error.message : 'Unknown error';
      alert('Failed to delete incentive cycle: ' + errMsg);
    }
  });

  const handleDeleteCycle = (cycleId: string) => {
    if (window.confirm('Are you sure you want to delete this incentive cycle? This action cannot be undone.')) {
      deleteCycleMutation.mutate(cycleId);
    }
  };

  // Start a new incentive cycle
  const startIncentiveCycle = () => {
    if (hasActiveCycle()) {
      alert('Cannot start a new cycle. Please complete or cancel the current active cycle first.');
      return;
    }

    const nextMonth = getNextAvailableMonth();
    const payload: IncentiveCyclePayload = {
      month: nextMonth,
      type: 'REGULAR',
      notes: `Incentive cycle for ${formatMonth(nextMonth)}`
    };
    createCycleMutation.mutate(payload);
  };

  // Start a new incentive cycle
  const startAdditionalCycle = () => {
    if (hasActiveCycle()) {
      alert('Cannot start additional cycle. Please complete or cancel the current active cycle first.');
      return;
    }
  
    const approvedCycles = cycles.filter(c => c.status === 'approved' || c.status === 'APPROVED');
    if (approvedCycles.length === 0) {
      alert('No approved cycles found. Cannot create additional cycle.');
      return;
    }
  
    // Get the most recently approved cycle
    const latestApproved = approvedCycles.reduce((latest, cycle) => {
      return new Date(cycle.approvedAt || 0) > new Date(latest.approvedAt || 0) ? cycle : latest;
    });
  
    const payload: IncentiveCyclePayload = {
      month: latestApproved.month,
      type: 'ADDITIONAL', // <-- Set as ADDITIONAL
      notes: `Additional incentive cycle for ${formatMonth(latestApproved.month)}`
    };
    createCycleMutation.mutate(payload);
  };

  // Add hours to cycle
  const addHours = (cycle: IncentiveCycle) => {
    // If cycle is calculated and we're modifying hours, reset to draft status
    if (cycle.status === 'calculated'||cycle.status === 'CALCULATED') {
      setCycles(prev => prev.map(c =>
        c.id === cycle.id
          ? { ...c, status: 'draft' as const }
          : c
      ));
    }

    setSelectedCycle(cycle);
    setShowHoursForm(true);
  };

  // Calculate incentives for cycle (calls API)
  const calculateIncentives = (cycle: IncentiveCycle) => {
    // calculateIncentivesMutation.mutate(cycle.id);
  };

  // Make changes to calculated cycle
  const makeChanges = (cycle: IncentiveCycle) => {
    const updatedCycle = {
      ...cycle,
      status: 'draft' as const
    };

    setCycles(prev => prev.map(c => c.id === cycle.id ? updatedCycle : c));
  };

  // Approve cycle
  const approveCycle = (cycle: IncentiveCycle) => {
    if (window.confirm(`Are you sure you want to approve the incentive cycle for ${formatMonth(cycle.month)}? This action cannot be undone and will lock all processed hours for this month.`)) {
      approveCycleMutation.mutate(cycle.id);
    }
  };

  // Cancel cycle
  const handleCancelCycle = () => {
    if (!cancellingCycle || !cancelReason.trim()) {
      alert('Please provide a reason for cancellation');
      return;
    }

    cancelCycleMutation.mutate({ cycleId: cancellingCycle, reason: cancelReason.trim() });
  };

  // Save cycle hours
  const handleSaveCycleHours = (incentiveCycle:IncentiveCycle, monthlyHours: any[]) => {
    setCycles(prev => prev.map(cycle => {
      if (cycle.id === incentiveCycle.id) {
        return {
          ...incentiveCycle
          // ...cycle,
          // monthlyHours
        };
      }
      return cycle;
    }));
    setShowHoursForm(false);
    setSelectedCycle(null);
  };
  // useEffect(() => {
  //   console.log('Cycles state updated:', {
  //     allCycles: cycles,
  //     activeCycle: getActiveCycle(),
  //     approvedCycles: cycles.filter(c => c.status.toLowerCase() === 'approved')
  //   });
  // }, [cycles]);
  const activeCycle = getActiveCycle();
  const approvedCycles = cycles.filter(c => c.status.toLowerCase() === 'approved');
  const pendingRetroactive = retroactiveIncentives.filter(r => !r.addedToCycle);
  const canStartNewCycle = !hasActiveCycle();

  const allApprovedIncentives = approvedCycles.flatMap(cycle => cycle.incentiveCalculations || []);

  // Handler for deleting all approved cycles
  const handleDeleteAllApprovedCycles = async () => {
    if (!window.confirm('Are you sure you want to delete ALL approved cycles? This action cannot be undone.')) return;
    setDeletingAll(true);
    setDeleteError(null);
    try {
      await deleteAllApprovedCycles();
      setCycles(prev => prev.filter(c => c.status.toLowerCase() !== 'approved'));
    } catch (err: any) {
      setDeleteError(err?.message || 'Failed to delete all approved cycles.');
    } finally {
      setDeletingAll(false);
    }
  };


  return (
    <div className="space-y-6">
      {/* Header with Cycle Controls */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center">
              <Calendar className="w-6 h-6 mr-3 text-blue-600" />
              Incentive Cycle Management
            </h2>
            <p className="text-gray-600 mt-1">Manage monthly incentive cycles with calendar-based automation</p>
          </div>

          <div className="flex items-center space-x-3">
            {canStartNewCycle && (
              <>
                <button
                  onClick={startIncentiveCycle}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 font-medium"
                  disabled={createCycleMutation.isPending}
                >
                  <Play className="w-5 h-5" />
                  <span>{createCycleMutation.isPending ? 'Starting...' : 'Start Incentive Cycle'}</span>
                </button>
                {createCycleMutation.isError && (
                  <span className="text-red-600 text-sm ml-2">{
                    createCycleMutation.error &&
                    typeof createCycleMutation.error === 'object' &&
                    'message' in createCycleMutation.error
                      ? (createCycleMutation.error as Error).message
                      : 'Error'
                  }</span>
                )}

                {approvedCycles.length > 0 && (
                  <button
                    onClick={startAdditionalCycle}
                    className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2 font-medium"
                  >
                    <TrendingUp className="w-5 h-5" />
                    <span>Additional Cycle</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>

        {/* Next Available Month Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Calendar className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="font-medium text-blue-900">
                {canStartNewCycle ? 'Ready to Start' : 'Active Cycle'}
              </h3>
              <p className="text-blue-700 text-sm">
                {canStartNewCycle
                  ? `Next available cycle: ${formatMonth(getNextAvailableMonth())}`
                  : `Current active cycle: ${activeCycle ? formatMonth(activeCycle.month) : 'None'}`
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Active Cycle Details */}
      {activeCycle && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 flex items-center">
                <Clock className="w-5 h-5 mr-2 text-orange-500" />
                Active Cycle: {formatMonth(activeCycle.month)}
                {activeCycle.type === 'additional' && (
                  <span className="ml-3 bg-purple-100 text-purple-800 text-sm px-3 py-1 rounded-full">
                    Additional
                  </span>
                )}
              </h3>
              <p className="text-gray-600 mt-1">
                Started: {new Date(activeCycle.startedAt).toLocaleDateString()} •
                Status: <span className="font-medium capitalize">{activeCycle.status}</span>
              </p>
            </div>

            <div className="flex items-center space-x-3">
              {activeCycle && activeCycle.status.toLowerCase() === 'draft' && (
                <>
                  <button
                    onClick={() => addHours(activeCycle)}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                  >
                    <Users className="w-4 h-4" />
                    <span>Add Hours</span>
                  </button>

                  {(activeCycle.monthlyHours ?? []).length > 0 && (
                    <button
                      onClick={() => calculateIncentives1(activeCycle)}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                      disabled={calculateIncentivesMutation.isPending}
                    >
                      <Calculator className="w-4 h-4" />
                      <span>{calculateIncentivesMutation.isPending ? 'Calculating...' : 'Calculate Incentive'}</span>
                    </button>
                  )}
                </>
              )}

              {(activeCycle.status.toLowerCase() === 'draft' || activeCycle.status.toLowerCase() === 'calculated') && (activeCycle.monthlyHours ?? []).length > 0 && (
                <button
                  onClick={() => addHours(activeCycle)}
                  className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
                >
                  <Edit className="w-4 h-4" />
                  <span>Modify Hours</span>
                </button>
              )}

              {activeCycle.status.toLowerCase() === 'calculated' && (
                <>
                  <button
                    onClick={() => makeChanges(activeCycle)}
                    className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Make Changes</span>
                  </button>

                  <button
                    onClick={() => approveCycle(activeCycle)}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Approve</span>
                  </button>
                </>
              )}

              <button
                onClick={() => setCancellingCycle(activeCycle.id)}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
              >
                <XCircle className="w-4 h-4" />
                <span>Cancel</span>
              </button>
            </div>
          </div>

          {/* Cycle Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Candidates with Hours</p>
                  <p className="text-2xl font-bold text-gray-900">{(activeCycle.monthlyHours ?? []).length}</p>
                </div>
                <Users className="w-8 h-8 text-gray-400" />
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 text-sm font-medium">Total Hours</p>
                  <p className="text-2xl font-bold text-blue-900">
                    {(activeCycle.monthlyHours ?? []).reduce((sum, h) => sum + (h.hoursWorked || 0), 0)}
                  </p>
                </div>
                <Clock className="w-8 h-8 text-blue-400" />
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600 text-sm font-medium">Incentive Calculations</p>
                  <p className="text-2xl font-bold text-green-900">
                  {(activeCycle?.incentiveCalculations || []).length}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-green-400" />
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-600 text-sm font-medium">Total Incentives</p>
                  <p className="text-2xl font-bold text-purple-900">
                    {`₹${(activeCycle.incentiveCalculations ?? []).reduce((sum, calc) => sum + calc.incentiveAmount, 0).toLocaleString('en-IN')}`}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-400" />
              </div>
            </div>
          </div>

          {/* View Total Incentive Report Button - Only show for calculated cycles */}
          {activeCycle.status.toLowerCase() === 'calculated' && (activeCycle.incentiveCalculations ?? []).length >= 0 && (
            <div className="mt-4 flex justify-center">
              <button
                onClick={() => setShowTotalIncentiveReport(activeCycle)}
                className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center space-x-2 font-medium"
              >
                <BarChart3 className="w-5 h-5" />
                <span>View Total Incentive Report</span>
              </button>
            </div>
          )}

          {activeCycle.calculatedAt && (
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-blue-700 text-sm">
                <strong>Calculated:</strong> {new Date(activeCycle.calculatedAt).toLocaleString()}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Pending Retroactive Incentives */}
      {pendingRetroactive.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg overflow-hidden">
          <div
            className="p-4 cursor-pointer hover:bg-yellow-100 transition-colors"
            onClick={() => setShowRetroactiveDetails(!showRetroactiveDetails)}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-yellow-800 flex items-center">
                <AlertCircle className="w-5 h-5 mr-2" />
                Pending Retroactive Incentives ({pendingRetroactive.length})
              </h2>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-yellow-700">
                  {showRetroactiveDetails ? 'Hide Details' : 'Show Details'}
                </span>
                {showRetroactiveDetails ? (
                  <ChevronDown className="w-5 h-5 text-yellow-700" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-yellow-700" />
                )}
              </div>
            </div>
            {!showRetroactiveDetails && (
              <p className="text-sm text-yellow-700 mt-1">
                Click to view {pendingRetroactive.length} candidate{pendingRetroactive.length !== 1 ? 's' : ''} with missing hours entries
              </p>
            )}
          </div>

          {showRetroactiveDetails && (
            <div className="px-4 pb-4">
              <div className="bg-white rounded-lg border border-yellow-300 p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {pendingRetroactive.map((retro, index) => (
                    <div key={index} className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 hover:bg-yellow-100 transition-colors">
                      <div className="font-medium text-gray-800">{retro.candidateName}</div>
                      <div className="text-sm text-gray-600">
                        {retro.month ? formatMonth(retro.month) : 'Invalid date'}
                      </div>
                      <div className="text-xs text-yellow-700 mt-1 flex items-center">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        {retro.reason || 'Missing hours entry'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Approved Cycles Summary */}
      {approvedCycles.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-800 flex items-center">
              <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
              Approved Cycles ({approvedCycles.length})
            </h2>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowReports(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
              >
                <Calendar className="w-4 h-4" />
                <span>View Reports</span>
              </button>
              <button
                onClick={handleDeleteAllApprovedCycles}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2 disabled:opacity-50"
                disabled={deletingAll}
              >
                <XCircle className="w-4 h-4" />
                <span>{deletingAll ? 'Deleting...' : 'Delete All Cycles'}</span>
              </button>
            </div>
          </div>
          {deleteError && <div className="text-red-600 mb-2">{deleteError}</div>}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {approvedCycles.slice(-6).map(cycle => (
              <div key={cycle.id} className="border border-green-200 rounded-lg p-4 bg-green-50">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-gray-800">
                    {formatMonth(cycle.month)}
                    {cycle.type === 'additional' && (
                      <span className="ml-2 bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">
                        Additional
                      </span>
                    )}
                  </h3>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <button
                      onClick={() => handleDeleteCycle(cycle.id)}
                      title="Delete Cycle"
                      className="p-1 rounded hover:bg-red-100"
                      disabled={deleteCycleMutation.isPending}
                    >
                      <Trash className="w-5 h-5 text-red-600" />
                    </button>
                  </div>
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <div>Approved: {new Date(cycle.approvedAt!).toLocaleDateString()}</div>
                  <div>Candidates: {(cycle.monthlyHours ?? []).length}</div>
                  <div>Hours: {(cycle.monthlyHours ?? []).reduce((sum, h) => sum + (h.hoursWorked || 0), 0)}</div>
                  {cycle.incentiveCalculations && (
                    <div className="font-medium text-green-700">
                      Incentives: {cycle.incentiveCalculations.length}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Cancel Cycle Modal */}
      {cancellingCycle && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Cancel Cycle</h3>
            <p className="text-gray-600 mb-4">
              Please provide a reason for cancelling this cycle:
            </p>
            <textarea
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="Enter cancellation reason..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
              rows={3}
            />
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => {
                  setCancellingCycle(null);
                  setCancelReason('');
                }}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleCancelCycle}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Confirm Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hours Form Modal */}
      {showHoursForm && selectedCycle && (
        <CycleHoursForm
          cycle={selectedCycle}
          candidates={candidates}
          retroactiveIncentives={retroactiveIncentives}
          approvedCycles={approvedCycles}
          onSave={handleSaveCycleHours}
          onCancel={() => {
            setShowHoursForm(false);
            setSelectedCycle(null);
          }}
        />
      )}

      {/* Reports Modal */}
      {showReports && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-screen overflow-y-auto">
            <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">Approved Cycles Reports</h2>
              <button
                onClick={() => setShowReports(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6">
              <IncentiveReports incentives={allApprovedIncentives} />
            </div>
          </div>
        </div>
      )}

      {/* Total Incentive Report Modal */}
      {showTotalIncentiveReport && (
        <TotalIncentiveReportModal
          cycle={showTotalIncentiveReport}
          candidates={candidates}
          onClose={() => setShowTotalIncentiveReport(null)}
        />
      )}
    </div>
  );
};

export default IncentiveCycleManager;