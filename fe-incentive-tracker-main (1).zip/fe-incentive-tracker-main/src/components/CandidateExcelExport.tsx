import React from 'react';
import * as XLSX from 'xlsx';
import { Download, FileSpreadsheet, X } from 'lucide-react';
import { Candidate } from '../types';

interface CandidateExcelExportProps {
  candidates: Candidate[];
  onClose: () => void;
}

export const CandidateExcelExport: React.FC<CandidateExcelExportProps> = ({
  candidates,
  onClose
}) => {
  const formatCurrency = (amount: number | undefined | null) => {
    if (amount === undefined || amount === null || isNaN(amount)) {
      return '$0.00';
    }
    return `$${amount.toFixed(2)}`;
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatPercentage = (value: number | undefined | null) => {
    if (value === undefined || value === null || isNaN(value)) {
      return '0%';
    }
    return `${(value * 100).toFixed(2)}%`;
  };

  const getCoordinatorName = (coordinator: any) => {
    return coordinator?.name || 'N/A';
  };

  const exportToExcel = () => {
    // Create main candidate data worksheet
    const candidateData = candidates.map(candidate => ({
      'Candidate ID': candidate.candidateId,
      'Candidate Name': candidate.candidateName,
      'Client Name': candidate.clientName,
      'Contract Type': candidate.contractType,
      'Start Date': formatDate(candidate.startDate),
      'End Date': candidate.endDate ? formatDate(candidate.endDate) : 'Active',
      'Status': candidate.endDate ? 'Inactive' : 'Active',
      'Pay Rate': formatCurrency(candidate.payRate),
      'W2 Payroll Admin Taxes %': formatPercentage(candidate.w2PayrollAdminTaxesPercentage),
      'W2 Payroll Admin Taxes $': formatCurrency(candidate.w2PayrollAdminTaxes),
      'W2/C2C Overhead Cost %': formatPercentage(candidate.w2C2COverheadCostPercentage),
      'W2/C2C Overhead Cost $': formatCurrency(candidate.w2C2COverheadCost),
      'Health Benefits': formatCurrency(candidate.healthBenefits),
      'Net Purchase': formatCurrency(candidate.netPurchase),
      'Bill Rate': formatCurrency(candidate.billRate),
      'MSP Fees %': formatPercentage(candidate.mspFeesPercentage),
      'MSP Fees $': formatCurrency(candidate.mspFeesDollar),
      'Net Bill Rate': formatCurrency(candidate.netBillRate),
      'Current Margin': formatCurrency(candidate.margin),
      'Finder Fees': candidate.finderFees ? formatCurrency(candidate.finderFees) : 'N/A',
      'Recruiter': getCoordinatorName(candidate.recruiter),
      'Team Lead': getCoordinatorName(candidate.lead),
      'Manager': getCoordinatorName(candidate.manager),
      'Senior Manager': getCoordinatorName(candidate.seniorManager),
      'Associate Director': getCoordinatorName(candidate.assoDirector),
      'Center Head': getCoordinatorName(candidate.centerHead),
      'CRM': getCoordinatorName(candidate.crm),
      'Candidate Source': candidate.candidateSource || 'N/A',
      'Other Name': candidate.otherName || 'N/A',
      'Margin Revisions Count': candidate.marginRevisions?.length || 0,
      'Last Updated': candidate.marginRevisions && candidate.marginRevisions.length > 0 
        ? formatDate(candidate.marginRevisions[candidate.marginRevisions.length - 1].effectiveDate)
        : formatDate(candidate.startDate)
    }));

    // Create margin revisions worksheet
    const marginRevisionsData: any[] = [];
    candidates.forEach(candidate => {
      if (candidate.marginRevisions && candidate.marginRevisions.length > 0) {
        candidate.marginRevisions.forEach(revision => {
          marginRevisionsData.push({
            'Candidate ID': candidate.candidateId,
            'Candidate Name': candidate.candidateName,
            'Client Name': candidate.clientName,
            'Revision Date': formatDate(revision.effectiveDate),
            'Contract Type': revision.contractType || candidate.contractType,
            'Pay Rate': formatCurrency(revision.payRate || candidate.payRate),
            'W2 Payroll Admin Taxes %': formatPercentage(revision.w2PayrollAdminTaxesPercentage),
            'W2/C2C Overhead Cost %': formatPercentage(revision.w2C2COverheadCostPercentage),
            'Health Benefits': formatCurrency(revision.healthBenefits),
            'Bill Rate': formatCurrency(revision.billRate || candidate.billRate),
            'MSP Fees %': formatPercentage(revision.mspFeesPercentage),
            'Finder Fees': revision.finderFees ? formatCurrency(revision.finderFees) : 'N/A',
            'W2 Payroll Admin Taxes $': formatCurrency(revision.w2PayrollAdminTaxes),
            'W2/C2C Overhead Cost $': formatCurrency(revision.w2C2COverheadCost),
            'Net Purchase': formatCurrency(revision.netPurchase),
            'MSP Fees $': formatCurrency(revision.mspFeesDollar),
            'Net Bill Rate': formatCurrency(revision.netBillRate),
            'Margin': formatCurrency(revision.margin),
            'Reason': revision.reason || 'N/A',
            'Created By': revision.createdBy || 'N/A',
            'Created At': formatDate(revision.createdAt)
          });
        });
      }
    });

    // Create workbook with multiple sheets
    const workbook = XLSX.utils.book_new();

    // Add candidate data sheet
    const candidateWorksheet = XLSX.utils.json_to_sheet(candidateData);
    XLSX.utils.book_append_sheet(workbook, candidateWorksheet, 'Candidates');

    // Add margin revisions sheet if there are any revisions
    let revisionsWorksheet: XLSX.WorkSheet | undefined;
    if (marginRevisionsData.length > 0) {
      revisionsWorksheet = XLSX.utils.json_to_sheet(marginRevisionsData);
      XLSX.utils.book_append_sheet(workbook, revisionsWorksheet, 'Margin Revisions');
    }

    // Auto-size columns for candidate sheet
    const candidateColWidths = Object.keys(candidateData[0] || {}).map(key => ({
      wch: Math.min(Math.max(key.length + 2, 12), 30)
    }));
    candidateWorksheet['!cols'] = candidateColWidths;

    // Auto-size columns for revisions sheet if it exists
    if (marginRevisionsData.length > 0 && revisionsWorksheet) {
      const revisionsColWidths = Object.keys(marginRevisionsData[0] || {}).map(key => ({
        wch: Math.min(Math.max(key.length + 2, 12), 25)
      }));
      revisionsWorksheet['!cols'] = revisionsColWidths;
    }

    // Generate filename with timestamp
    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `candidates_export_${timestamp}.xlsx`;

    // Download the file
    XLSX.writeFile(workbook, filename);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <FileSpreadsheet className="w-6 h-6 text-green-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Export Candidates to Excel</h2>
              <p className="text-sm text-gray-500">
                Export {candidates.length} candidate{candidates.length !== 1 ? 's' : ''} with comprehensive data
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Export Summary */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-medium text-blue-900 mb-2">Export Summary</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-blue-700">Total Candidates:</span>
                <span className="ml-2 font-medium">{candidates.length}</span>
              </div>
              <div>
                <span className="text-blue-700">Active Candidates:</span>
                <span className="ml-2 font-medium">
                  {candidates.filter(c => !c.endDate).length}
                </span>
              </div>
              <div>
                <span className="text-blue-700">Candidates with Revisions:</span>
                <span className="ml-2 font-medium">
                  {candidates.filter(c => c.marginRevisions && c.marginRevisions.length > 0).length}
                </span>
              </div>
              <div>
                <span className="text-blue-700">Total Margin Revisions:</span>
                <span className="ml-2 font-medium">
                  {candidates.reduce((total, c) => total + (c.marginRevisions?.length || 0), 0)}
                </span>
              </div>
            </div>
          </div>

          {/* Data Included */}
          <div>
            <h3 className="font-medium text-gray-900 mb-3">Data Included in Export</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Basic candidate information</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Financial data (rates, margins, fees)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Team assignments (recruiter, lead, manager)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Contract details and status</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Margin revision history (separate sheet)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Calculated fields and percentages</span>
              </div>
            </div>
          </div>

          {/* Export Options */}
          <div>
            <h3 className="font-medium text-gray-900 mb-3">Export Options</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>• File will be downloaded as: <code className="bg-gray-100 px-2 py-1 rounded">candidates_export_YYYY-MM-DD.xlsx</code></p>
              <p>• Excel file will contain multiple worksheets for better organization</p>
              <p>• All currency values are formatted for easy reading</p>
              <p>• Dates are formatted in MM/DD/YYYY format</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end space-x-3 p-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={exportToExcel}
            className="px-6 py-2 bg-green-600 text-white hover:bg-green-700 rounded-lg transition-colors flex items-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>Export to Excel</span>
          </button>
        </div>
      </div>
    </div>
  );
};
