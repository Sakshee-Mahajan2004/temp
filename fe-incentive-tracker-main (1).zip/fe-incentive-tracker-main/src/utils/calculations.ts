import { Candidate, IncentiveCycle, CycleHours, IncentiveData, CoordinatorIncentive } from '../types';

// Margin-based incentive tiers for recruiters
const RECRUITER_MARGIN_TIERS = [
  { min: 40.01, max: 50.00, amount: 10000 },
  { min: 30.01, max: 40.00, amount: 7000 },
  { min: 20.01, max: 30.00, amount: 4500 },
  { min: 15.01, max: 20.00, amount: 4000 },
  { min: 10.01, max: 15.00, amount: 3500 },
  { min: 8.01, max: 10.00, amount: 2500 },
  { min: 6.01, max: 8.00, amount: 2000 },
  { min: 4.01, max: 6.00, amount: 1500 },
  { min: 2.01, max: 4.00, amount: 1000 },
  { min: 1.00, max: 2.00, amount: 500 }
];

// One-time incentives for coordinators (paid once at 160 hours)
const LOCAL_ONE_TIME_INCENTIVES:any = {
  'CRM': 1000,
  'Manager': 1500,
  'Senior Manager': 1500,
  'Associate Director': 1750,
  'Center Head': 1500
};

// Calculate total hours for a candidate across all approved cycles
export function calculateTotalHours(candidateId: string, approvedCycles: IncentiveCycle[]): number {
  let totalHours = 0;
  
  for (const cycle of approvedCycles) {
    const candidateHours = cycle.monthlyHours?.find(ch => ch.candidateId === candidateId);
    if (candidateHours?.hoursWorked) {
      totalHours += Number(candidateHours.hoursWorked) || 0;
    }
  }
  
  return totalHours;
}

// Check if candidate has reached 160 hours milestone
export function hasReached160Hours(candidateId: string, approvedCycles: IncentiveCycle[]): boolean {
  return calculateTotalHours(candidateId, approvedCycles) >= 160;
}

// Check if one-time incentive has been paid for a candidate
export function hasReceivedOneTimeIncentive(candidateId: string, coordinatorName: string, approvedCycles: IncentiveCycle[]): boolean {
  for (const cycle of approvedCycles) {
    const incentive = cycle.incentives?.find(inc => 
      inc.candidateId === candidateId && 
      inc.coordinatorName === coordinatorName &&
      inc.isOneTime
    );
    if (incentive && incentive.amount > 0) {
      return true;
    }
  }
  return false;
}

// Get recruiter incentive amount based on margin
export function getRecruiterIncentiveAmount(margin: number): number {
  // For margin <= $0.99, one-time incentive of ₹2,000
  if (margin <= 0.99) {
    return 2000;
  }
  
  // Find the appropriate tier
  for (const tier of RECRUITER_MARGIN_TIERS) {
    if (margin >= tier.min && margin <= tier.max) {
      return tier.amount;
    }
  }
  
  return 0;
}

// Calculate pro-rata incentive based on hours worked
export function calculateProRataIncentive(baseAmount: number, hoursWorked: number): number {
  if (hoursWorked >= 160) {
    return baseAmount;
  }
  return Math.round((baseAmount * hoursWorked) / 160);
}

// Calculate incentives for a single candidate in a cycle
export function calculateIncentivesForCandidate(
  candidate: Candidate,
  cycleHours: CycleHours,
  approvedCycles: IncentiveCycle[]
): IncentiveData[] {
  const incentives: IncentiveData[] = [];
  
  try {
    const candidateId = candidate.candidateId;
    const hoursWorked = Number(cycleHours.hoursWorked) || 0;
    const margin = Number(candidate.margin) || 0;
    
    // Skip if no hours worked
    if (hoursWorked <= 0) {
      return incentives;
    }
    
    // Calculate total hours across all cycles
    const totalHours = calculateTotalHours(candidateId, approvedCycles) + hoursWorked;
    const hasReached160 = totalHours >= 160;
    const previouslyReached160 = hasReached160Hours(candidateId, approvedCycles);
    
    // Handle W2 and C2C candidates
    if (candidate.contractType === 'W2' || candidate.contractType === 'C2C') {
      
      // If candidate hasn't reached 160 hours and project is ending
      if (!hasReached160 && margin > 0) {
        // Only recruiter gets ₹2,000 one-time incentive
        if (candidate.recruiter?.name) {
          incentives.push({
            candidateId,
            candidateName: candidate.candidateName,
            coordinatorName: candidate.recruiter?.name,
            coordinatorType: 'recruiter',
            amount: 2000,
            isOneTime: true,
            reason: 'Early termination incentive'
          });
        }
        return incentives;
      }
      
      // If candidate has reached 160 hours
      if (hasReached160) {
        
        // Recruiter incentives (recurring)
        if (candidate.recruiter?.name) {
          let recruiterBaseAmount = getRecruiterIncentiveAmount(margin);
          let totalHours = calculateTotalHours(candidateId, approvedCycles) + hoursWorked;
          let extraHours = totalHours > 160 ? totalHours - 160 : 0;
          let perHourIncentive = recruiterBaseAmount / 160;
          let proRataIncentive = extraHours * perHourIncentive;
          let recruiterAmount = recruiterBaseAmount + proRataIncentive;

          // Apply pro-rata if current month has less than 160 hours
          if (totalHours < 160) {
            recruiterAmount = (recruiterBaseAmount * totalHours) / 160;
          }
          
          if (recruiterAmount > 0) {
            incentives.push({
              candidateId,
              candidateName: candidate.candidateName,
              coordinatorName: candidate.recruiter?.name,
              coordinatorType: 'recruiter',
              amount: recruiterAmount, 
              isOneTime: false,
              reason: `Recurring incentive for margin $${margin.toFixed(2)}`
            });
          }
        }
        
        // Team Lead incentives (recurring)
        if (candidate.lead?.name) {
          let teamLeadBaseAmount = 250;
          let extraHours = totalHours > 160 ? totalHours - 160 : 0;
          let perHourLeadIncentive = teamLeadBaseAmount / 160;
          let proRataLeadIncentive = extraHours * perHourLeadIncentive;
          let teamLeadAmount = teamLeadBaseAmount + proRataLeadIncentive;

          // If totalHours < 160, pro-rate for totalHours
          if (totalHours < 160) {
            teamLeadAmount = (teamLeadBaseAmount * totalHours) / 160;
          }
          
          incentives.push({
            candidateId,
            candidateName: candidate.candidateName,
            coordinatorName: candidate.lead?.name,
            coordinatorType: 'teamLead',
            amount: teamLeadAmount,
            isOneTime: false,
            reason: 'Team Lead recurring incentive'
          });
        }
        
        // One-time incentives (only if just reached 160 hours)
        if (!previouslyReached160) {
          const coordinators = [
            { name: candidate.crm?.name, role: 'CRM' },
            { name: candidate.manager?.name, role: 'Manager' },
            { name: candidate.seniorManager?.name, role: 'Senior Manager' },
            { name: candidate.assoDirector?.name, role: 'Associate Director' },
            { name: candidate.centerHead?.name, role: 'Center Head' }
          ];
          
          for (const coordinator of coordinators) {
            if (coordinator.name && LOCAL_ONE_TIME_INCENTIVES[coordinator.role]) {
              const hasReceived = hasReceivedOneTimeIncentive(candidateId, coordinator.name, approvedCycles);
              
              if (!hasReceived) {
                incentives.push({
                  candidateId,
                  candidateName: candidate.candidateName,
                  coordinatorName: coordinator.name,
                  coordinatorType: coordinator.role,
                  amount: LOCAL_ONE_TIME_INCENTIVES[coordinator.role],
                  isOneTime: true,
                  reason: `One-time incentive for reaching 160 hours (${coordinator.role})`
                });
              }
            }
          }
        }
      }
    }
    
    // Handle Full-Time candidates (existing logic)
    else if (candidate.contractType === 'FULLTIME') {
      const finderFees = Number(candidate.finderFees) || 0;
      
      // Recruiter incentive
      if (candidate.recruiter?.name) {
        const recruiterAmount = finderFees <= 4500 ? 15000 : 20000;
        incentives.push({
          candidateId,
          candidateName: candidate.candidateName,
          coordinatorName: candidate.recruiter?.name,
          coordinatorType: 'recruiter',
          amount: recruiterAmount,
          isOneTime: true,
          reason: `Full-time placement (Finder fees: $${finderFees})`
        });
      }
      
      // Other coordinator incentives
      const fullTimeIncentives = [
        { name: candidate.lead?.name, amount: 1000, role: 'Team Lead' },
        { name: candidate.manager?.name, amount: 1500, role: 'Manager' },
        { name: candidate.crm?.name, amount: 1500, role: 'CRM' },
        { name: candidate.assoDirector?.name, amount: 4000, role: 'Associate Director' },
        { name: candidate.centerHead?.name, amount: 4000, role: 'Center Head' }
      ];
      
      for (const coordinator of fullTimeIncentives) {
        if (coordinator.name) {
          incentives.push({
            candidateId,
            candidateName: candidate.candidateName,
            coordinatorName: coordinator.name,
            coordinatorType: coordinator.role,
            amount: coordinator.amount,
            isOneTime: true,
            reason: `Full-time placement (${coordinator.role})`
          });
        }
      }
    }
    
  } catch (error) {
    console.error('Error calculating incentives for candidate:', candidate.candidateId, error);
  }
  
  return incentives;
}

// Calculate incentives for an entire cycle
export function calculateIncentivesForCycle(
  cycle: IncentiveCycle,
  candidates: Candidate[],
  approvedCycles: IncentiveCycle[]
): IncentiveCalculation[] {
  const allIncentives: IncentiveCalculation[] = [];
  
  try {
    if (!cycle.monthlyHours || cycle.monthlyHours.length === 0) {
      console.warn('No monthly hours data found for cycle:', cycle.id);
      return allIncentives;
    }
    
    for (const monthlyHour of cycle.monthlyHours) {
      const candidate = candidates.find(c => c.candidateId === monthlyHour.candidateId);
      
      if (!candidate) {
        console.warn('Candidate not found for ID:', monthlyHour.candidateId);
        continue;
      }
      
      const hoursWorked = monthlyHour.hoursWorked;
      const margin = candidate.margin || 0;
      
      // Skip if no hours worked
      if (hoursWorked <= 0) {
        continue;
      }
      
      // Calculate total hours across all approved cycles for this candidate
      const totalHoursFromApproved = approvedCycles.reduce((total, approvedCycle) => {
        const approvedHours = approvedCycle.monthlyHours?.find(h => h.candidateId === candidate.candidateId);
        return total + (approvedHours?.hoursWorked || 0);
      }, 0);
      
      const totalHours = totalHoursFromApproved + hoursWorked;
      const hasReached160 = totalHours >= 160;
      const previouslyReached160 = totalHoursFromApproved >= 160;
      
      // Handle W2/C2C candidates
      if (candidate.contractType === 'W2' || candidate.contractType === 'C2C') {
        
        // If candidate hasn't reached 160 hours and project is ending (low margin case)
        if (!hasReached160 && margin <= 0.99 && candidate.recruiter) {
          allIncentives.push({
            coordinatorName: candidate.recruiter,
            coordinatorType: 'recruiter',
            candidateId: candidate.candidateId,
            candidateName: candidate.candidateName,
            month: cycle.month,
            hoursWorked,
            margin,
            incentiveAmount: 2000,
            isRecurring: false,
            isOneTime: true,
            notes: 'Early termination incentive'
          });
        }
        
        // If candidate has reached 160 hours
        if (hasReached160) {
          
          // Recruiter incentives (recurring)
          if (candidate.recruiter) {
            let recruiterBaseAmount = getRecruiterIncentiveAmount(margin);
            let totalHours = totalHoursFromApproved + hoursWorked;
            let extraHours = totalHours > 160 ? totalHours - 160 : 0;
            let perHourIncentive = recruiterBaseAmount / 160;
            let proRataIncentive = extraHours * perHourIncentive;
            let recruiterAmount = recruiterBaseAmount + proRataIncentive;


            // Apply pro-rata if current month has less than 160 hours
            if (totalHours < 160) {
              recruiterAmount = (recruiterBaseAmount * totalHours) / 160;
            }
            
            if (recruiterAmount > 0) {
              allIncentives.push({
                coordinatorName: candidate.recruiter,
                coordinatorType: 'recruiter',
                candidateId: candidate.candidateId,
                candidateName: candidate.candidateName,
                month: cycle.month,
                hoursWorked,
                margin,
                incentiveAmount: recruiterAmount,
                isRecurring: true,
                isOneTime: false,
                notes: `Recurring incentive for margin $${margin.toFixed(2)}`
              });
            }
          }
          
          // Team Lead incentives (recurring)
          if (candidate.lead) {
            let teamLeadBaseAmount = 250;
            let extraHours = totalHours > 160 ? totalHours - 160 : 0;
            let perHourLeadIncentive = teamLeadBaseAmount / 160;
            let proRataLeadIncentive = extraHours * perHourLeadIncentive;
            let teamLeadAmount = teamLeadBaseAmount + proRataLeadIncentive;
  
            // If totalHours < 160, pro-rate for totalHours
            if (totalHours < 160) {
              teamLeadAmount = (teamLeadBaseAmount * totalHours) / 160;
            }
            
            allIncentives.push({
              coordinatorName: candidate.lead,
              coordinatorType: 'teamLead',
              candidateId: candidate.candidateId,
              candidateName: candidate.candidateName,
              month: cycle.month,
              hoursWorked,
              margin,
              incentiveAmount: teamLeadAmount,
              isRecurring: true,
              isOneTime: false,
              notes: 'Team Lead recurring incentive'
            });
          }
          
          // One-time incentives (only if just reached 160 hours)
          if (!previouslyReached160) {
            const coordinators = [
              { name: candidate.crm, role: 'crm', amount: 1000 },
              { name: candidate.manager, role: 'manager', amount: 1500 },
              { name: candidate.seniorManager, role: 'seniorManager', amount: 1500 },
              { name: candidate.assoDirector, role: 'assoDirector', amount: 1750 },
              { name: candidate.centerHead, role: 'centerHead', amount: 1500 }
            ];
            
            for (const coordinator of coordinators) {
              if (coordinator.name) {
                allIncentives.push({
                  coordinatorName: coordinator.name,
                  coordinatorType: coordinator.role as any,
                  candidateId: candidate.candidateId,
                  candidateName: candidate.candidateName,
                  month: cycle.month,
                  hoursWorked,
                  margin,
                  incentiveAmount: coordinator.amount,
                  isRecurring: false,
                  isOneTime: true,
                  notes: `One-time incentive for reaching 160 hours`
                });
              }
            }
          }
        }
      }
      
      // Handle Full-Time candidates
      else if (candidate.contractType === 'FULLTIME') {
        const finderFees = candidate.finderFees || 0;
        
        // Recruiter incentive based on finder fees
        if (candidate.recruiter) {
          const recruiterAmount = finderFees <= 4500 ? 15000 : 20000;
          allIncentives.push({
            coordinatorName: candidate.recruiter,
            coordinatorType: 'recruiter',
            candidateId: candidate.candidateId,
            candidateName: candidate.candidateName,
            month: cycle.month,
            hoursWorked,
            margin: 0,
            incentiveAmount: recruiterAmount,
            isRecurring: false,
            isOneTime: true,
            isFullTime: true,
            finderFees,
            placementCount: 1,
            notes: `Full-time placement (Finder fees: $${finderFees})`
          });
        }
        
        // Other coordinator incentives for full-time
        const fullTimeIncentives = [
          { name: candidate.lead, role: 'teamLead', amount: 1000 },
          { name: candidate.manager, role: 'manager', amount: 1500 },
          { name: candidate.crm, role: 'crm', amount: 1500 },
          { name: candidate.assoDirector, role: 'assoDirector', amount: 4000 },
          { name: candidate.centerHead, role: 'centerHead', amount: 4000 }
        ];
        
        for (const coordinator of fullTimeIncentives) {
          if (coordinator.name) {
            allIncentives.push({
              coordinatorName: coordinator.name,
              coordinatorType: coordinator.role as any,
              candidateId: candidate.candidateId,
              candidateName: candidate.candidateName,
              month: cycle.month,
              hoursWorked,
              margin: 0,
              incentiveAmount: coordinator.amount,
              isRecurring: false,
              isOneTime: true,
              isFullTime: true,
              finderFees,
              placementCount: 1,
              notes: `Full-time placement`
            });
          }
        }
      }
    }
    
  } catch (error:any) {
    console.error('Error calculating incentives for cycle:', cycle.id, error);
    throw new Error(`Failed to calculate incentives: ${error.message || 'Unknown error'}`);
  }
  
  return allIncentives;
}

// Format currency for reports
export function formatCurrencyForReport(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

// Check if a candidate month has been processed
export function isCandidateMonthProcessed(
  candidateId: string,
  month: string,
  approvedCycles: IncentiveCycle[]
): boolean {
  return approvedCycles.some(cycle => 
    cycle.month === month &&
    cycle.monthlyHours?.some(ch => ch.candidateId === candidateId)
  );
}

// Calculate candidate fields for display
export function calculateCandidateFields(candidate: Partial<Candidate>): Partial<Candidate> {
  if (candidate.contractType === 'FULLTIME') {
    return candidate; // No margin calculations for full-time
  }
  
  const calculated = { ...candidate };
  
  // 1. W2 Payroll and Admin Taxes ($) = Pay Rate * W2 Payroll and Admin Taxes %
  if (calculated.payRate && calculated.w2PayrollAdminTaxesPercentage) {
    calculated.w2PayrollAdminTaxes = (calculated.payRate * calculated.w2PayrollAdminTaxesPercentage) / 100;
  } else {
    calculated.w2PayrollAdminTaxes = 0;
  }
  
  // 2. W2 / C2C Overhead Cost ($) = Pay Rate * W2 / C2C Overhead Cost %
  if (calculated.payRate && calculated.w2C2COverheadCostPercentage) {
    calculated.w2C2COverheadCost = (calculated.payRate * calculated.w2C2COverheadCostPercentage) / 100;
  } else {
    calculated.w2C2COverheadCost = 0;
  }
  
  // 3. Net Purchase = Pay rate + W2 Payroll and Admin Taxes + W2 / C2C Overhead Cost + Health benefits
  calculated.netPurchase = (calculated.payRate || 0) + 
                          (calculated.w2PayrollAdminTaxes || 0) + 
                          (calculated.w2C2COverheadCost || 0) + 
                          (calculated.healthBenefits || 0);
  
  // 4. MSP Fees $ = Bill Rate * MSP fees %
  if (calculated.billRate && calculated.mspFeesPercentage) {
    calculated.mspFeesDollar = (calculated.billRate * calculated.mspFeesPercentage) / 100;
  } else {
    calculated.mspFeesDollar = 0;
  }
  
  // 5. Net Bill Rate = Bill Rate - MSP Fees $ (CORRECTED FORMULA)
  calculated.netBillRate = (calculated.billRate || 0) - (calculated.mspFeesDollar || 0);
  
  // 6. Margin = Net Bill Rate - Net Purchase
  calculated.margin = (calculated.netBillRate || 0) - (calculated.netPurchase || 0);
  
  return calculated;
}

// Calculate margin revision fields
export function calculateMarginRevisionFields(revision: any, originalCandidate: Candidate): any {
  const calculated = { ...revision };
  
  // Use revision values or fall back to original candidate values
  const payRate = calculated.payRate || originalCandidate.payRate || 0;
  const w2PayrollAdminTaxesPercentage = calculated.w2PayrollAdminTaxesPercentage || originalCandidate.w2PayrollAdminTaxesPercentage || 0;
  const w2C2COverheadCostPercentage = calculated.w2C2COverheadCostPercentage || originalCandidate.w2C2COverheadCostPercentage || 0;
  const healthBenefits = calculated.healthBenefits || originalCandidate.healthBenefits || 0;
  const billRate = calculated.billRate || originalCandidate.billRate || 0;
  const mspFeesPercentage = calculated.mspFeesPercentage || originalCandidate.mspFeesPercentage || 0;
  
  // Apply the same calculation formulas
  calculated.w2PayrollAdminTaxes = (payRate * w2PayrollAdminTaxesPercentage) / 100;
  calculated.w2C2COverheadCost = (payRate * w2C2COverheadCostPercentage) / 100;
  calculated.netPurchase = payRate + calculated.w2PayrollAdminTaxes + calculated.w2C2COverheadCost + healthBenefits;
  calculated.mspFeesDollar = (billRate * mspFeesPercentage) / 100;
  calculated.netBillRate = billRate - calculated.mspFeesDollar; // CORRECTED FORMULA
  calculated.margin = calculated.netBillRate - calculated.netPurchase;
  
  return calculated;
}

// Generate retroactive incentives
export function generateRetroactiveIncentives(
  candidates: Candidate[],
  approvedCycles: IncentiveCycle[]
): IncentiveData[] {
  const retroactiveIncentives: IncentiveData[] = [];
  
  // This function can be implemented based on specific retroactive calculation requirements
  // For now, returning empty array
  
  return retroactiveIncentives;
}

// Missing exported functions - placeholder implementations
export function getAllHoursForCandidate(candidateId: string, approvedCycles: IncentiveCycle[]): number {
  return calculateTotalHours(candidateId, approvedCycles);
}

export function generateIncentiveReport(
  incentives: IncentiveData[],
  candidates: Candidate[],
  cycle: IncentiveCycle
): string {
  // Placeholder implementation
  return `Incentive Report for ${cycle.month} ${cycle.year}`;
}

export function generateCoordinatorReports(
  incentives: IncentiveData[],
  candidates: Candidate[]
): CoordinatorIncentive[] {
  // Placeholder implementation
  const coordinatorMap = new Map<string, number>();
  
  incentives.forEach(incentive => {
    const current = coordinatorMap.get(incentive.coordinatorName) || 0;
    coordinatorMap.set(incentive.coordinatorName, current + incentive.amount);
  });
  
  return Array.from(coordinatorMap.entries()).map(([name, amount]) => ({
    coordinatorName: name,
    totalAmount: amount,
    incentiveCount: incentives.filter(i => i.coordinatorName === name).length
  }));
}

export function calculateIncentiveAdjustments(
  currentIncentives: IncentiveData[],
  previousIncentives: IncentiveData[]
): IncentiveData[] {
  // Placeholder implementation
  return [];
}

export function getNextSequentialMonth(month: string, year: string): { month: string; year: string } {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  
  const currentMonthIndex = months.indexOf(month);
  const currentYear = parseInt(year);
  
  if (currentMonthIndex === 11) {
    return { month: months[0], year: (currentYear + 1).toString() };
  } else {
    return { month: months[currentMonthIndex + 1], year: year };
  }
}