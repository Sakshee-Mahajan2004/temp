
import axios from 'axios';

const axiosClient = axios.create({
  baseURL: 'http://incapi.amptech.corp/api', 
  // baseURL: 'http://localhost:8042/api',
});

// Add a request interceptor to include token from localStorage
axiosClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers = config.headers || {};
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add a response interceptor to handle session expiration
axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Dispatch a custom event for session expiration
      localStorage.removeItem('authToken');
      window.dispatchEvent(new Event('sessionExpired'));
    }
    return Promise.reject(error);
  }
);

export default axiosClient;