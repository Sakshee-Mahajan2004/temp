import axiosClient from './axiosClient';

export interface LoginPayload {
  username: string;
  password: string;
}

export async function login(payload: LoginPayload) {
  const response = await axiosClient.post('/auth/login', payload);
  const { token } = response.data;
  if (token) {
    localStorage.setItem('authToken', token);
  }
  return response.data;
} 