-- Create users table
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'USER',
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(255)
);

-- Create user_permissions table
CREATE TABLE user_permissions (
    user_id BIGINT NOT NULL,
    permission VARCHAR(100) NOT NULL,
    PRIMARY KEY (user_id, permission),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create coordinators table
CREATE TABLE coordinators (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create candidates table
CREATE TABLE candidates (
    id BIGSERIAL PRIMARY KEY,
    candidate_id VARCHAR(255) UNIQUE NOT NULL,
    candidate_name VARCHAR(255) NOT NULL,
    client_name VARCHAR(255) NOT NULL,
    contract_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    pay_rate DECIMAL(10,2),
    w2_payroll_admin_taxes_percentage DECIMAL(5,2),
    w2_payroll_admin_taxes DECIMAL(10,2),
    w2_c2c_overhead_cost_percentage DECIMAL(5,2),
    w2_c2c_overhead_cost DECIMAL(10,2),
    health_benefits DECIMAL(10,2),
    net_purchase DECIMAL(10,2),
    bill_rate DECIMAL(10,2),
    msp_fees_percentage DECIMAL(5,2),
    msp_fees_dollar DECIMAL(10,2),
    net_bill_rate DECIMAL(10,2),
    margin DECIMAL(10,2),
    finder_fees DECIMAL(10,2),
    recruiter VARCHAR(255),
    lead VARCHAR(255),
    manager VARCHAR(255),
    senior_manager VARCHAR(255),
    crm VARCHAR(255),
    asso_director VARCHAR(255),
    center_head VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create incentive_cycles table
CREATE TABLE incentive_cycles (
    id BIGSERIAL PRIMARY KEY,
    month VARCHAR(7) NOT NULL, -- YYYY-MM format
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    calculated_at TIMESTAMP,
    approved_at TIMESTAMP,
    cancelled_at TIMESTAMP,
    cancellation_reason TEXT,
    notes TEXT,
    created_by VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create monthly_hours table
CREATE TABLE monthly_hours (
    id BIGSERIAL PRIMARY KEY,
    candidate_id VARCHAR(255) NOT NULL,
    month VARCHAR(7) NOT NULL, -- YYYY-MM format
    hours_worked DECIMAL(8,2) NOT NULL,
    is_retroactive BOOLEAN NOT NULL DEFAULT false,
    cycle_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Create incentive_calculations table
CREATE TABLE incentive_calculations (
    id BIGSERIAL PRIMARY KEY,
    coordinator_name VARCHAR(255) NOT NULL,
    coordinator_type VARCHAR(50) NOT NULL,
    candidate_id VARCHAR(255) NOT NULL,
    candidate_name VARCHAR(255) NOT NULL,
    month VARCHAR(7) NOT NULL,
    hours_worked DECIMAL(8,2) NOT NULL,
    margin DECIMAL(10,2) NOT NULL,
    incentive_amount DECIMAL(10,2) NOT NULL,
    is_recurring BOOLEAN NOT NULL,
    is_one_time BOOLEAN NOT NULL,
    is_full_time BOOLEAN DEFAULT false,
    finder_fees DECIMAL(10,2),
    placement_count INTEGER,
    notes TEXT,
    cycle_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Create margin_revisions table
CREATE TABLE margin_revisions (
    id BIGSERIAL PRIMARY KEY,
    candidate_id BIGINT NOT NULL,
    effective_date DATE NOT NULL,
    contract_type VARCHAR(50),
    pay_rate DECIMAL(10,2),
    w2_payroll_admin_taxes_percentage DECIMAL(5,2),
    w2_c2c_overhead_cost_percentage DECIMAL(5,2),
    health_benefits DECIMAL(10,2),
    bill_rate DECIMAL(10,2),
    msp_fees_percentage DECIMAL(5,2),
    finder_fees DECIMAL(10,2),
    w2_payroll_admin_taxes DECIMAL(10,2),
    w2_c2c_overhead_cost DECIMAL(10,2),
    net_purchase DECIMAL(10,2),
    msp_fees_dollar DECIMAL(10,2),
    net_bill_rate DECIMAL(10,2),
    margin DECIMAL(10,2),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(255),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
);

-- Create incentive_adjustments table
CREATE TABLE incentive_adjustments (
    id BIGSERIAL PRIMARY KEY,
    coordinator_name VARCHAR(255) NOT NULL,
    coordinator_type VARCHAR(255) NOT NULL,
    candidate_id VARCHAR(255) NOT NULL,
    candidate_name VARCHAR(255) NOT NULL,
    affected_month VARCHAR(7) NOT NULL,
    original_incentive DECIMAL(10,2) NOT NULL,
    revised_incentive DECIMAL(10,2) NOT NULL,
    adjustment_amount DECIMAL(10,2) NOT NULL,
    adjustment_type VARCHAR(50) NOT NULL,
    margin_revision_id VARCHAR(255) NOT NULL,
    cycle_id BIGINT,
    processed_in_cycle VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Create coordinator_reports table
CREATE TABLE coordinator_reports (
    id BIGSERIAL PRIMARY KEY,
    coordinator_name VARCHAR(255) NOT NULL,
    coordinator_email VARCHAR(255) NOT NULL,
    coordinator_location VARCHAR(255) NOT NULL,
    total_incentive DECIMAL(10,2) NOT NULL,
    adjustment_amount DECIMAL(10,2),
    cycle_id BIGINT,
    sent_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX idx_candidates_candidate_id ON candidates(candidate_id);
CREATE INDEX idx_candidates_start_date ON candidates(start_date);
CREATE INDEX idx_candidates_end_date ON candidates(end_date);
CREATE INDEX idx_monthly_hours_candidate_id ON monthly_hours(candidate_id);
CREATE INDEX idx_monthly_hours_month ON monthly_hours(month);
CREATE INDEX idx_incentive_cycles_month ON incentive_cycles(month);
CREATE INDEX idx_incentive_cycles_status ON incentive_cycles(status);
CREATE INDEX idx_incentive_calculations_coordinator ON incentive_calculations(coordinator_name);
CREATE INDEX idx_margin_revisions_candidate_id ON margin_revisions(candidate_id);
CREATE INDEX idx_margin_revisions_effective_date ON margin_revisions(effective_date);