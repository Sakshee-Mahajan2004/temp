package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "candidates")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class Candidate extends BaseEntity {
    @Column(unique = true, nullable = false)
    private String candidateId;
    
    @Column(nullable = false)
    private String candidateName;
    
    @Column(nullable = true)
    private String otherName;


    @Column(nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'N/A'")
    private String candidateSource;
    
    @Column(nullable = false)
    private String clientName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ContractType contractType;
    
    @Column(nullable = false)
    private LocalDate startDate;
    
    private LocalDate endDate;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal payRate;
    
    @Column(precision = 5, scale = 2, name = "w2_payroll_admin_taxes_percentage")
    private BigDecimal w2PayrollAdminTaxesPercentage;
    
    @Column(precision = 10, scale = 2, name = "w2_payroll_admin_taxes")
    private BigDecimal w2PayrollAdminTaxes;
    
    @Column(precision = 5, scale = 2, name = "w2c2c_overhead_cost_percentage")
    private BigDecimal w2C2COverheadCostPercentage;
    
    @Column(precision = 10, scale = 2, name = "w2c2c_overhead_cost")
    private BigDecimal w2C2COverheadCost;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal healthBenefits;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal netPurchase;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal billRate;
    
    @Column(precision = 5, scale = 2)
    private BigDecimal mspFeesPercentage;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal mspFeesDollar;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal netBillRate;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal margin;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal finderFees;
    
    // Team member assignments - Many-to-One relationships with Coordinator
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recruiter_id")
    private Coordinator recruiter;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lead_id")
    private Coordinator lead;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manager_id")
    private Coordinator manager;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "senior_manager_id")
    private Coordinator seniorManager;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "crm_id")
    private Coordinator crm;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "asso_director_id")
    private Coordinator assoDirector;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "center_head_id")
    private Coordinator centerHead;
    
    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<MarginRevision> marginRevisions;
    
    public enum ContractType {
        C2C, W2, FULLTIME
    }
}