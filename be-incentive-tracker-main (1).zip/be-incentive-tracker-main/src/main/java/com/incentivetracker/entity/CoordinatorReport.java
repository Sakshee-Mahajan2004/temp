package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "coordinator_reports")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class CoordinatorReport extends BaseEntity {
    @Column(nullable = false)
    private String coordinatorName;
    
    @Column(nullable = false)
    private String coordinatorEmail;
    
    @Column(nullable = false)
    private String coordinatorLocation;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal totalIncentive;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal adjustmentAmount;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cycle_id")
    private IncentiveCycle cycle;
    
    private LocalDateTime sentAt;
    
    @CreationTimestamp
    private LocalDateTime createdAt;
}