package com.incentivetracker.enums;

public enum CycleStatus {
    DRAFT, CALCULATING, CALCULATED, APPROVED, CANCELLED
}
