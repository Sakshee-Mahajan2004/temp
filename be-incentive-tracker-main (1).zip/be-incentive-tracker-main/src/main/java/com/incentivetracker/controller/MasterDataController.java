package com.incentivetracker.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/master-data")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Master Data", description = "Master data APIs for dropdowns and reference data")
public class MasterDataController {

    @GetMapping("/contract-types")
    @Operation(summary = "Get contract types", description = "Get all available contract types")
    public ResponseEntity<List<String>> getContractTypes() {
        return ResponseEntity.ok(Arrays.asList("C2C", "W2", "FULLTIME"));
    }

    @GetMapping("/cycle-types")
    @Operation(summary = "Get cycle types", description = "Get all available cycle types")
    public ResponseEntity<List<String>> getCycleTypes() {
        return ResponseEntity.ok(Arrays.asList("REGULAR", "ADDITIONAL"));
    }

    @GetMapping("/cycle-statuses")
    @Operation(summary = "Get cycle statuses", description = "Get all available cycle statuses")
    public ResponseEntity<List<String>> getCycleStatuses() {
        return ResponseEntity.ok(Arrays.asList("DRAFT", "CALCULATING", "CALCULATED", "APPROVED", "CANCELLED"));
    }

    @GetMapping("/coordinator-types")
    @Operation(summary = "Get coordinator types", description = "Get all available coordinator types")
    public ResponseEntity<List<String>> getCoordinatorTypes() {
        return ResponseEntity.ok(Arrays.asList("RECRUITER", "CRM", "TEAM_LEAD", "MANAGER", 
                "SENIOR_MANAGER", "ASSO_DIRECTOR", "CENTER_HEAD"));
    }

    @GetMapping("/user-roles")
    @Operation(summary = "Get user roles", description = "Get all available user roles")
    public ResponseEntity<List<String>> getUserRoles() {
        return ResponseEntity.ok(Arrays.asList("ADMIN", "USER"));
    }

    @GetMapping("/user-permissions")
    @Operation(summary = "Get user permissions", description = "Get all available user permissions")
    public ResponseEntity<List<String>> getUserPermissions() {
        return ResponseEntity.ok(Arrays.asList(
                "ADD_CANDIDATES", "MARGIN_REVISION", "COORDINATORS", "START_INCENTIVE_CYCLE",
                "CALCULATE_INCENTIVE_CYCLE", "ADD_HOURS", "APPROVE_INCENTIVE_CYCLE",
                "CUSTOM_REPORTS", "LEGACY_REPORTS", "DOWNLOAD", "USER_MANAGEMENT", "DELETE_APPROVED_CYCLES"
        ));
    }

    @GetMapping("/incentive-tiers")
    @Operation(summary = "Get incentive tiers", description = "Get recruiter incentive tiers based on margin")
    public ResponseEntity<List<Map<String, Object>>> getIncentiveTiers() {
        List<Map<String, Object>> tiers = Arrays.asList(
                createTier(1.00, 2.00, 500),
                createTier(2.01, 4.00, 1000),
                createTier(4.01, 6.00, 1500),
                createTier(6.01, 8.00, 2000),
                createTier(8.01, 10.00, 2500),
                createTier(10.01, 15.00, 3500),
                createTier(15.01, 20.00, 4000),
                createTier(20.01, 30.00, 4500),
                createTier(30.01, 40.00, 7000),
                createTier(40.01, 50.00, 10000)
        );
        return ResponseEntity.ok(tiers);
    }

    @GetMapping("/one-time-incentives")
    @Operation(summary = "Get one-time incentives", description = "Get one-time incentive amounts for coordinators")
    public ResponseEntity<Map<String, Integer>> getOneTimeIncentives() {
        Map<String, Integer> incentives = new HashMap<>();
        incentives.put("CRM", 1000);
        incentives.put("MANAGER", 1500);
        incentives.put("SENIOR_MANAGER", 1500);
        incentives.put("ASSO_DIRECTOR", 1750);
        incentives.put("CENTER_HEAD", 1500);
        incentives.put("TEAM_LEAD", 250); // Recurring
        return ResponseEntity.ok(incentives);
    }

    @GetMapping("/fulltime-incentives")
    @Operation(summary = "Get full-time incentives", description = "Get full-time placement incentive structure")
    public ResponseEntity<Map<String, Object>> getFullTimeIncentives() {
        Map<String, Object> incentives = new HashMap<>();
        
        Map<String, Object> recruiterIncentives = new HashMap<>();
        recruiterIncentives.put("lowFinderFee", Map.of("threshold", 4500, "amounts", Map.of(1, 15000, 2, 18000, 3, 20000)));
        recruiterIncentives.put("highFinderFee", Map.of("threshold", 4500, "amounts", Map.of(1, 20000, 2, 25000, 3, 30000)));
        
        Map<String, Integer> otherIncentives = new HashMap<>();
        otherIncentives.put("TEAM_LEAD", 1000);
        otherIncentives.put("MANAGER", 1500);
        otherIncentives.put("CRM", 1500);
        otherIncentives.put("ASSO_DIRECTOR", 4000);
        otherIncentives.put("CENTER_HEAD", 4000);
        
        incentives.put("recruiter", recruiterIncentives);
        incentives.put("others", otherIncentives);
        
        return ResponseEntity.ok(incentives);
    }

    private Map<String, Object> createTier(double from, double to, int amount) {
        Map<String, Object> tier = new HashMap<>();
        tier.put("from", from);
        tier.put("to", to);
        tier.put("amount", amount);
        return tier;
    }
}