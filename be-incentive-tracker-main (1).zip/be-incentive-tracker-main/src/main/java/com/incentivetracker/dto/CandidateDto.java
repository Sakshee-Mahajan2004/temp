package com.incentivetracker.dto;

import com.incentivetracker.entity.Candidate;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class CandidateDto {
    private java.util.UUID id;
    
    @NotBlank(message = "Candidate ID is required")
    private String candidateId;
    
    @NotBlank(message = "Candidate name is required")
    private String candidateName;

    private String otherName;

    @NotBlank(message = "Candidate source is required")
    private String candidateSource;
    
    @NotBlank(message = "Client name is required")
    private String clientName;
    
    @NotNull(message = "Contract type is required")
    private Candidate.ContractType contractType;
    
    @NotNull(message = "Start date is required")
    private LocalDate startDate;
    
    private LocalDate endDate;
    private BigDecimal payRate;
    private BigDecimal w2PayrollAdminTaxesPercentage;
    private BigDecimal w2PayrollAdminTaxes;
    private BigDecimal w2C2COverheadCostPercentage;
    private BigDecimal w2C2COverheadCost;
    private BigDecimal healthBenefits;
    private BigDecimal netPurchase;
    private BigDecimal billRate;
    private BigDecimal mspFeesPercentage;
    private BigDecimal mspFeesDollar;
    private BigDecimal netBillRate;
    private BigDecimal margin;
    private BigDecimal finderFees;
    
    // Team member assignments - Many-to-One relationships with Coordinator
    private CoordinatorDto recruiter;
    private CoordinatorDto lead;
    private CoordinatorDto manager;
    private CoordinatorDto seniorManager;
    private CoordinatorDto crm;
    private CoordinatorDto assoDirector;
    private CoordinatorDto centerHead;
    
    private List<MarginRevisionDto> marginRevisions;
}