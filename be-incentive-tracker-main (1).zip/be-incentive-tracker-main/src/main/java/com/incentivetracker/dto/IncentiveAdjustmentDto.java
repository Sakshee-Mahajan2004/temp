package com.incentivetracker.dto;

import com.incentivetracker.entity.IncentiveAdjustment;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class IncentiveAdjustmentDto {
    private java.util.UUID id;
    private String coordinatorName;
    private String coordinatorType;
    private String candidateId;
    private String candidateName;
    private String affectedMonth;
    private BigDecimal originalIncentive;
    private BigDecimal revisedIncentive;
    private BigDecimal adjustmentAmount;
    private IncentiveAdjustment.AdjustmentType adjustmentType;
    private String marginRevisionId;
    private String processedInCycle;
}