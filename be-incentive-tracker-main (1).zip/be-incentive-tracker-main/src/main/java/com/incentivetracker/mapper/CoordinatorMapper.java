package com.incentivetracker.mapper;

import com.incentivetracker.dto.CoordinatorDto;
import com.incentivetracker.entity.Coordinator;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface CoordinatorMapper {
    
    CoordinatorDto toDto(Coordinator coordinator);
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    Coordinator toEntity(CoordinatorDto coordinatorDto);
    
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateEntityFromDto(CoordinatorDto coordinatorDto, @MappingTarget Coordinator coordinator);
}