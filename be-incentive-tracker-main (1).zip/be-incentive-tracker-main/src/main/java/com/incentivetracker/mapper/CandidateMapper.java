package com.incentivetracker.mapper;

import com.incentivetracker.dto.CandidateDto;
import com.incentivetracker.entity.Candidate;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring", 
    uses = {MarginRevisionMapper.class, CoordinatorMapper.class},
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface CandidateMapper {
    
    @Mapping(target = "marginRevisions", source = "marginRevisions")
    @Mapping(target = "otherName", source = "otherName")
    @Mapping(target = "candidateSource", source = "candidateSource")
    CandidateDto toDto(Candidate candidate);
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "marginRevisions", ignore = true)
    @Mapping(target = "recruiter", ignore = true)
    @Mapping(target = "lead", ignore = true)
    @Mapping(target = "manager", ignore = true)
    @Mapping(target = "seniorManager", ignore = true)
    @Mapping(target = "crm", ignore = true)
    @Mapping(target = "assoDirector", ignore = true)
    @Mapping(target = "centerHead", ignore = true)
    @Mapping(target = "otherName", source = "otherName")
    @Mapping(target = "candidateSource", source = "candidateSource")
    Candidate toEntity(CandidateDto candidateDto);
    
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "candidateId", ignore = true)
    @Mapping(target = "marginRevisions", ignore = true)
    @Mapping(target = "recruiter", ignore = true)
    @Mapping(target = "lead", ignore = true)
    @Mapping(target = "manager", ignore = true)
    @Mapping(target = "seniorManager", ignore = true)
    @Mapping(target = "crm", ignore = true)
    @Mapping(target = "assoDirector", ignore = true)
    @Mapping(target = "centerHead", ignore = true)
    @Mapping(target = "otherName", source = "otherName")
    @Mapping(target = "candidateSource", source = "candidateSource")
    void updateEntityFromDto(CandidateDto candidateDto, @MappingTarget Candidate candidate);
    
    @AfterMapping
    default void calculateFields(@MappingTarget Candidate candidate) {
        if (candidate.getContractType() != Candidate.ContractType.FULLTIME) {
            // Calculate derived fields
            if (candidate.getPayRate() != null && candidate.getW2PayrollAdminTaxesPercentage() != null) {
                candidate.setW2PayrollAdminTaxes(
                    candidate.getPayRate()
                        .multiply(candidate.getW2PayrollAdminTaxesPercentage())
                        .divide(java.math.BigDecimal.valueOf(100))
                );
            }
            
            if (candidate.getPayRate() != null && candidate.getW2C2COverheadCostPercentage() != null) {
                candidate.setW2C2COverheadCost(
                    candidate.getPayRate()
                        .multiply(candidate.getW2C2COverheadCostPercentage())
                        .divide(java.math.BigDecimal.valueOf(100))
                );
            }
            
            // Calculate net purchase
            java.math.BigDecimal netPurchase = candidate.getPayRate() != null ? candidate.getPayRate() : java.math.BigDecimal.ZERO;
            if (candidate.getW2PayrollAdminTaxes() != null) {
                netPurchase = netPurchase.add(candidate.getW2PayrollAdminTaxes());
            }
            if (candidate.getW2C2COverheadCost() != null) {
                netPurchase = netPurchase.add(candidate.getW2C2COverheadCost());
            }
            if (candidate.getHealthBenefits() != null) {
                netPurchase = netPurchase.add(candidate.getHealthBenefits());
            }
            candidate.setNetPurchase(netPurchase);
            
            // Calculate MSP fees
            if (candidate.getBillRate() != null && candidate.getMspFeesPercentage() != null) {
                candidate.setMspFeesDollar(
                    candidate.getBillRate()
                        .multiply(candidate.getMspFeesPercentage())
                        .divide(java.math.BigDecimal.valueOf(100))
                );
            }
            
            // Calculate net bill rate
            if (candidate.getBillRate() != null && candidate.getMspFeesDollar() != null) {
                candidate.setNetBillRate(candidate.getBillRate().subtract(candidate.getMspFeesDollar()));
            }
            
            // Calculate margin
            if (candidate.getNetBillRate() != null && candidate.getNetPurchase() != null) {
                candidate.setMargin(candidate.getNetBillRate().subtract(candidate.getNetPurchase()));
            }
        }
    }
}