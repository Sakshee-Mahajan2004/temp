package com.incentivetracker.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.Optional;
import java.util.UUID;

@Configuration
public class AuditorConfig {
    @Bean
    public AuditorAware<UUID> auditorProvider() {
        return () -> {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return Optional.empty();
            }
            Object principal = authentication.getPrincipal();
            // Replace UserPrincipal with your actual principal class if different
            if (principal instanceof com.incentivetracker.security.UserDetailsServiceImpl.UserPrincipal userPrincipal) {
                return Optional.ofNullable(userPrincipal.getId());
            }
            return Optional.empty();
        };
    }
} 