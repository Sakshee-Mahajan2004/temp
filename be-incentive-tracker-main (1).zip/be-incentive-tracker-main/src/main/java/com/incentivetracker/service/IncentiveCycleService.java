package com.incentivetracker.service;

import com.incentivetracker.dto.IncentiveCalculationDto;
import com.incentivetracker.dto.IncentiveCycleDto;
import com.incentivetracker.dto.MonthlyHoursDto;
import com.incentivetracker.entity.IncentiveCalculation;
import com.incentivetracker.entity.IncentiveCycle;
import com.incentivetracker.entity.MonthlyHours;
import com.incentivetracker.enums.CycleStatus;
import com.incentivetracker.exception.ResourceNotFoundException;
import com.incentivetracker.mapper.IncentiveCycleMapper;
import com.incentivetracker.mapper.MonthlyHoursMapper;
import com.incentivetracker.repository.IncentiveCalculationRepository;
import com.incentivetracker.repository.IncentiveCycleRepository;
import com.incentivetracker.repository.MonthlyHoursRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class IncentiveCycleService {

    private final IncentiveCycleRepository cycleRepository;
    private final IncentiveCycleMapper cycleMapper;
    private final MonthlyHoursMapper hoursMapper;
    private final IncentiveCalculationService calculationService;
    private final MonthlyHoursRepository monthlyHoursRepository;
    private final IncentiveCalculationRepository incentiveCalculationRepository;


    public Page<IncentiveCycleDto> getAllCycles(Pageable pageable) {
        return cycleRepository.findAll(pageable)
                .map(cycleMapper::toDto);
    }

    public IncentiveCycleDto getCycleById(UUID id) {
        IncentiveCycle cycle = cycleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + id));
        return cycleMapper.toDto(cycle);
    }

    public List<IncentiveCycleDto> getActiveCycles() {
        return cycleRepository.findActiveCycles().stream()
                .map(cycleMapper::toDto)
                .toList();
    }

    public List<IncentiveCycleDto> getApprovedCycles() {
        return cycleRepository.findApprovedCyclesOrderByMonthDesc().stream()
                .map(cycleMapper::toDto)
                .toList();
    }

    public IncentiveCycleDto startCycle(IncentiveCycleDto cycleDto) {
        // Check if there's already an active cycle
        List<IncentiveCycle> activeCycles = cycleRepository.findActiveCycles();
        if (!activeCycles.isEmpty()) {
            throw new IllegalStateException("Cannot start new cycle. There is already an active cycle.");
        }
        
        IncentiveCycle cycle = cycleMapper.toEntity(cycleDto);
        cycle.setStatus(CycleStatus.DRAFT);
        cycle = cycleRepository.save(cycle);
        return cycleMapper.toDto(cycle);
    }

    @Transactional
    public IncentiveCycleDto addHours(UUID cycleId, List<MonthlyHoursDto> hoursDto) {
        IncentiveCycle cycle = cycleRepository.findById(cycleId)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + cycleId));
        
        if (cycle.getStatus() == CycleStatus.APPROVED) {
            throw new IllegalStateException("Cannot modify hours for approved cycle");
        }
        
        // Clear existing hours and add new ones
        cycle.getMonthlyHours().clear();
//        long number = monthlyHoursRepository.deleteByCycle(cycle);


        
        // Convert DTOs to entities and set the cycle
        List<MonthlyHours> hours = new java.util.ArrayList<>();
        for (MonthlyHoursDto dto : hoursDto) {
            MonthlyHours hour = hoursMapper.toEntity(dto);
            hour.setCycle(cycle);
            hours.add(hour);
        }
        cycle.getMonthlyHours().addAll(hours);
        cycle.getIncentiveCalculations().clear();
        
        // Reset status to draft if it was calculated
        if (cycle.getStatus() == CycleStatus.CALCULATED) {
            long calculation =incentiveCalculationRepository.deleteByCycle(cycle);
            cycle.setStatus(CycleStatus.DRAFT);
            cycle.setCalculatedAt(null);
        }
        
        cycle = cycleRepository.save(cycle);
        return cycleMapper.toDto(cycle);
    }


    public IncentiveCycleDto addCalculatedIncentive(UUID cycleId, List<IncentiveCalculationDto> hoursDto) {
        IncentiveCycle cycle = cycleRepository.findById(cycleId)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + cycleId));
        
        if (cycle.getStatus() == CycleStatus.APPROVED) {
            throw new IllegalStateException("Cannot modify hours for approved cycle");
        }
        
        
        cycle.getIncentiveCalculations().clear();
        
        // Convert DTOs to entities and set the cycle
        List<IncentiveCalculation> hours = new java.util.ArrayList<>();
        for (IncentiveCalculationDto dto : hoursDto) {
            IncentiveCalculation incentiveCalculation = hoursMapper.toCalculatedIncentive(dto);
            incentiveCalculation.setCycle(cycle);
            hours.add(incentiveCalculation);
        }
        cycle.getIncentiveCalculations().addAll(hours);
        cycle.setStatus(CycleStatus.CALCULATED);
        cycle.setCalculatedAt(LocalDateTime.now());
        
        cycle = cycleRepository.save(cycle);
        return cycleMapper.toDto(cycle);
    }

    public IncentiveCycleDto calculateIncentives(UUID cycleId) {
        IncentiveCycle cycle = cycleRepository.findById(cycleId)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + cycleId));
        
        if (cycle.getStatus() == CycleStatus.APPROVED) {
            throw new IllegalStateException("Cannot recalculate approved cycle");
        }
        
        // Perform incentive calculations
        calculationService.calculateIncentivesForCycle(cycle);
        
        cycle.setStatus(CycleStatus.CALCULATED);
        cycle.setCalculatedAt(LocalDateTime.now());
        cycle = cycleRepository.save(cycle);
        
        return cycleMapper.toDto(cycle);
    }

    public IncentiveCycleDto approveCycle(UUID cycleId) {
        IncentiveCycle cycle = cycleRepository.findById(cycleId)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + cycleId));
        
        if (cycle.getStatus() != CycleStatus.CALCULATED) {
            throw new IllegalStateException("Can only approve calculated cycles");
        }
        
        cycle.setStatus(CycleStatus.APPROVED);
        cycle.setApprovedAt(LocalDateTime.now());
        cycle = cycleRepository.save(cycle);
        
        return cycleMapper.toDto(cycle);
    }

    public IncentiveCycleDto cancelCycle(UUID cycleId, String reason) {
        IncentiveCycle cycle = cycleRepository.findById(cycleId)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + cycleId));
        
        if (cycle.getStatus() == CycleStatus.APPROVED) {
            throw new IllegalStateException("Cannot cancel approved cycle");
        }
        
        cycle.setStatus(CycleStatus.CANCELLED);
        cycle.setCancelledAt(LocalDateTime.now());
        cycle.setCancellationReason(reason);
        cycle = cycleRepository.save(cycle);
        
        return cycleMapper.toDto(cycle);
    }

    public void deleteCycle(UUID cycleId) {
        IncentiveCycle cycle = cycleRepository.findById(cycleId)
                .orElseThrow(() -> new ResourceNotFoundException("Incentive cycle not found with id: " + cycleId));
        
        cycleRepository.delete(cycle);
    }

    public void deleteAllApprovedCycles() {
        cycleRepository.deleteByStatus(CycleStatus.APPROVED);
    }
}