package com.incentivetracker.service;

import com.incentivetracker.dto.CoordinatorDto;
import com.incentivetracker.entity.Coordinator;
import com.incentivetracker.exception.ResourceNotFoundException;
import com.incentivetracker.mapper.CoordinatorMapper;
import com.incentivetracker.repository.CoordinatorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class CoordinatorService {

    private final CoordinatorRepository coordinatorRepository;
    private final CoordinatorMapper coordinatorMapper;

    public Page<CoordinatorDto> getAllCoordinators(Pageable pageable) {
        return coordinatorRepository.findAll(pageable)
                .map(coordinatorMapper::toDto);
    }

    public List<CoordinatorDto> getAllCoordinatorsList() {
        return coordinatorRepository.findAll().stream()
                .map(coordinatorMapper::toDto)
                .toList();
    }

    public CoordinatorDto getCoordinatorById(UUID id) {
        Coordinator coordinator = coordinatorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coordinator not found with id: " + id));
        return coordinatorMapper.toDto(coordinator);
    }

    public CoordinatorDto createCoordinator(CoordinatorDto coordinatorDto) {
        if (coordinatorRepository.existsByEmail(coordinatorDto.getEmail())) {
            throw new IllegalArgumentException("Coordinator with email " + coordinatorDto.getEmail() + " already exists");
        }
        
        Coordinator coordinator = coordinatorMapper.toEntity(coordinatorDto);
        coordinator = coordinatorRepository.save(coordinator);
        return coordinatorMapper.toDto(coordinator);
    }

    public CoordinatorDto updateCoordinator(UUID id, CoordinatorDto coordinatorDto) {
        Coordinator existingCoordinator = coordinatorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coordinator not found with id: " + id));
        
        coordinatorMapper.updateEntityFromDto(coordinatorDto, existingCoordinator);
        existingCoordinator = coordinatorRepository.save(existingCoordinator);
        return coordinatorMapper.toDto(existingCoordinator);
    }

    public void deleteCoordinator(UUID id) {
        if (!coordinatorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Coordinator not found with id: " + id);
        }
        coordinatorRepository.deleteById(id);
    }
}