package com.incentivetracker.repository;

import com.incentivetracker.entity.IncentiveCycle;
import com.incentivetracker.enums.CycleStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IncentiveCycleRepository extends JpaRepository<IncentiveCycle, java.util.UUID> {
    Optional<IncentiveCycle> findByMonth(String month);
    
    @Query("SELECT ic FROM IncentiveCycle ic WHERE ic.status = :status")
    List<IncentiveCycle> findByStatus(@Param("status") CycleStatus status);
    
    @Query("SELECT ic FROM IncentiveCycle ic WHERE ic.status = 'APPROVED' ORDER BY ic.month DESC")
    List<IncentiveCycle> findApprovedCyclesOrderByMonthDesc();
    
    @Query("SELECT ic FROM IncentiveCycle ic WHERE ic.status IN ('DRAFT', 'CALCULATING', 'CALCULATED')")
    List<IncentiveCycle> findActiveCycles();

    @Modifying
    @Query("DELETE FROM IncentiveCycle ic WHERE ic.status = :status")
    void deleteByStatus(@Param("status") CycleStatus status);

}