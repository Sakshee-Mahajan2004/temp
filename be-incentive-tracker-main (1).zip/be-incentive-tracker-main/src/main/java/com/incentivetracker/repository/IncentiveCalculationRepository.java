package com.incentivetracker.repository;

import com.incentivetracker.entity.IncentiveCalculation;
import com.incentivetracker.entity.IncentiveCycle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncentiveCalculationRepository extends JpaRepository<IncentiveCalculation, Long> {
    // Define custom query methods if needed
    // For example, to find calculations by cycle ID or status
    // List<IncentiveCalculation> findByCycleId(UUID cycleId);
    // List<IncentiveCalculation> findByStatus(CycleStatus status);


    long deleteByCycle(IncentiveCycle cycle);
}
