package com.incentivetracker.repository;

import com.incentivetracker.entity.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CandidateRepository extends JpaRepository<Candidate, java.util.UUID> {
    Optional<Candidate> findByCandidateId(String candidateId);
    Boolean existsByCandidateId(String candidateId);
    
    @Query("SELECT c FROM Candidate c WHERE c.startDate <= :date AND (c.endDate IS NULL OR c.endDate >= :date)")
    List<Candidate> findActiveCandidatesForDate(@Param("date") LocalDate date);
    
    @Query("SELECT c FROM Candidate c WHERE c.clientName = :clientName")
    List<Candidate> findByClientName(@Param("clientName") String clientName);
    
    @Query("SELECT c FROM Candidate c WHERE c.contractType = :contractType")
    List<Candidate> findByContractType(@Param("contractType") Candidate.ContractType contractType);
}