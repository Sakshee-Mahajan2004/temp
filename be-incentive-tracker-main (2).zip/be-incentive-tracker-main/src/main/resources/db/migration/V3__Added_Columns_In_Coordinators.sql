-- Add new columns to coordinators table with default values for existing data
ALTER TABLE coordinators ADD COLUMN employee_id VARCHAR(255) NOT NULL DEFAULT 'UNKNOWN';
ALTER TABLE coordinators ADD COLUMN ifsc_code VARCHAR(20) NOT NULL DEFAULT 'NA';
ALTER TABLE coordinators ADD COLUMN bank_name VARCHAR(255) NOT NULL DEFAULT 'NA';
ALTER TABLE coordinators ADD COLUMN bank_account_number VARCHAR(50) NOT NULL DEFAULT 'NA';
ALTER TABLE coordinators ADD COLUMN status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE coordinators ADD COLUMN effective_date DATE NOT NULL DEFAULT CURRENT_DATE;

