package com.incentivetracker.controller;

import com.incentivetracker.dto.CoordinatorDto;
import com.incentivetracker.service.CoordinatorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.postgresql.util.PSQLException;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/coordinators")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Coordinators", description = "Coordinator management APIs")
public class CoordinatorController {

    private final CoordinatorService coordinatorService;

    @GetMapping
    @Operation(summary = "Get all coordinators", description = "Retrieve all coordinators with pagination")
    public ResponseEntity<Page<CoordinatorDto>> getAllCoordinators(Pageable pageable) {
        return ResponseEntity.ok(coordinatorService.getAllCoordinators(pageable));
    }

    @GetMapping("/list")
    @Operation(summary = "Get all coordinators as list", description = "Retrieve all coordinators as a simple list")
    public ResponseEntity<List<CoordinatorDto>> getAllCoordinatorsList() {
        return ResponseEntity.ok(coordinatorService.getAllCoordinatorsList());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get coordinator by ID", description = "Retrieve a specific coordinator by ID")
    public ResponseEntity<CoordinatorDto> getCoordinatorById(@PathVariable UUID id) {
        return ResponseEntity.ok(coordinatorService.getCoordinatorById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_COORDINATORS') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Create coordinator", description = "Create a new coordinator")
    public ResponseEntity<CoordinatorDto> createCoordinator(@Valid @RequestBody CoordinatorDto coordinatorDto) {
        return new ResponseEntity<>(coordinatorService.createCoordinator(coordinatorDto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_COORDINATORS') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Update coordinator", description = "Update an existing coordinator")
    public ResponseEntity<CoordinatorDto> updateCoordinator(@PathVariable UUID id, 
                                                           @Valid @RequestBody CoordinatorDto coordinatorDto) {
        return ResponseEntity.ok(coordinatorService.updateCoordinator(id, coordinatorDto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_COORDINATORS') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Delete coordinator", description = "Delete a coordinator")
    public ResponseEntity<?> deleteCoordinator(@PathVariable UUID id) {
        final String errorMsg = "Cannot delete coordinator: This coordinator is assigned to one or more candidates. Please reassign or remove those candidates before deleting the coordinator.";
        try {
            coordinatorService.deleteCoordinator(id);
            return ResponseEntity.ok("Coordinator deleted successfully.");
        } catch (Exception ex) {
            Throwable cause = ex;
            while (cause != null) {
                // Check for known exception types
                if (cause instanceof DataIntegrityViolationException ||
                    cause instanceof ConstraintViolationException ||
                    cause instanceof JpaSystemException ||
                    (cause instanceof org.postgresql.util.PSQLException &&
                     cause.getMessage() != null &&
                     cause.getMessage().contains("violates foreign key constraint"))) {
                    return ResponseEntity.badRequest().body(errorMsg);
                }
                // Check for the constraint violation message in any exception
                if (cause.getMessage() != null &&
                    cause.getMessage().toLowerCase().contains("violates foreign key constraint")) {
                    return ResponseEntity.badRequest().body(errorMsg);
                }
                cause = cause.getCause();
            }
            return ResponseEntity.status(500).body("An error occurred: " + ex.getMessage());
        }
    }
}