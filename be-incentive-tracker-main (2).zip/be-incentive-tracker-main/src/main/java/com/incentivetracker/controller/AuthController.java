package com.incentivetracker.controller;

import com.incentivetracker.dto.AuthRequest;
import com.incentivetracker.dto.AuthResponse;
import com.incentivetracker.security.JwtTokenProvider;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Authentication management APIs")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;

    @PostMapping("/login")
    @Operation(summary = "User login", description = "Authenticate user and return JWT token")
    public ResponseEntity<AuthResponse> authenticateUser(@Valid @RequestBody AuthRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = tokenProvider.generateToken(authentication);
        
        Object principal = authentication.getPrincipal();
        if (principal instanceof com.incentivetracker.security.UserDetailsServiceImpl.UserPrincipal userPrincipal) {
            // Extract permissions (skip roles)
            java.util.List<String> permissions = userPrincipal.getAuthorities().stream()
                .map(auth -> auth.getAuthority())
                .filter(auth -> !auth.equals("ROLE_ADMIN") && !auth.equals("ROLE_USER"))
                .map(auth -> auth.replace("ROLE_", ""))
                .toList();
            return ResponseEntity.ok(new AuthResponse(
                jwt,
                userPrincipal.getUsername(),    
                userPrincipal.getEmail(),
                "ADMIN",
                userPrincipal.getId() != null ? userPrincipal.getId().toString() : null,
                userPrincipal.getFirstName(),
                userPrincipal.getMiddleName(),
                userPrincipal.getLastName(),
                userPrincipal.getPhoneNumber(),
                permissions
            ));
        } else {
            UserDetails userDetails = (UserDetails) principal;
            java.util.List<String> permissions = userDetails.getAuthorities().stream()
                .map(auth -> auth.getAuthority())
                .filter(auth -> !auth.equals("ROLE_ADMIN") && !auth.equals("ROLE_USER"))
                .map(auth -> auth.replace("ROLE_", ""))
                .toList();
            return ResponseEntity.ok(new AuthResponse(jwt, userDetails.getUsername(), userDetails.getUsername(), "ADMIN", permissions));
        }
    }
}