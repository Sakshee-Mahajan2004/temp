package com.incentivetracker.mapper;

import com.incentivetracker.dto.IncentiveCycleDto;
import com.incentivetracker.entity.IncentiveCycle;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring", 
    uses = {MonthlyHoursMapper.class, IncentiveCalculationMapper.class, IncentiveAdjustmentMapper.class, CoordinatorReportMapper.class},
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface IncentiveCycleMapper {
    
    @Mapping(target = "monthlyHours", source = "monthlyHours")
    @Mapping(target = "incentiveCalculations", source = "incentiveCalculations")
    @Mapping(target = "incentiveAdjustments", source = "incentiveAdjustments")
    @Mapping(target = "coordinatorReports", source = "coordinatorReports")
    IncentiveCycleDto toDto(IncentiveCycle cycle);
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "startedAt", ignore = true)
    @Mapping(target = "monthlyHours", ignore = true)
    @Mapping(target = "incentiveCalculations", ignore = true)
    @Mapping(target = "incentiveAdjustments", ignore = true)
    @Mapping(target = "coordinatorReports", ignore = true)
    IncentiveCycle toEntity(IncentiveCycleDto cycleDto);
    
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "startedAt", ignore = true)
    @Mapping(target = "monthlyHours", ignore = true)
    @Mapping(target = "incentiveCalculations", ignore = true)
    @Mapping(target = "incentiveAdjustments", ignore = true)
    @Mapping(target = "coordinatorReports", ignore = true)
    void updateEntityFromDto(IncentiveCycleDto cycleDto, @MappingTarget IncentiveCycle cycle);
}