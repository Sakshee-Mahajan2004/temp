package com.incentivetracker.mapper;

import com.incentivetracker.dto.CoordinatorReportDto;
import com.incentivetracker.entity.CoordinatorReport;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface CoordinatorReportMapper {
    
    CoordinatorReportDto toDto(CoordinatorReport report);
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    CoordinatorReport toEntity(CoordinatorReportDto reportDto);
}