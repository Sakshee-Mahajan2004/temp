package com.incentivetracker.mapper;

import com.incentivetracker.dto.IncentiveCalculationDto;
import com.incentivetracker.dto.MonthlyHoursDto;
import com.incentivetracker.entity.IncentiveCalculation;
import com.incentivetracker.entity.MonthlyHours;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface MonthlyHoursMapper {
    
    MonthlyHoursDto toDto(MonthlyHours monthlyHours);
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    MonthlyHours toEntity(MonthlyHoursDto monthlyHoursDto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    IncentiveCalculation toCalculatedIncentive(IncentiveCalculationDto monthlyHoursDto);
}