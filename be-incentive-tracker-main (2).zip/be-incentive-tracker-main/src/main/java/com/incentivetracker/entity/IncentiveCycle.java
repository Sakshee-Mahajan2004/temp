package com.incentivetracker.entity;

import com.incentivetracker.enums.CycleStatus;
import com.incentivetracker.enums.CycleType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "incentive_cycles")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class IncentiveCycle extends BaseEntity {
    @Column(nullable = false)
    private String month; // YYYY-MM format
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CycleType type;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CycleStatus status;
    
    @CreationTimestamp
    private LocalDateTime startedAt;
    
    private LocalDateTime calculatedAt;
    private LocalDateTime approvedAt;
    private LocalDateTime cancelledAt;
    private String cancellationReason;
    
    @OneToMany(mappedBy = "cycle", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<MonthlyHours> monthlyHours;
    
    @OneToMany(mappedBy = "cycle", cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
    private List<IncentiveCalculation> incentiveCalculations;
    
    @OneToMany(mappedBy = "cycle", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<IncentiveAdjustment> incentiveAdjustments;
    
    @OneToMany(mappedBy = "cycle", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<CoordinatorReport> coordinatorReports;
    
    private String notes;

}