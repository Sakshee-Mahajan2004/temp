package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "coordinators")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class Coordinator extends BaseEntity {
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    @Column(nullable = false)
    private String location;
    
    @Column(nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'N/A'")
    private String employeeId;
    
    @Column(nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'N/A'")
    private String ifscCode;
    
    @Column(nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'N/A'")
    private String bankName;
    
    @Column( nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'N/A'")
    private String bankAccountNumber;
    
    @Column( nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'ACTIVE'")
    private String status;
    
    @Column(nullable = true, columnDefinition = "DATE DEFAULT CURRENT_DATE")
    private LocalDate effectiveDate;
    
    @CreationTimestamp
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    private LocalDateTime updatedAt;
}