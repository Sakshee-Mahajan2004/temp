package com.incentivetracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class AuthResponse {
    private String token;
    private String type = "Bearer";
    private String username;
    private String email;
    private String role;
    private String userId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String phoneNumber;
    private List<String> permissions;
    
    public AuthResponse(String token, String username, String email, String role, List<String> permissions) {
        this.token = token;
        this.username = username;
        this.email = email;
        this.role = role;
        this.permissions = permissions;
    }

    public AuthResponse(String token, String username, String email, String role, String userId, String firstName, String middleName, String lastName, String phoneNumber, List<String> permissions) {
        this.token = token;
        this.username = username;
        this.email = email;
        this.role = role;
        this.userId = userId;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.permissions = permissions;
    }
}