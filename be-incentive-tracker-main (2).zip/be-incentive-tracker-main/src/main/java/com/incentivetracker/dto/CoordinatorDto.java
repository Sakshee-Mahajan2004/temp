package com.incentivetracker.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CoordinatorDto {
    private java.util.UUID id;
    
    @NotBlank(message = "Name is required")
    private String name;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;
    
    @NotBlank(message = "Location is required")
    private String location;

    private String firstName;
    private String middleName;
    private String lastName;
    private String phoneNumber;
    
    @NotBlank(message = "Employee ID is required")
    private String employeeId;
    
    @NotBlank(message = "IFSC Code is required")
    private String ifscCode;
    
    @NotBlank(message = "Bank Name is required")
    private String bankName;
    
    @NotBlank(message = "Bank Account Number is required")
    private String bankAccountNumber;
    
    @NotBlank(message = "Status is required")
    private String status;
    
 
    private LocalDate effectiveDate;
}
