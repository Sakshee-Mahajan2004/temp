package com.incentivetracker.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CoordinatorReportDto {
    private java.util.UUID id;
    private String coordinatorName;
    private String coordinatorEmail;
    private String coordinatorLocation;
    private BigDecimal totalIncentive;
    private BigDecimal adjustmentAmount;
    private LocalDateTime sentAt;
}