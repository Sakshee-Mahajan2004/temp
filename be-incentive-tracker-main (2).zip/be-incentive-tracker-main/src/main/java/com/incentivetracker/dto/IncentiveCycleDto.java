package com.incentivetracker.dto;

import com.incentivetracker.entity.IncentiveCycle;
import com.incentivetracker.enums.CycleStatus;
import com.incentivetracker.enums.CycleType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class IncentiveCycleDto {
    private java.util.UUID id;
    
    @NotBlank(message = "Month is required")
    private String month;
    
    @NotNull(message = "Cycle type is required")
    private CycleType type;
    
    private CycleStatus status;
    private LocalDateTime startedAt;
    private LocalDateTime calculatedAt;
    private LocalDateTime approvedAt;
    private LocalDateTime cancelledAt;
    private String cancellationReason;
    
    private List<MonthlyHoursDto> monthlyHours;
    private List<IncentiveCalculationDto> incentiveCalculations;
    private List<IncentiveAdjustmentDto> incentiveAdjustments;
    private List<CoordinatorReportDto> coordinatorReports;
    
    private String notes;
    private String createdBy;
}