package com.incentivetracker.service;

import com.incentivetracker.dto.CoordinatorDto;
import com.incentivetracker.entity.Coordinator;
import com.incentivetracker.exception.ResourceNotFoundException;
import com.incentivetracker.mapper.CoordinatorMapper;
import com.incentivetracker.repository.CoordinatorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class CoordinatorService {

    private final CoordinatorRepository coordinatorRepository;
    private final CoordinatorMapper coordinatorMapper;

    public Page<CoordinatorDto> getAllCoordinators(Pageable pageable) {
        return coordinatorRepository.findAll(pageable)
                .map(coordinatorMapper::toDto);
    }

    public List<CoordinatorDto> getAllCoordinatorsList() {
        return coordinatorRepository.findAll().stream()
                .map(coordinatorMapper::toDto)
                .toList();
    }

    public CoordinatorDto getCoordinatorById(UUID id) {
        Coordinator coordinator = coordinatorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coordinator not found with id: " + id));
        return coordinatorMapper.toDto(coordinator);
    }

  public CoordinatorDto createCoordinator(CoordinatorDto coordinatorDto) {
    if (coordinatorRepository.existsByEmail(coordinatorDto.getEmail())) {
        throw new IllegalArgumentException("Coordinator with email " + coordinatorDto.getEmail() + " already exists");
    }

    // Tokenize sensitive fields
    coordinatorDto.setEmployeeId(generateToken("EMP"));
    coordinatorDto.setIfscCode(generateToken("IFSC"));
    coordinatorDto.setBankAccountNumber(generateToken("ACC"));
    coordinatorDto.setBankName(generateToken("BANK"));

    // Convert to entity
    Coordinator coordinator = coordinatorMapper.toEntity(coordinatorDto);

    // Set effective date based on status
    setEffectiveDateBasedOnStatus(coordinator, coordinatorDto.getEffectiveDate());

    // Save to database
    coordinator = coordinatorRepository.save(coordinator);

    return coordinatorMapper.toDto(coordinator);
}


// Helper method to generate a unique token
private String generateToken(String prefix) {
    return prefix + "_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
}

// Helper method to set effective date based on status
private void setEffectiveDateBasedOnStatus(Coordinator coordinator, LocalDate userProvidedEffectiveDate) {
    String status = coordinator.getStatus();
    
    if ("ACTIVE".equalsIgnoreCase(status)) {
        // For ACTIVE status, always set effective date to current date
        coordinator.setEffectiveDate(LocalDate.now());
    } else if ("LEFT".equalsIgnoreCase(status) || "NOTICE_PERIOD".equalsIgnoreCase(status)) {
        // For LEFT or NOTICE_PERIOD status, use user-provided effective date
        if (userProvidedEffectiveDate != null) {
            coordinator.setEffectiveDate(userProvidedEffectiveDate);
        } else {
            throw new IllegalArgumentException("Effective date is required for status: " + status);
        }
    } else {
        // For any other status, use user-provided date or current date as fallback
        coordinator.setEffectiveDate(userProvidedEffectiveDate != null ? userProvidedEffectiveDate : LocalDate.now());
    }
}


    public CoordinatorDto updateCoordinator(UUID id, CoordinatorDto coordinatorDto) {
        Coordinator existingCoordinator = coordinatorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coordinator not found with id: " + id));
        
        coordinatorMapper.updateEntityFromDto(coordinatorDto, existingCoordinator);
        
        // Set effective date based on status
        setEffectiveDateBasedOnStatus(existingCoordinator, coordinatorDto.getEffectiveDate());
        
        existingCoordinator = coordinatorRepository.save(existingCoordinator);
        return coordinatorMapper.toDto(existingCoordinator);
    }

    public void deleteCoordinator(UUID id) {
        if (!coordinatorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Coordinator not found with id: " + id);
        }
        coordinatorRepository.deleteById(id);
    }
}