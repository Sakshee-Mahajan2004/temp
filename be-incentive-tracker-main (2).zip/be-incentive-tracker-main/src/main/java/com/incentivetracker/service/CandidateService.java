package com.incentivetracker.service;

import com.incentivetracker.dto.CandidateDto;
import com.incentivetracker.dto.MarginRevisionDto;
import com.incentivetracker.entity.Candidate;
import com.incentivetracker.entity.Coordinator;
import com.incentivetracker.entity.MarginRevision;
import com.incentivetracker.exception.ResourceNotFoundException;
import com.incentivetracker.mapper.CandidateMapper;
import com.incentivetracker.mapper.MarginRevisionMapper;
import com.incentivetracker.repository.CandidateRepository;
import com.incentivetracker.repository.CoordinatorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class CandidateService {

    private final CandidateRepository candidateRepository;
    private final CoordinatorRepository coordinatorRepository;
    private final CandidateMapper candidateMapper;
    private final MarginRevisionMapper marginRevisionMapper;

    public Page<CandidateDto> getAllCandidates(Pageable pageable) {
        return candidateRepository.findAll(pageable)
                .map(candidateMapper::toDto);
    }

    public CandidateDto getCandidateById(UUID id) {
        Candidate candidate = candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + id));
        return candidateMapper.toDto(candidate);
    }

    public CandidateDto getCandidateByCandidateId(String candidateId) {
        Candidate candidate = candidateRepository.findByCandidateId(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with candidateId: " + candidateId));
        return candidateMapper.toDto(candidate);
    }

    public CandidateDto createCandidate(CandidateDto candidateDto) {
        if (candidateRepository.existsByCandidateId(candidateDto.getCandidateId())) {
            throw new IllegalArgumentException("Candidate with ID " + candidateDto.getCandidateId() + " already exists");
        }
        
        Candidate candidate = candidateMapper.toEntity(candidateDto);
        setCoordinatorRelationships(candidate, candidateDto);
        calculateFields(candidate);
        candidate = candidateRepository.save(candidate);
        return candidateMapper.toDto(candidate);
    }

    public CandidateDto updateCandidate(UUID id, CandidateDto candidateDto) {
        Candidate existingCandidate = candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + id));
        
        candidateMapper.updateEntityFromDto(candidateDto, existingCandidate);
        setCoordinatorRelationships(existingCandidate, candidateDto);
        calculateFields(existingCandidate);
        existingCandidate = candidateRepository.save(existingCandidate);
        return candidateMapper.toDto(existingCandidate);
    }

    public void deleteCandidate(UUID id) {
        if (!candidateRepository.existsById(id)) {
            throw new ResourceNotFoundException("Candidate not found with id: " + id);
        }
        candidateRepository.deleteById(id);
    }

    public MarginRevisionDto addMarginRevision(UUID candidateId, MarginRevisionDto revisionDto) {
        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + candidateId));
        
        MarginRevision revision = marginRevisionMapper.toEntity(revisionDto);
        revision.setCandidate(candidate);
        calculateRevisionFields(revision, candidate);
        
        candidate.getMarginRevisions().add(revision);
        candidateRepository.save(candidate);
        
        return marginRevisionMapper.toDto(revision);
    }

    public List<MarginRevisionDto> getMarginRevisions(UUID candidateId) {
        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + candidateId));
        
        return candidate.getMarginRevisions().stream()
                .map(marginRevisionMapper::toDto)
                .toList();
    }

    public List<CandidateDto> getActiveCandidates() {
        List<Candidate> activeCandidates = candidateRepository.findActiveCandidatesForDate(LocalDate.now());
        return activeCandidates.stream()
                .map(candidateMapper::toDto)
                .toList();
    }

    public List<CandidateDto> getCandidatesByClient(String clientName) {
        List<Candidate> candidates = candidateRepository.findByClientName(clientName);
        return candidates.stream()
                .map(candidateMapper::toDto)
                .toList();
    }

    public List<CandidateDto> getAllCandidatesList() {
        List<Candidate> candidatesList = candidateRepository.findAll();
        return candidatesList.stream()
                .map(candidateMapper::toDto)
                .toList();
    }

    private void setCoordinatorRelationships(Candidate candidate, CandidateDto candidateDto) {
        // Set recruiter
        if (candidateDto.getRecruiter() != null && candidateDto.getRecruiter().getId() != null) {
            Coordinator recruiter = coordinatorRepository.findById(candidateDto.getRecruiter().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Recruiter not found with id: " + candidateDto.getRecruiter().getId()));
            candidate.setRecruiter(recruiter);
        }
        
        // Set lead
        if (candidateDto.getLead() != null && candidateDto.getLead().getId() != null) {
            Coordinator lead = coordinatorRepository.findById(candidateDto.getLead().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Lead not found with id: " + candidateDto.getLead().getId()));
            candidate.setLead(lead);
        }
        
        // Set manager
        if (candidateDto.getManager() != null && candidateDto.getManager().getId() != null) {
            Coordinator manager = coordinatorRepository.findById(candidateDto.getManager().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Manager not found with id: " + candidateDto.getManager().getId()));
            candidate.setManager(manager);
        }
        
        // Set senior manager
        if (candidateDto.getSeniorManager() != null && candidateDto.getSeniorManager().getId() != null) {
            Coordinator seniorManager = coordinatorRepository.findById(candidateDto.getSeniorManager().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Senior Manager not found with id: " + candidateDto.getSeniorManager().getId()));
            candidate.setSeniorManager(seniorManager);
        }
        
        // Set CRM
        if (candidateDto.getCrm() != null && candidateDto.getCrm().getId() != null) {
            Coordinator crm = coordinatorRepository.findById(candidateDto.getCrm().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("CRM not found with id: " + candidateDto.getCrm().getId()));
            candidate.setCrm(crm);
        }
        
        // Set Associate Director
        if (candidateDto.getAssoDirector() != null && candidateDto.getAssoDirector().getId() != null) {
            Coordinator assoDirector = coordinatorRepository.findById(candidateDto.getAssoDirector().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Associate Director not found with id: " + candidateDto.getAssoDirector().getId()));
            candidate.setAssoDirector(assoDirector);
        }
        
        // Set Center Head
        if (candidateDto.getCenterHead() != null && candidateDto.getCenterHead().getId() != null) {
            Coordinator centerHead = coordinatorRepository.findById(candidateDto.getCenterHead().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Center Head not found with id: " + candidateDto.getCenterHead().getId()));
            candidate.setCenterHead(centerHead);
        }
    }

    private void calculateFields(Candidate candidate) {
        // Calculation logic is now handled by MapStruct @AfterMapping in CandidateMapper
        // This method can be removed or used for additional business logic
    }

    private void calculateRevisionFields(MarginRevision revision, Candidate candidate) {
        // Calculation logic is now handled by MapStruct @AfterMapping in MarginRevisionMapper
        // This method can be removed or used for additional business logic
    }
}